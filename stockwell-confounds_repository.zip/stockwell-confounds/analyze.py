"""Classifier results for every condition/arm/seed -> results/auc.json (+ permutation nulls)."""
import os, json, sys, glob
import numpy as np
from multiprocessing import Pool
import analysis as A
from experiments import OUT, CONDITIONS

RES = os.path.join(os.path.dirname(OUT), 'auc.json')
IDX = ['plv', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'ppc']
ARMS = {'A1': ['A1'], 'A2': ['A2']}
for k in IDX:
    ARMS[k] = ['A3_' + k]
for k in ['plv', 'wpli', 'imcoh', 'ciplv']:
    ARMS[k + '+reg'] = ['A3_' + k, 'A3r_' + k]
ARMS['A1+wpli'] = ['A1', 'A3_wpli']
ARMS['A1+plv'] = ['A1', 'A3_plv']
TRANSFORM_ARMS = ['plv', 'imcoh', 'wpli', 'A2', 'A1']


def seeds_for(c):
    return sorted(int(os.path.basename(p).split('__s')[1][:-4]) for p in glob.glob(os.path.join(OUT, f'{c}__s*.npz')))


def job(args):
    c, s = args
    d = A.load(c, s)
    out = {}
    if c.startswith('rs_'):
        for pre in ['bench_', 'ref_']:
            for name, bl in ARMS.items():
                if any(pre + b not in d for b in bl):
                    continue
                r = A.eval_arm(d, bl, prefix=pre)
                out[pre + name] = r
    else:
        for name, bl in ARMS.items():
            if any(b not in d for b in bl):
                continue
            out[name] = A.eval_arm(d, bl)
        for kind in ['morlet7', 'hilbert']:
            if kind + ':A1' in d:
                for name in TRANSFORM_ARMS:
                    bl = ARMS[name]
                    out[kind + ':' + name] = A.eval_arm(d, bl, prefix=kind + ':')
    # within-subject phase-block permutation nulls for the main coupling conditions
    if c in ('inc_0.35', 'inc_0.6'):
        rng = np.random.default_rng(1000 + s)
        for name, perm_block, keep in [('wpli', 'A3_wpli', []), ('plv', 'A3_plv', []), ('A1+wpli', 'A3_wpli', ['A1'])]:
            vals = []
            for _ in range(50):
                Xp = A.permute_within_subject(d[perm_block], d['subj'], rng)
                X = np.hstack([d[k] for k in keep] + [Xp]).astype(np.float64)
                vals.append(A.eval_arm(d, None, X_override=X)['auc'])
            out['perm:' + name] = vals
    return c, s, out


def main(conds=None, procs=2):
    conds = conds or list(CONDITIONS)
    res = json.load(open(RES)) if os.path.exists(RES) else {}
    jobs = [(c, s) for c in conds for s in seeds_for(c) if str(s) not in res.get(c, {})]
    print(len(jobs), 'jobs', flush=True)
    with Pool(procs) as pool:
        for i, (c, s, out) in enumerate(pool.imap_unordered(job, jobs)):
            res.setdefault(c, {})[str(s)] = out
            if (i + 1) % 10 == 0 or i + 1 == len(jobs):
                json.dump(res, open(RES, 'w'))
                print(f'{i + 1}/{len(jobs)}', flush=True)
    json.dump(res, open(RES, 'w'))


if __name__ == '__main__':
    main(sys.argv[1].split(',') if len(sys.argv) > 1 else None, int(sys.argv[2]) if len(sys.argv) > 2 else 2)
