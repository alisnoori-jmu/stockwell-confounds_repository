"""Time-frequency transforms and connectivity indices.

Stockwell transform (FFT form, signed Gaussian offsets):
    S(tau, f_m) = IFFT_k { X[(k + m) mod N] * exp(-2 pi^2 k^2 / m^2) }
A Morlet CWT with the same Gaussian (sigma_f = f / 2pi, i.e. n_cycles = 2pi) satisfies
    W(tau, f) = S(tau, f) * exp(+i 2 pi f tau),
so every cross-channel quantity built from S_i S_j* is identical for the two transforms;
only single-channel absolute phase differs. Both are evaluated at 64 Hz time resolution
(baseband decimation, exact up to Gaussian tails < 5e-5).
"""
import numpy as np
from scipy import signal

BANDS = [(1, 4), (4, 8), (8, 13), (13, 30), (30, 45.01)]
BAND_NAMES = ['delta', 'theta', 'alpha', 'beta', 'gamma']
VOICES = np.concatenate([np.arange(1.0, 13.01, 1.0), np.arange(14.0, 44.01, 2.0)])   # Hz: 1-Hz steps to 13 Hz, 2-Hz steps above
BAND_OF_VOICE = np.array([next(i for i, (lo, hi) in enumerate(BANDS) if lo <= v < hi) for v in VOICES])
INDICES = ['plv', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'ppc']
_EPS = 1e-20


def _gauss_bank(N, fs, sigma_of_m, dec=4):
    m = np.round(VOICES * N / fs).astype(int)
    K = N // (2 * dec)
    kk = np.concatenate([np.arange(0, K), np.arange(-K, 0)])
    idx = (m[:, None] + kk[None, :]) % N
    sig = sigma_of_m(m.astype(float))
    G = np.exp(-(kk[None, :] ** 2) / (2 * sig[:, None] ** 2))
    return idx, G.astype(np.float32), m


_BANK = {}


def tf_coeffs(x, fs, kind='stockwell', dec=4):
    """x: (n_ch, N) real -> complex coeffs (n_ch, n_voices, N/dec)."""
    N = x.shape[-1]
    key = (N, fs, kind, dec)
    if key not in _BANK:
        if kind in ('stockwell', 'morlet2pi'):
            sig = lambda m: m / (2 * np.pi)
        elif kind == 'morlet7':
            sig = lambda m: m / 7.0
        else:
            raise ValueError(kind)
        _BANK[key] = _gauss_bank(N, fs, sig, dec)
    idx, G, m = _BANK[key]
    X = np.fft.fft(x, axis=-1).astype(np.complex64)
    Y = X[:, idx] * G[None]
    S = np.fft.ifft(Y, axis=-1)
    if kind == 'morlet2pi' or kind == 'morlet7':
        # restore the local (CWT) phase reference: W = S * exp(i 2 pi f tau)
        n_t = S.shape[-1]
        tau = np.arange(n_t) * dec / fs
        f = m * fs / N
        S = S * np.exp(1j * 2 * np.pi * f[:, None] * tau[None, :])[None]
    return S.astype(np.complex64)


_HB = {}


def hilbert_coeffs(x, fs, dec=4):
    """Band-pass analytic signal per band via a frequency-domain mask with 1-Hz raised-cosine
    edges (zero phase) -> (n_ch, n_bands, N/dec). Equivalent to FIR band-pass + Hilbert."""
    N = x.shape[-1]
    key = (fs, N)
    if key not in _HB:
        f = np.fft.fftfreq(N, 1.0 / fs)
        masks = []
        for lo, hi in BANDS:
            hi = min(hi, 0.45 * fs)
            m = np.zeros(N)
            pos = f > 0
            core = pos & (f >= lo) & (f <= hi)
            m[core] = 1.0
            lo_edge = pos & (f >= lo - 1) & (f < lo)
            hi_edge = pos & (f > hi) & (f <= hi + 1)
            m[lo_edge] = 0.5 - 0.5 * np.cos(np.pi * (f[lo_edge] - (lo - 1)))
            m[hi_edge] = 0.5 + 0.5 * np.cos(np.pi * (f[hi_edge] - hi))
            masks.append(2.0 * m)          # analytic signal: double positive frequencies
        _HB[key] = np.array(masks, dtype=np.float32)
    X = np.fft.fft(x, axis=-1)
    Y = X[:, None, :] * _HB[key][None]
    return np.fft.ifft(Y, axis=-1)[..., ::dec].astype(np.complex64)


import numba


@numba.njit(cache=True, fastmath=True)
def _pair_kernel(Cr, Ci, iu0, iu1):
    n_pairs = iu0.shape[0]
    n_f = Cr.shape[1]
    n_t = Cr.shape[2]
    out = np.zeros((6, n_pairs, n_f), dtype=np.float64)
    for p in range(n_pairs):
        a = iu0[p]
        b = iu1[p]
        for f in range(n_f):
            ser = 0.0; sei = 0.0; sim_ = 0.0; ssim = 0.0; sabs = 0.0; pa = 0.0; pb = 0.0
            for t in range(n_t):
                ar = Cr[a, f, t]; ai = Ci[a, f, t]; br = Cr[b, f, t]; bi = Ci[b, f, t]
                xr = ar * br + ai * bi          # Re(A conj(B))
                xi = ai * br - ar * bi          # Im(A conj(B))
                mag = np.sqrt(xr * xr + xi * xi) + 1e-20
                ser += xr / mag; sei += xi / mag
                sim_ += xi; ssim += xi * xi; sabs += abs(xi)
                pa += ar * ar + ai * ai; pb += br * br + bi * bi
            n = float(n_t)
            mr = ser / n; mi = sei / n
            out[0, p, f] = np.sqrt(mr * mr + mi * mi)                       # PLV
            out[1, p, f] = abs(sim_ / n) / np.sqrt((pa / n) * (pb / n) + 1e-20)  # |ImCoh|
            out[2, p, f] = abs(sim_) / (sabs + 1e-20)                        # wPLI
            num = sim_ * sim_ - ssim
            den = sabs * sabs - ssim
            v = num / (den + 1e-20)
            out[3, p, f] = v if v > 0 else 0.0                               # debiased wPLI^2
            den2 = 1.0 - mr * mr
            if den2 < 1e-6:
                den2 = 1e-6
            out[4, p, f] = abs(mi) / np.sqrt(den2)                          # ciPLV
            out[5, p, f] = ((ser * ser + sei * sei) - n) / (n * (n - 1.0))   # PPC
    return out


def _pair_stats(C, iu0, iu1):
    """C: (n_ch, n_freq, n_t). Returns dict index -> (n_pairs, n_freq)."""
    o = _pair_kernel(np.ascontiguousarray(C.real, dtype=np.float32),
                     np.ascontiguousarray(C.imag, dtype=np.float32),
                     iu0.astype(np.int64), iu1.astype(np.int64))
    return {k: o[i] for i, k in enumerate(INDICES)}


def band_average(a, bands_of_freq, n_bands=5):
    return np.stack([a[..., bands_of_freq == b].mean(-1) for b in range(n_bands)], axis=-1)


def window_features(x, fs, local_mask, chain=None, kind='stockwell'):
    """All feature blocks for one window x (n_ch, N).

    Returns dict of 1-D arrays:
      A1 log band power (n_ch*5), A2 circular variance of absolute phase (n_ch*5),
      A3_<index> pair summaries (5 bands x [mean, p90, local mean] = 15),
      A3r_<index> per-chain within-chain means (5 bands x 5 chains = 25, bipolar only).
    """
    dec = max(1, int(round(fs / 64.0)))              # coefficients kept at 64 Hz for every fs
    if kind == 'hilbert':
        C = hilbert_coeffs(x, fs, dec)
        bof = np.arange(5)
    else:
        C = tf_coeffs(x, fs, kind, dec)
        bof = BAND_OF_VOICE
    n_ch = C.shape[0]
    iu0, iu1 = np.triu_indices(n_ch, 1)
    feats = {}
    P = (np.abs(C) ** 2).mean(-1)                      # (n_ch, n_freq)
    feats['A1'] = np.log(band_average(P, bof) + 1e-12).ravel()
    u = C / (np.abs(C) + _EPS)
    cv = 1 - np.abs(u.mean(-1))                          # circular variance over time
    feats['A2'] = band_average(cv, bof).ravel()
    ps = _pair_stats(C, iu0, iu1)
    for k, v in ps.items():
        vb = band_average(v, bof)                        # (n_pairs, 5)
        s = [vb.mean(0), np.percentile(vb, 90, axis=0), vb[local_mask].mean(0)]
        feats['A3_' + k] = np.concatenate(s)
        if chain is not None:
            same = chain[iu0] == chain[iu1]
            reg = [vb[same & (chain[iu0] == c)].mean(0) for c in range(int(chain.max()) + 1)]
            feats['A3r_' + k] = np.concatenate(reg)
    return feats


# ------------------------------------------------------------- resampling operations
def benchmark_uniformise(x, fs_native):
    """MLSPred-Bench style: sample picking (no anti-alias filter) + zero padding to 1280."""
    if fs_native == 256:
        y = x
    elif fs_native == 512:
        y = x[:, ::2]
    elif fs_native == 1000:
        y = x[:, ::4]
    elif fs_native == 400:
        n8 = x.shape[-1] // 8 * 8
        keep = np.array([0, 2, 3, 5, 6])                  # 5 of every 8 samples
        idx = (np.arange(n8 // 8)[:, None] * 8 + keep[None, :]).ravel()
        y = x[:, idx]
    elif fs_native == 250:
        y = x
    else:
        raise ValueError(fs_native)
    n = y.shape[-1]
    if n < 1280:
        pad = 1280 - n
        y = np.pad(y, ((0, 0), (pad // 2, pad - pad // 2)))
    return y[:, :1280]


def reference_uniformise(x, fs_native):
    """Anti-aliased polyphase resampling to exactly 256 Hz (1280 samples)."""
    from fractions import Fraction
    fr = Fraction(256, int(fs_native)).limit_denominator(1000)
    y = signal.resample_poly(x, fr.numerator, fr.denominator, axis=-1)
    if y.shape[-1] < 1280:
        y = np.pad(y, ((0, 0), (0, 1280 - y.shape[-1])))
    return y[:, :1280]
