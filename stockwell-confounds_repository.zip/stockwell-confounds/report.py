"""Summary statistics, tables and figures for the Stockwell simulation study.

Reads results/auc.json, event_level.json, regime_map.json, regime_check.json and (if present)
eeg_real.json; writes results/summary.json and results/figs/*.png."""
import os, sys, json
import numpy as np
from scipy import stats
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'manuscripts'))
import figstyle as FS
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.lines import Line2D

HERE = os.path.dirname(os.path.abspath(__file__))
RD = os.path.join(HERE, 'results')
FIG = os.path.join(RD, 'figs')
os.makedirs(FIG, exist_ok=True)
FS.apply()


def _load(name):
    p = os.path.join(RD, name)
    return json.load(open(p)) if os.path.exists(p) else None


R = _load('auc.json') or {}

# fixed identity -> style (colour follows the entity in every figure)
STYLE = {
    'A1': dict(c=FS.SERIES[0], m='o', ls='-', label='Band power (A1)'),
    'plv': dict(c=FS.SERIES[1], m='s', ls='--', label='PLV'),
    'wpli': dict(c=FS.SERIES[2], m='^', ls='-.', label='wPLI'),
    'imcoh': dict(c=FS.SERIES[3], m='D', ls=':', label='|ImCoh|'),
    'ciplv': dict(c=FS.SERIES[4], m='v', ls=(0, (5, 1)), label='ciPLV'),
    'ppc': dict(c=FS.SERIES[5], m='P', ls=(0, (3, 1, 1, 1)), label='PPC'),
    'dwpli': dict(c=FS.SERIES[6], m='X', ls='-', label='dwPLI'),
    'A2': dict(c=FS.SERIES[7], m='*', ls='--', label='Absolute phase (A2)'),
}
NAMES = {k: v['label'] for k, v in STYLE.items()}
NAMES.update({'A1+wpli': 'A1 + wPLI', 'A1+plv': 'A1 + PLV', 'plv+reg': 'PLV + regional',
              'wpli+reg': 'wPLI + regional', 'imcoh+reg': '|ImCoh| + regional', 'ciplv+reg': 'ciPLV + regional'})


# ------------------------------------------------------------------ statistics helpers
def seeds(cond):
    return sorted(R.get(cond, {}), key=int)


def vals(cond, arm):
    c = R.get(cond, {})
    return np.array([c[s][arm]['auc'] for s in seeds(cond) if arm in c[s]])


def ci(v, level=0.95):
    v = np.asarray(v, float)
    n = len(v)
    if n == 0:
        return np.nan, np.nan, np.nan
    m = v.mean()
    if n < 2:
        return m, np.nan, np.nan
    h = stats.t.ppf(0.5 + level / 2, n - 1) * v.std(ddof=1) / np.sqrt(n)
    return m, m - h, m + h


def wilcoxon_vs(v, ref=0.5):
    v = np.asarray(v, float) - ref
    if len(v) < 6 or np.allclose(v, 0):
        return np.nan
    return float(stats.wilcoxon(v).pvalue)


def holm(ps):
    ps = np.asarray(ps, float)
    adj = np.full_like(ps, np.nan)
    ok = ~np.isnan(ps)
    q = ps[ok]
    order = np.argsort(q)
    out = np.empty_like(q)
    m = len(q)
    run = 0.0
    for r, i in enumerate(order):
        run = max(run, (m - r) * q[i])
        out[i] = min(run, 1.0)
    adj[ok] = out
    return adj


def paired(c1, a1, c2, a2):
    """Seed-paired difference c1/a1 - c2/a2 (same simulated subjects in both)."""
    s = sorted(set(R.get(c1, {})) & set(R.get(c2, {})), key=int)
    d = np.array([R[c1][k][a1]['auc'] - R[c2][k][a2]['auc'] for k in s
                  if a1 in R[c1][k] and a2 in R[c2][k]])
    m, lo, hi = ci(d)
    p = float(stats.wilcoxon(d).pvalue) if len(d) > 5 and not np.allclose(d, 0) else np.nan
    return dict(mean=m, lo=lo, hi=hi, n=len(d), p=p, diffs=d.tolist())


def tost(d, margin):
    d = np.asarray(d, float)
    m, lo90, hi90 = ci(d, 0.90)
    _, lo95, hi95 = ci(d, 0.95)
    return dict(mean=m, lo90=lo90, hi90=hi90, lo95=lo95, hi95=hi95, margin=margin,
                equivalent=bool(lo90 > -margin and hi90 < margin),
                differs=bool(hi95 < 0 or lo95 > 0))


def subject_pooled(cond, arm):
    """Per-subject AUROCs pooled over seeds (for the subject-level summary)."""
    c = R.get(cond, {})
    out = []
    for s in seeds(cond):
        if arm in c[s]:
            out += c[s][arm]['subj_auc']
    return np.array(out)


def boot_ci(x, n=5000, seed=0):
    x = np.asarray(x, float)
    if len(x) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    b = rng.choice(x, (n, len(x))).mean(1)
    return float(x.mean()), float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))


def fmt(m, lo, hi, d=3):
    if np.isnan(m):
        return 'n/a'
    if np.isnan(lo):
        return f'{m:.{d}f}'
    return f'{m:.{d}f} [{lo:.{d}f}, {hi:.{d}f}]'


# ------------------------------------------------------------------ figure 1: design + timeline
def fig_design():
    fig = plt.figure(figsize=(7.2, 4.6))
    ax = fig.add_axes([0.0, 0.60, 1.0, 0.39])
    ax.set_xlim(0, 100); ax.set_ylim(0, 30); ax.axis('off')
    boxes = [
        (1, 'Sources (8)', 'shared + private phase\nrandom walks, lags $\\varphi_k$;\nfocal set $\\rho_0 \\pm \\Delta\\rho$'),
        (21, 'Lead field', 'Gaussian, width 0.35;\n17 electrodes;\nzero-lag mixing'),
        (41, 'Artefacts', 'EMG, mains, pops,\nsensor noise\n(SNR 5 $\\pm$ 1.5 dB)'),
        (61, 'Montage', '20 bipolar channels,\ndouble banana\n(MLSPred-Bench)'),
        (81, 'Features', 'Stockwell, Morlet or\nHilbert: power, abs.\nand inter-channel phase'),
    ]
    for x, t, s in boxes:
        ax.add_patch(FancyBboxPatch((x, 10), 17.2, 16.5, boxstyle='round,pad=0.3,rounding_size=1.2',
                                    fc='#f4f3f0', ec=FS.INK2, lw=0.9))
        ax.text(x + 8.6, 23.6, t, ha='center', va='center', fontsize=8.3, fontweight='bold', color=FS.INK)
        ax.text(x + 8.6, 16.6, s, ha='center', va='center', fontsize=6.9, color=FS.INK2, linespacing=1.3)
    for x in (18.7, 38.7, 58.7, 78.7):
        ax.annotate('', xy=(x + 2.0, 18.2), xytext=(x, 18.2),
                    arrowprops=dict(arrowstyle='-|>', color=FS.INK2, lw=1.0))
    ax.text(50, 3.5, 'L2 logistic regression (C tuned on validation subjects)  \u2192  window scores  \u2192  alarm rule',
            ha='center', va='center', fontsize=7.6, color=FS.INK)
    ax.text(-0.5, 31.5, 'a', fontsize=10, fontweight='bold', va='top', color=FS.INK)

    # (b) alarm-centred definitions (Winterhalder et al.)
    ax2 = fig.add_axes([0.07, 0.33, 0.88, 0.2])
    ax2.set_xlim(-6, 52); ax2.set_ylim(0, 2.4)
    ax2.spines[['left', 'top', 'right']].set_visible(False)
    ax2.set_yticks([]); ax2.grid(False)
    ax2.add_patch(Rectangle((0, 0.55), 10, 0.8, fc='#f2f1ee', ec=FS.INK2, lw=1.0, hatch='////'))
    ax2.text(5, 0.95, 'SPH', ha='center', va='center', fontsize=7.6, color=FS.INK,
             bbox=dict(fc='#f2f1ee', ec='none', pad=0.6))
    ax2.add_patch(Rectangle((10, 0.55), 30, 0.8, fc='#dbe8f7', ec=FS.SERIES[0], lw=1.0))
    ax2.text(20, 0.95, 'SOP: seizure expected here', ha='center', va='center', fontsize=7.6, color=FS.INK)
    ax2.plot([0], [1.62], marker='v', color=FS.INK, ms=7, ls='none')
    ax2.text(0, 1.95, 'alarm $T_a$', ha='center', va='bottom', fontsize=7.6, color=FS.INK)
    ax2.axvline(34, ymin=0.15, ymax=0.62, color=FS.SERIES[7], lw=1.6)
    ax2.text(33.4, 1.62, 'onset $T_s$ inside the SOP: correct alarm', ha='right', va='center', fontsize=7.4, color=FS.INK)
    ax2.annotate('', xy=(0, 0.3), xytext=(40, 0.3), arrowprops=dict(arrowstyle='<->', color=FS.INK2, lw=0.8))
    ax2.text(41, 0.3, 'refractory: SPH + SOP', ha='left', va='center', fontsize=7.2, color=FS.INK2)
    ax2.set_xlabel('Time after the alarm (min); example with SPH = 10 min, SOP = 30 min', fontsize=7.8)
    ax2.text(-6, 2.6, 'b', fontsize=10, fontweight='bold', va='top', color=FS.INK)

    # (c) seizure-centred labels used for training and for the monitoring streams
    ax3 = fig.add_axes([0.07, 0.08, 0.88, 0.13])
    ax3.set_xlim(-52, 6); ax3.set_ylim(0, 1.6)
    ax3.spines[['left', 'top', 'right']].set_visible(False)
    ax3.set_yticks([]); ax3.grid(False)
    ax3.add_patch(Rectangle((-52, 0.35), 12, 0.8, fc='white', ec=FS.INK2, lw=0.8))
    ax3.text(-46, 0.75, 'interictal (0)', ha='center', va='center', fontsize=7.4, color=FS.INK)
    ax3.add_patch(Rectangle((-40, 0.35), 30, 0.8, fc='#dbe8f7', ec=FS.SERIES[0], lw=1.0))
    ax3.text(-25, 0.75, 'preictal (1): $T_s - $SPH$ - $SOP to $T_s - $SPH', ha='center', va='center', fontsize=7.4,
             color=FS.INK)
    ax3.add_patch(Rectangle((-10, 0.35), 16, 0.8, fc='#f2f1ee', ec=FS.INK2, lw=1.0, hatch='////'))
    ax3.text(-5, 0.75, 'excluded', ha='center', va='center', fontsize=7.4, color=FS.INK,
             bbox=dict(fc='#f2f1ee', ec='none', pad=0.6))
    ax3.axvline(0, ymin=0.1, ymax=0.85, color=FS.SERIES[7], lw=1.6)
    ax3.set_xlabel('Time relative to seizure onset $T_s$ (min); SPH and postictal 30 min excluded', fontsize=7.8)
    ax3.text(-52, 1.85, 'c', fontsize=10, fontweight='bold', va='top', color=FS.INK)
    fig.savefig(os.path.join(FIG, 'fig1_design.png'))
    plt.close(fig)


# ------------------------------------------------------------------ figure 2: coupling sweep
def fig_sweep():
    arms = ['A1', 'plv', 'wpli', 'imcoh', 'ciplv', 'A2']
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), sharey=True)
    for ax, direction, lab in [(axs[0], 'inc', 'a'), (axs[1], 'dec', 'b')]:
        xs = [0.0, 0.1, 0.2, 0.35, 0.6] if direction == 'inc' else [0.0, 0.1, 0.2, 0.35]
        for a in arms:
            pts = []
            for x in xs:
                cname = 'inc_0.0' if x == 0 else f'{direction}_{x}'
                m, lo, hi = ci(vals(cname, a))
                pts.append((x, m, lo, hi))
            pts = [p for p in pts if not np.isnan(p[1])]
            if not pts:
                continue
            x, m, lo, hi = map(np.array, zip(*pts))
            st = STYLE[a]
            ax.errorbar(x, m, yerr=[m - lo, hi - m], color=st['c'], marker=st['m'], ls=st['ls'],
                        capsize=2.5, lw=1.5, ms=5, label=st['label'])
        ax.axhline(0.5, color=FS.INK2, lw=0.9, ls=':')
        ax.set_xlabel('Increase in focal coupling, $\\Delta\\rho$' if direction == 'inc'
                      else 'Decrease in focal coupling, $\\Delta\\rho$')
        FS.panel_label(ax, lab)
    axs[0].set_ylabel('Test AUROC (mean over seeds, 95% CI)')
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=6, bbox_to_anchor=(0.5, 1.06), fontsize=7.5)
    fig.savefig(os.path.join(FIG, 'fig2_sweep.png'))
    plt.close(fig)


# ------------------------------------------------------------------ figure 3: power confound + permutation
def fig_power_perm():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.1), gridspec_kw=dict(width_ratios=[1.25, 1]))
    ax = axs[0]
    arms = ['A1', 'plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'A2']
    for i, a in enumerate(arms):
        for j, (cond, off, fill) in enumerate([('power40', -0.18, True), ('inc_0.35', 0.18, False)]):
            m, lo, hi = ci(vals(cond, a))
            if np.isnan(m):
                continue
            st = STYLE[a]
            ax.errorbar(i + off, m, yerr=[[m - lo], [hi - m]], color=st['c'], marker=st['m'], ms=6,
                        mfc=st['c'] if fill else 'white', mec=st['c'], capsize=2.5, ls='none', lw=1.4)
    ax.axhline(0.5, color=FS.INK2, lw=0.9, ls=':')
    ax.set_xticks(range(len(arms)))
    short = dict(A1='A1\npower', A2='A2\nabs. phase', plv='PLV', ppc='PPC', imcoh='|ImCoh|', wpli='wPLI',
                 dwpli='dwPLI', ciplv='ciPLV')
    ax.set_xticklabels([short[a] for a in arms], fontsize=7.2)
    ax.set_ylabel('Test AUROC (95% CI)')
    ax.legend(handles=[Line2D([], [], color=FS.INK2, marker='o', ls='none', mfc=FS.INK2, label='power only (+40%)'),
                       Line2D([], [], color=FS.INK2, marker='o', ls='none', mfc='white', label='coupling only ($\\Delta\\rho$ = 0.35)')],
              loc='upper right', fontsize=7.2)
    FS.panel_label(ax, 'a')

    ax = axs[1]
    rows = [('wpli', 'wPLI'), ('plv', 'PLV'), ('A1+wpli', 'A1+\nwPLI')]
    k = 0
    ticks, tl, gpos = [], [], []
    for cond, cl in [('inc_0.35', '$\\Delta\\rho$ = 0.35'), ('inc_0.6', '$\\Delta\\rho$ = 0.6')]:
        k0 = k
        for arm, lab in rows:
            ss = [s for s in seeds(cond) if 'perm:' + arm in R[cond][s] and arm in R[cond][s]]
            if not ss:
                continue
            obs = np.array([R[cond][s][arm]['auc'] for s in ss])
            perm = np.array([R[cond][s]['perm:' + arm] for s in ss]).mean(0)   # null of the seed mean
            col = STYLE['wpli']['c'] if arm == 'wpli' else STYLE['plv']['c'] if arm == 'plv' else FS.INK2
            parts = ax.violinplot([perm], positions=[k], widths=0.7, showextrema=False)
            for b in parts['bodies']:
                b.set_facecolor('#d9d8d4'); b.set_edgecolor('none'); b.set_alpha(1)
            m, lo, hi = ci(obs)
            ax.errorbar(k, m, yerr=[[m - lo], [hi - m]], color=col, marker='o', ms=5.5, capsize=2.5, lw=1.4)
            ticks.append(k); tl.append(lab)
            k += 1
        gpos.append(((k0 + k - 1) / 2, cl))
        k += 0.6
    ax.axhline(0.5, color=FS.INK2, lw=0.9, ls=':')
    ax.set_xticks(ticks); ax.set_xticklabels(tl, fontsize=7.0)
    for x, cl in gpos:
        ax.text(x, -0.2, cl, transform=ax.get_xaxis_transform(), ha='center', va='top', fontsize=7.6, color=FS.INK)
    ax.set_ylabel('Test AUROC')
    ax.set_ylim(0.46, 0.9)
    ax.legend(handles=[Line2D([], [], color='#b9b8b4', lw=6, label='permutation null'),
                       Line2D([], [], color=FS.INK2, marker='o', ls='none', label='observed (95% CI)')],
              loc='upper left', fontsize=7.0)
    FS.panel_label(ax, 'b')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig3_power_perm.png'))
    plt.close(fig)


# ------------------------------------------------------------------ figure 4: observation cost + lag sweep
def fig_obs_lag():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw=dict(width_ratios=[1.2, 1]))
    ax = axs[0]
    conds = [('obs_source', 'Sources'), ('obs_referential', 'Referential\nelectrodes'),
             ('obs_bipolar_noart', 'Bipolar,\nno artefacts'), ('inc_0.35', 'Bipolar with\nartefacts')]
    arms = ['A1', 'plv', 'wpli', 'imcoh']
    for j, a in enumerate(arms):
        xs, ms, los, his = [], [], [], []
        for i, (c, _) in enumerate(conds):
            m, lo, hi = ci(vals(c, a))
            if not np.isnan(m):
                xs.append(i + (j - 1.5) * 0.11); ms.append(m); los.append(lo); his.append(hi)
        if xs:
            st = STYLE[a]
            ms, los, his = map(np.array, (ms, los, his))
            ax.errorbar(xs, ms, yerr=[ms - los, his - ms], color=st['c'], marker=st['m'], ls=st['ls'], lw=1.3,
                        capsize=2, ms=5, label=st['label'])
    ax.axhline(0.5, color=FS.INK2, lw=0.9, ls=':')
    ax.set_xticks(range(len(conds))); ax.set_xticklabels([c[1] for c in conds], fontsize=7.2)
    ax.set_ylabel('Test AUROC at $\\Delta\\rho$ = 0.35 (95% CI)')
    ax.legend(fontsize=7, loc='upper right')
    FS.panel_label(ax, 'a')

    ax = axs[1]
    lags = [(0, 'lag_0'), (10, 'lag_10'), (30, 'inc_0.35'), (60, 'lag_60'), (90, 'lag_90')]
    for a in ['A1', 'plv', 'wpli', 'imcoh']:
        pts = [(x,) + ci(vals(c, a)) for x, c in lags]
        pts = [p for p in pts if not np.isnan(p[1])]
        if not pts:
            continue
        x, m, lo, hi = map(np.array, zip(*pts))
        st = STYLE[a]
        ax.errorbar(x, m, yerr=[m - lo, hi - m], color=st['c'], marker=st['m'], ls=st['ls'], capsize=2.5,
                    lw=1.5, ms=5, label=st['label'])
    ax.axhline(0.5, color=FS.INK2, lw=0.9, ls=':')
    ax.set_xlabel('SD of fixed source lags (degrees)')
    ax.set_xticks([0, 10, 30, 60, 90])
    FS.panel_label(ax, 'b')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig4_obs_lag.png'))
    plt.close(fig)


# ------------------------------------------------------------------ resampling
RS_RATES = [250, 400, 512, 1000]
RS_OPS = {250: 'zero padding', 400: 'keep 5 of 8, pad', 512: 'keep 1 of 2', 1000: 'keep 1 of 4, pad'}
RS_ARMS = ['A1', 'plv', 'ppc', 'imcoh', 'wpli', 'A2']
RS_TABLE_ARMS = ['A1', 'A2', 'plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv']


def resampling_table():
    rows = []
    for fs in RS_RATES:
        c = f'rs_{fs}'
        for a in RS_TABLE_ARMS:
            d = paired(c, 'bench_' + a, c, 'ref_' + a)
            if d['n'] == 0:
                continue
            t2, t5 = tost(d['diffs'], 0.02), tost(d['diffs'], 0.05)
            mref = ci(vals(c, 'ref_' + a))[0]
            rows.append(dict(rate=fs, op=RS_OPS[fs], arm=a, n=d['n'], ref_auc=mref, **{k: t2[k] for k in
                             ('mean', 'lo90', 'hi90', 'lo95', 'hi95', 'differs')},
                             equiv_002=t2['equivalent'], equiv_005=t5['equivalent'], p_wilcoxon=d['p']))
    return rows


def fig_resampling(rows):
    if not rows:
        return
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    ax.axhspan(-0.05, 0.05, color='#f1f0ec', zorder=0)
    ax.axhspan(-0.02, 0.02, color='#e2e1dc', zorder=0)
    for j, a in enumerate(RS_ARMS):
        st = STYLE[a]
        xs, ms, lo, hi = [], [], [], []
        for i, fs in enumerate(RS_RATES):
            r = [x for x in rows if x['rate'] == fs and x['arm'] == a]
            if not r:
                continue
            r = r[0]
            xs.append(i + (j - 2.5) * 0.12); ms.append(r['mean']); lo.append(r['lo90']); hi.append(r['hi90'])
        ms, lo, hi = map(np.array, (ms, lo, hi))
        ax.errorbar(xs, ms, yerr=[ms - lo, hi - ms], color=st['c'], marker=st['m'], ls='none', capsize=2.5,
                    ms=5.5, lw=1.4, label=st['label'])
    ax.axhline(0, color=FS.INK2, lw=0.9)
    ax.set_xticks(range(len(RS_RATES)))
    ax.set_xticklabels([f'{fs} Hz\n{RS_OPS[fs]}' for fs in RS_RATES], fontsize=7.4)
    ax.set_ylabel('$\\Delta$AUROC, benchmark $-$ polyphase\n(mean, 90% CI)')
    ax.text(3.62, 0.0205, '$\\pm$0.02', fontsize=7, color=FS.INK2, va='bottom', ha='right')
    ax.text(3.62, 0.0505, '$\\pm$0.05', fontsize=7, color=FS.INK2, va='bottom', ha='right')
    ax.legend(ncol=6, fontsize=7.0, loc='lower center', bbox_to_anchor=(0.5, 1.0))
    fig.savefig(os.path.join(FIG, 'fig5_resampling.png'))
    plt.close(fig)


# ------------------------------------------------------------------ event level
TAUS = [0.0, 30.0, 60.0, 300.0, 1200.0]
TAU_LAB = {0.0: 'i.i.d.', 30.0: '30 s', 60.0: '1 min', 300.0: '5 min', 1200.0: '20 min'}


def event_table(ev):
    out = []
    if not ev:
        return out
    for cfg in sorted({r['cfg'] for r in ev}):
        for rule in ['3of5', '3consec']:
            for tau in TAUS:
                rr = [r for r in ev if r['cfg'] == cfg and r['rule'] == rule and r['tau'] == tau]
                if not rr:
                    continue
                # pooled over subjects: total false alarms / total eligible hours (refractory-corrected per subject)
                fa = np.array([r['fa_h'] for r in rr]); sens = np.array([r['sens'] for r in rr])
                rnd = np.array([r['random_sens'] for r in rr]); tiw = np.array([r['tiw'] for r in rr])
                pw = np.array([r['p_window'] for r in rr])
                nwin = np.array([r['inter_h'] * 720 for r in rr])
                nexc = pw * nwin
                nruns = np.array([r['n_runs'] for r in rr])
                out.append(dict(cfg=cfg, rule=rule, tau=tau, n_subj=len(rr),
                                hours=float(sum(r['inter_h'] for r in rr)),
                                sens=boot_ci(sens), fa_h=boot_ci(fa), fa_h_median=float(np.median(fa)),
                                random_sens=float(rnd.mean()), tiw=float(tiw.mean()),
                                p_window=float(nexc.sum() / nwin.sum()), p_subject_median=float(np.median(pw)),
                                mean_run_windows=float(nexc.sum() / max(nruns.sum(), 1))))
    return out


def fig_event(ev, rmap, rchk, real=None):
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 3.0), gridspec_kw=dict(width_ratios=[1.15, 1, 1]))
    # (a) analytic regime map, simulation check and real-EEG operating points
    ax = axs[0]
    if rmap:
        rows = rmap['SPH2_SOP5']
        for rule, st, lab in [('3consec', STYLE['A1'], '3 consecutive'), ('3of5', STYLE['plv'], '3 of 5')]:
            r = [x for x in rows if x['rule'] == rule]
            ax.plot([x['p'] for x in r], [x['L_star_windows'] * 5 / 60 for x in r], color=st['c'], ls=st['ls'],
                    lw=1.8, label=f'$L^*$, {lab}')
        if rchk:
            iid = {(x['p'], x['rule'], x['cfg']): x['sim_fa_h'] for x in rchk if x['L'] is None}
            for x in rchk:
                if x['L'] is None or x['cfg'] != 'SPH2_SOP5' or x['rule'] != '3consec':
                    continue
                higher = x['sim_fa_h'] > iid[(x['p'], x['rule'], x['cfg'])]
                ax.plot(x['p'], x['L'] * 5 / 60, marker='o', ms=5, ls='none', color=FS.INK,
                        mfc=FS.INK if higher else 'white')
        if real:
            cl = real['clustering']
            for sname, mk in [('line_length', 's'), ('alpha_power', 'D'), ('alpha_plv', '^')]:
                rr = [r for r in cl if r['score'] == sname and r['mean_run'] > 0]
                if rr:
                    ax.plot([r['p'] for r in rr], [r['mean_run'] * 5 / 60 for r in rr], marker=mk, ls='none', ms=4.5,
                            color=FS.SERIES[2], mfc='white')
        ax.set_xscale('log'); ax.set_yscale('log')
        ax.set_xlabel('Exceedance rate per window, $p$')
        ax.set_ylabel('Mean run of exceedances (min)')
        ax.text(0.03, 0.03, 'clustering\nraises the\nalarm rate', transform=ax.transAxes, fontsize=6.6, color=FS.INK2,
                va='bottom')
        ax.text(0.97, 0.96, 'clustering lowers\nthe alarm rate', transform=ax.transAxes, fontsize=6.8, color=FS.INK2,
                va='top', ha='right')
    FS.panel_label(ax, 'a')
    ha_ = [Line2D([], [], color=STYLE['A1']['c'], lw=1.8, label='$L^*$, 3 consecutive'),
           Line2D([], [], color=STYLE['plv']['c'], lw=1.8, ls='--', label='$L^*$, 3 of 5'),
           Line2D([], [], marker='o', color=FS.INK, ls='none', ms=5, label='simulation: more alarms than i.i.d.'),
           Line2D([], [], marker='o', color=FS.INK, mfc='white', ls='none', ms=5, label='simulation: fewer alarms than i.i.d.')]
    if real:
        ha_ += [Line2D([], [], marker=mk, color=FS.SERIES[2], mfc='white', ls='none', ms=4.5, label=f'CHB-MIT: {nm}')
                for nm, mk in [('line length', 's'), ('alpha power', 'D'), ('alpha PLV', '^')]]
    # (b) false alarms per hour vs tau; (c) sensitivity vs tau
    tab = event_table(ev)
    for ax, key, ylab, lab in [(axs[1], 'fa_h', 'False alarms per hour', 'b'), (axs[2], 'sens', 'Event sensitivity', 'c')]:
        for cfg, cls in [('SPH2_SOP5', '-'), ('SPH10_SOP30', '--')]:
            for rule, st in [('3consec', STYLE['A1']), ('3of5', STYLE['plv'])]:
                r = [x for x in tab if x['cfg'] == cfg and x['rule'] == rule]
                if not r:
                    continue
                x = np.arange(len(r))
                m = np.array([q[key][0] for q in r]); lo = np.array([q[key][1] for q in r]); hi = np.array([q[key][2] for q in r])
                ax.errorbar(x + (0.08 if cfg == 'SPH10_SOP30' else -0.08), m, yerr=[m - lo, hi - m], color=st['c'],
                            marker=st['m'], mfc=st['c'] if cfg == 'SPH2_SOP5' else 'white', ls=cls, capsize=2, lw=1.3,
                            ms=4.5, label=f"{'3 consec.' if rule == '3consec' else '3 of 5'}, "
                                          f"{'SPH 2/SOP 5' if cfg == 'SPH2_SOP5' else 'SPH 10/SOP 30'}")
                if key == 'sens':
                    ax.plot(x, [q['random_sens'] for q in r], color=st['c'], ls=':', lw=1.0)
        ax.set_xticks(range(len(TAUS))); ax.set_xticklabels([TAU_LAB[t] for t in TAUS], fontsize=7, rotation=30)
        ax.set_xlabel('Correlation time $\\tau$')
        ax.set_ylabel(ylab)
        FS.panel_label(ax, lab)
    axs[2].text(0.02, 0.02, 'dotted: random predictor', transform=axs[2].transAxes, fontsize=6.5, color=FS.INK2)
    h, l = axs[1].get_legend_handles_labels()
    fig.tight_layout(rect=(0, 0, 1, 0.84))
    fig.legend(handles=ha_, loc='upper left', ncol=2, bbox_to_anchor=(0.0, 1.0), fontsize=6.4,
               title='(a)', title_fontsize=6.6, alignment='left')
    if h:
        fig.legend(h, l, loc='upper right', ncol=2, bbox_to_anchor=(1.0, 1.0), fontsize=6.4, title='(b, c)',
                   title_fontsize=6.6, alignment='left')
    fig.savefig(os.path.join(FIG, 'fig6_event.png'))
    plt.close(fig)


# ------------------------------------------------------------------ real EEG
def fig_real(real):
    if not real:
        return
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.8))
    ax = axs[0]
    idx = ['plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv']
    ent = real['entanglement']
    for i, k in enumerate(idx):
        st = STYLE[k]
        a = np.array(ent[k]['auc_power_terciles_lopo'])
        ax.plot(np.full(len(a), i) + np.linspace(-0.12, 0.12, len(a)), a, marker=st['m'], color=st['c'], ls='none',
                ms=4.5, mfc='white')
        ax.plot(i, a.mean(), marker=st['m'], color=st['c'], ms=7, ls='none')
    ax.axhline(0.5, color=FS.INK2, lw=0.9, ls=':')
    ax.set_xticks(range(len(idx))); ax.set_xticklabels([NAMES[k] for k in idx], fontsize=7, rotation=30)
    ax.set_ylabel('AUROC, high vs low alpha power\n(leave-one-patient-out)')
    FS.panel_label(ax, 'a')
    ax = axs[1]
    rs = real['resampling']
    for i, k in enumerate(idx):
        st = STYLE[k]
        v = np.array([r[f'mad_{k}'] for r in rs])
        ax.plot(np.full(len(v), i) + np.linspace(-0.12, 0.12, len(v)), v * 100, marker=st['m'], color=st['c'], ls='none',
                ms=4.5)
    ax.set_xticks(range(len(idx))); ax.set_xticklabels([NAMES[k] for k in idx], fontsize=7, rotation=30)
    ax.set_ylabel('Median relative feature change (%)\npicking vs polyphase, 256 → 128 Hz')
    FS.panel_label(ax, 'b')
    ax = axs[2]
    cl = real['clustering']
    scores = ['line_length', 'alpha_power', 'beta_power', 'alpha_plv', 'alpha_wpli']
    for i, s in enumerate(scores):
        rr = [r for r in cl if r['score'] == s]
        real_ = np.array([r['fa_real_3consec'] for r in rr]); iid = np.array([r['fa_iid_3consec'] for r in rr])
        ax.plot(np.full(len(rr), i) - 0.12, iid, marker='o', color=FS.SERIES[0], mfc='white', ls='none', ms=4.5)
        ax.plot(np.full(len(rr), i) + 0.12, real_, marker='s', color=FS.SERIES[1], ls='none', ms=4.5)
    ax.set_yscale('log')
    ax.set_xticks(range(len(scores)))
    ax.set_xticklabels(['line length', 'alpha power', 'beta power', 'alpha PLV', 'alpha wPLI'], fontsize=7, rotation=30)
    ax.set_ylabel('False alarms per hour, 3 consecutive')
    ax.legend(handles=[Line2D([], [], color=FS.SERIES[0], marker='o', mfc='white', ls='none', label='permuted (i.i.d.)'),
                       Line2D([], [], color=FS.SERIES[1], marker='s', ls='none', label='real order')], fontsize=6.8,
              loc='lower right')
    FS.panel_label(ax, 'c')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig7_real_eeg.png'))
    plt.close(fig)


# ------------------------------------------------------------------ main
ARMS_ALL = ['A1', 'A2', 'plv', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'ppc', 'plv+reg', 'wpli+reg', 'imcoh+reg',
            'ciplv+reg', 'A1+wpli', 'A1+plv']
CONDS_ALL = ['inc_0.0', 'inc_0.1', 'inc_0.2', 'inc_0.35', 'inc_0.6', 'dec_0.1', 'dec_0.2', 'dec_0.35', 'power40',
             'obs_source', 'obs_referential', 'obs_bipolar_noart', 'snr_p10', 'snr_m5', 'hetero2',
             'lag_0', 'lag_10', 'lag_60', 'lag_90', 'lag_0_null', 'kura_null', 'kura_inc_0.1', 'kura_inc_0.4',
             'kura_power40']


def main():
    out = {}
    tab = []
    for c in CONDS_ALL:
        for a in ARMS_ALL:
            v = vals(c, a)
            if len(v) == 0:
                continue
            m, lo, hi = ci(v)
            sv = subject_pooled(c, a)
            tab.append(dict(cond=c, arm=a, n_seeds=len(v), mean=m, lo=lo, hi=hi, sd_seed=float(v.std(ddof=1)) if len(v) > 1 else np.nan,
                            mcse=float(v.std(ddof=1) / np.sqrt(len(v))) if len(v) > 1 else np.nan,
                            p_vs_chance=wilcoxon_vs(v), subj_mean=float(sv.mean()) if len(sv) else np.nan,
                            n_subj=len(sv)))
    # Holm within each condition (family = arms of one condition vs chance)
    for c in CONDS_ALL:
        rr = [r for r in tab if r['cond'] == c]
        if rr:
            adj = holm([r['p_vs_chance'] for r in rr])
            for r, p in zip(rr, adj):
                r['p_holm'] = float(p)
    out['table'] = tab
    # transform comparison
    tr = []
    for c in ['inc_0.35', 'inc_0.6', 'power40']:
        for a in ['A1', 'A2', 'plv', 'imcoh', 'wpli']:
            for kind in ['', 'morlet7:', 'hilbert:']:
                v = vals(c, kind + a)
                if len(v):
                    m, lo, hi = ci(v)
                    d = paired(c, kind + a, c, a) if kind else None
                    tr.append(dict(cond=c, arm=a, transform=kind.rstrip(':') or 'stockwell', mean=m, lo=lo, hi=hi,
                                   diff_vs_stockwell=None if d is None else dict(mean=d['mean'], lo=d['lo'], hi=d['hi'], p=d['p'])))
    out['transforms'] = tr
    # key paired contrasts
    con = {}
    pairs = [('obs_source', 'inc_0.35'), ('obs_referential', 'inc_0.35'), ('obs_bipolar_noart', 'inc_0.35'),
             ('obs_source', 'obs_referential'), ('obs_referential', 'obs_bipolar_noart'), ('snr_p10', 'snr_m5'),
             ('hetero2', 'inc_0.35'), ('snr_p10', 'inc_0.35'), ('snr_m5', 'inc_0.35')]
    for c1, c2 in pairs:
        for a in ['A1', 'plv', 'wpli', 'imcoh', 'ciplv']:
            d = paired(c1, a, c2, a)
            if d['n']:
                con[f'{c1}-{c2}:{a}'] = {k: d[k] for k in ('mean', 'lo', 'hi', 'n', 'p')}
    for c in ['inc_0.35', 'inc_0.6', 'power40', 'kura_inc_0.1', 'kura_inc_0.4', 'kura_power40', 'obs_source',
              'obs_referential', 'obs_bipolar_noart', 'lag_0', 'lag_10', 'lag_60', 'lag_90']:
        for a1, a2 in [('plv', 'wpli'), ('plv', 'imcoh'), ('A1+wpli', 'A1'), ('A1+plv', 'A1'), ('wpli+reg', 'wpli'),
                       ('plv+reg', 'plv'), ('ppc', 'wpli'), ('plv', 'ciplv')]:
            d = paired(c, a1, c, a2)
            if d['n']:
                con[f'{c}:{a1}-{a2}'] = {k: d[k] for k in ('mean', 'lo', 'hi', 'n', 'p')}
    out['contrasts'] = con
    # permutation nulls
    perm = {}
    for c in ['inc_0.35', 'inc_0.6']:
        for a in ['wpli', 'plv', 'A1+wpli']:
            ss = [s for s in seeds(c) if 'perm:' + a in R[c][s] and a in R[c][s]]
            if not ss:
                continue
            P = np.array([R[c][s]['perm:' + a] for s in ss])          # seeds x permutations
            obs = np.array([R[c][s][a]['auc'] for s in ss])
            d = obs - P.mean(1)                                        # per-seed excess over the null
            m, lo, hi = ci(d)
            rep = P.mean(0)                                            # permutation replicates of the seed mean
            perm[f'{c}:{a}'] = dict(n_seeds=len(ss), n_perm=int(P.size), perm_mean=float(P.mean()),
                                    perm_sd_single=float(P.std()), obs_mean=float(obs.mean()),
                                    excess_mean=m, excess_lo=lo, excess_hi=hi, p_wilcoxon=wilcoxon_vs(d, 0.0),
                                    p_perm_mean=float((1 + np.sum(rep >= obs.mean())) / (1 + len(rep))))
    out['permutation'] = perm
    # resampling
    rs = resampling_table()
    out['resampling'] = rs
    # event level
    ev = _load('event_level.json')
    out['event'] = event_table(ev)
    rmap = _load('regime_map.json')
    rchk = _load('regime_check.json')
    out['regime_check'] = rchk
    real = _load('eeg_real.json')
    if real:
        out['real'] = dict(entanglement={k: dict(spearman=v['spearman_alpha_power'], auc_mean=v['auc_mean'],
                                                 aucs=v['auc_power_terciles_lopo']) for k, v in real['entanglement'].items()},
                           resampling=real['resampling'], clustering=real['clustering'], records=real['records'])
    json.dump(out, open(os.path.join(RD, 'summary.json'), 'w'), indent=1, default=float)
    fig_design(); fig_sweep(); fig_power_perm(); fig_obs_lag(); fig_resampling(rs); fig_event(ev, rmap, rchk, real)
    fig_real(real)
    print('written')


if __name__ == '__main__':
    main()
