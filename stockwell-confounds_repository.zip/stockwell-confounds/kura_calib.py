"""Calibrate the Kuramoto coupling increment so that the source-level focal alpha PLV change
matches the shared-walk generator at delta_rho = 0.35 (the main effect size)."""
import numpy as np, json, sys
import sim, features as F

def focal_alpha(p, delta, amp=1.0, n_subj=6, n_win=6):
    iu0, iu1 = np.triu_indices(sim.N_SRC, 1)
    fm = sim.focal_pairs('source')
    nf = ~fm
    out = {0: [], 1: []}
    outnf = {0: [], 1: []}
    for s in range(n_subj):
        pp = dict(p); pp['observe'] = 'source'; pp['artefacts'] = False
        X, y = sim.generate_subject_windows(10_000 + s, pp, n_win, delta, amp)
        for x, c in zip(X, y):
            C = F.tf_coeffs(x.astype(np.float64), 256.0, 'stockwell', 4)
            st = F._pair_stats(C, iu0, iu1)
            plv = F.band_average(st['plv'], F.BAND_OF_VOICE)[:, 2]
            wpli = F.band_average(st['wpli'], F.BAND_OF_VOICE)[:, 2]
            out[c].append((plv[fm].mean(), wpli[fm].mean()))
            outnf[c].append((plv[nf].mean(), wpli[nf].mean()))
    r = {}
    for c in (0, 1):
        a = np.array(out[c]); b = np.array(outnf[c])
        r[c] = dict(focal_plv=a[:, 0].mean(), focal_wpli=a[:, 1].mean(), other_plv=b[:, 0].mean())
    return r

base = dict(sim.DEFAULT)
print('shared walk d=0.35', focal_alpha(base, 0.35), flush=True)
print('shared walk d=0.60', focal_alpha(base, 0.60), flush=True)
kp = dict(base); kp['generator'] = 'kuramoto'
for K0 in [0.10]:
    kp['kura_K0'] = K0
    for dK in [0.1, 0.2, 0.4]:
        print('kuramoto K0', K0, 'dK', dK, focal_alpha(kp, dK), flush=True)
