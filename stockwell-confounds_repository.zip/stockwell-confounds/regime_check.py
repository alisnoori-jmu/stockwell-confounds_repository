"""Direct-simulation check of the analytic alarm-rate model (Section 2.10).

Binary exceedance streams with a fixed marginal rate p are generated either independently
or as a two-state Markov chain with mean run length L windows (5-s windows). Alarms use the
same code as the event-level analysis (consecutive qualifying windows form one event, then a
refractory period). Output: results/regime_check.json with simulated and predicted false
alarms per hour for both rules and both refractory settings."""
import os, json
import numpy as np
from event_level import alarm_times, CONFIGS

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results', 'regime_check.json')
W_PER_H = 720
HOURS = 2000


def markov_stream(rng, p, L, n):
    if L is None:
        return rng.random(n) < p
    q = p / (L * (1 - p))                  # P(0 -> 1) giving stationary P(1) = p, mean run length L
    parts, tot = [], 0
    state = rng.random() < p
    while tot < n:
        k = 100000
        r0 = rng.geometric(q, k)
        r1 = rng.geometric(1.0 / L, k)
        runs = np.empty(2 * k, np.int64)
        if state:
            runs[0::2], runs[1::2] = r1, r0
            vals = np.tile([True, False], k)
        else:
            runs[0::2], runs[1::2] = r0, r1
            vals = np.tile([False, True], k)
        seg = np.repeat(vals, runs)
        parts.append(seg)
        tot += seg.size
    return np.concatenate(parts)[:n]


def predicted(p, L, rule, R):
    if L is None:
        lam = (1 - p) * p ** 3 if rule == '3consec' else 6 * p ** 3 * (1 - p) ** 2
    else:
        lam = (p / L) * (1 - 1 / L) ** 2
    return lam / (1 + lam * R) * W_PER_H


def main():
    rng = np.random.default_rng(20260923)
    n = HOURS * W_PER_H
    rows = []
    for p in [0.02, 0.05, 0.10, 0.20]:
        for L in [None, 6, 12, 60, 240]:
            x = markov_stream(rng, p, L, n)
            runs = np.diff(np.flatnonzero(np.diff(np.r_[0, x.astype(int), 0])))[::2]
            for cfg, (sph, sop) in CONFIGS.items():
                R = sph + sop
                for rule in ['3consec', '3of5']:
                    k = len(alarm_times(x, rule, R))
                    rows.append(dict(p=p, L=L, cfg=cfg, rule=rule, sim_fa_h=k / HOURS,
                                     pred_fa_h=predicted(p, L, rule, R), emp_p=float(x.mean()),
                                     emp_mean_run=float(runs.mean())))
                    print(rows[-1], flush=True)
    json.dump(rows, open(OUT, 'w'), indent=1)


if __name__ == '__main__':
    main()
