"""Minimal plotting style used by report.py (the figures of the revised manuscript are drawn by
revision/figures_rev.py at their printed size)."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

SERIES = ['#0072B2', '#D55E00', '#009E73', '#E69F00', '#CC79A7', '#56B4E9', '#000000', '#7F7F7F']
INK = '#222222'
INK2 = '#555555'


def apply():
    plt.rcParams.update({'font.size': 8, 'savefig.dpi': 300, 'figure.dpi': 100, 'axes.spines.top': False,
                         'axes.spines.right': False})


def panel_label(ax, lab):
    ax.text(-0.12, 1.04, lab, transform=ax.transAxes, fontweight='bold', va='bottom')
