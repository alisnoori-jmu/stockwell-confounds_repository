# Seeds and subject split

| Item | Value | Where |
|---|---|---|
| Main conditions (null, Δρ = 0.35, Δρ = 0.6, power +40 %; Table 3) | seeds 0–19 | `run_all.py` (`S20`) |
| Resampling conditions (Table 6) | seeds 0–15 | `run_all.py` (`S16`) |
| Secondary coupling levels (increase 0.1, 0.2; decrease 0.1, 0.2, 0.35), observation, nuisance and lag conditions | seeds 0–11 | `run_all.py` (`S12`) |
| Kuramoto conditions (Table 5) | seeds 0–11 | `run_kura.py` |
| Event-level experiment (Table 7; classifier from the Δρ = 0.6 features) | seeds 0–4 | `event_level.run` |
| Subjects per seed | 60 | `experiments.py` |
| Split (subject index) | train 0–35, validation 36–47, test 48–59 | `experiments.SPLIT` |
| Subject seed | first 15 hex digits of SHA-256(`"subj-{seed}-{s}"`) | `experiments.subject_seed` |
| Event-level fresh test windows | subject seed + 7; 150 interictal + 150 preictal windows | `event_level.score_windows` |
| Event-level seizure timeline | `default_rng(seed*1000 + s)` | `event_level.run` |
| Event-level score stream | `default_rng(seed*1000 + s + int(tau))` | `event_level.run` |
| Random predictor | `default_rng(seed + s)`, 200 repetitions | `event_level.run` |
| Markov validation streams | `default_rng(20260923)`, 2,000 h per setting | `regime_check.py` |
| Subject bootstrap | 5,000 resamples | `report.py` |

Subject anatomy depends only on the seed and the subject index, so every condition is evaluated on the same
simulated subjects and all between-condition differences are seed-paired.

## Seeds used in the revision

| Item | Value | Where |
|---|---|---|
| Mechanism, forward-model and frequency conditions | seeds 0–11 | `revision/runner.py` (`S12`) |
| High-frequency stress conditions | seeds 0–15 | `revision/runner.py` (`S16`) |
| Regenerated conditions (reproduction check, gradient boosting) | seeds 0–11 | `revision/runner.py` (plan `regen`; `kura_inc_0.4` in plan `r25b`) |
| Auxiliary random stream of the generator variants | `default_rng([subject seed, 20261016])` | `revision/sim_ext.py` |
| Gradient boosting | `random_state = seed` | `revision/runner.py` |
| Hierarchical bootstrap | `default_rng(1)`, 5,000 resamples (subject bootstrap `default_rng(0)`) | `revision/event_boot.py` |
| Firing-power analysis | same streams as `event_level.run` | `revision/event_fp.py` |
| Signal-level error power | seeds 0–3, test subjects 48–59, 16 windows each | `revision/alias_signal.py` |
