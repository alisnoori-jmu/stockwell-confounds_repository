"""Condition definitions and the feature-generation runner.

Each (condition, seed) produces one .npz of window features for N_SUBJ simulated subjects
(split 36 train / 12 validation / 12 test, as in the original protocol). Subject anatomy is
drawn from a seed that depends only on (seed, subject index), so every condition sees the
same simulated people (common random numbers), which makes paired comparisons tighter.
"""
import os, sys, json, time, hashlib
import numpy as np
from multiprocessing import Pool
import sim, features as F

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results', 'features')
os.makedirs(OUT, exist_ok=True)
N_SUBJ = 60
N_PER_CLASS = 8
SPLIT = dict(train=range(0, 36), val=range(36, 48), test=range(48, 60))


def cond(name, **kw):
    base = dict(delta_rho=0.0, amp_mult=1.0, direction=+1, params={}, kinds=['stockwell'],
                native_fs=None, n_per_class=N_PER_CLASS)
    base.update(kw)
    base['name'] = name
    return base


CONDITIONS = {}
for d in [0.0, 0.1, 0.2, 0.35, 0.6]:
    CONDITIONS[f'inc_{d}'] = cond(f'inc_{d}', delta_rho=d,
                                  kinds=['stockwell', 'morlet7', 'hilbert'] if d in (0.35, 0.6) else ['stockwell'])
for d in [0.1, 0.2, 0.35]:
    CONDITIONS[f'dec_{d}'] = cond(f'dec_{d}', delta_rho=d, direction=-1)
CONDITIONS['power40'] = cond('power40', amp_mult=np.sqrt(1.4), kinds=['stockwell', 'morlet7', 'hilbert'])
# observation-model decomposition at delta_rho = 0.35
CONDITIONS['obs_source'] = cond('obs_source', delta_rho=0.35, params=dict(observe='source', artefacts=False))
CONDITIONS['obs_referential'] = cond('obs_referential', delta_rho=0.35, params=dict(observe='referential', artefacts=False))
CONDITIONS['obs_bipolar_noart'] = cond('obs_bipolar_noart', delta_rho=0.35, params=dict(artefacts=False))
# nuisance perturbations at delta_rho = 0.35
CONDITIONS['snr_p10'] = cond('snr_p10', delta_rho=0.35, params=dict(snr_db=10.0))
CONDITIONS['snr_m5'] = cond('snr_m5', delta_rho=0.35, params=dict(snr_db=-5.0))
CONDITIONS['hetero2'] = cond('hetero2', delta_rho=0.35, params=dict(hetero=2.0))
# lag sweep at delta_rho = 0.35 (default lag SD = 30 deg is inc_0.35)
for lag in [0.0, 10.0, 60.0, 90.0]:
    CONDITIONS[f'lag_{int(lag)}'] = cond(f'lag_{int(lag)}', delta_rho=0.35, params=dict(lag_sd_deg=lag))
# lag sweep null checks (zero-lag coupling with no change must stay at chance)
CONDITIONS['lag_0_null'] = cond('lag_0_null', delta_rho=0.0, params=dict(lag_sd_deg=0.0))
# independent generator: noisy Kuramoto oscillators (coupling increment dK in rad/s; dK = 0.1 and 0.4
# match the source-level focal alpha-PLV change of delta_rho = 0.35 and 0.6 in the shared-walk model)
KURA = dict(generator='kuramoto')
CONDITIONS['kura_null'] = cond('kura_null', delta_rho=0.0, params=KURA)
CONDITIONS['kura_inc_0.1'] = cond('kura_inc_0.1', delta_rho=0.1, params=KURA)
CONDITIONS['kura_inc_0.4'] = cond('kura_inc_0.4', delta_rho=0.4, params=KURA)
CONDITIONS['kura_power40'] = cond('kura_power40', amp_mult=np.sqrt(1.4), params=KURA)
# native-rate resampling at delta_rho = 0.35
for fsn in [250, 400, 512, 1000]:
    CONDITIONS[f'rs_{fsn}'] = cond(f'rs_{fsn}', delta_rho=0.35, native_fs=fsn, params=dict(fs=float(fsn)))


def subject_seed(seed, s):
    h = hashlib.sha256(f'subj-{seed}-{s}'.encode()).hexdigest()
    return int(h[:15], 16)


def _features_for(x, fs, mode, kind):
    lm = sim.local_pairs(mode)
    chain = sim.CHAIN if mode == 'bipolar' else None
    return F.window_features(x, fs, lm, chain, kind)


def run_one(args):
    cname, seed = args
    c = CONDITIONS[cname]
    path = os.path.join(OUT, f'{cname}__s{seed}.npz')
    if os.path.exists(path):
        return path
    p = dict(sim.DEFAULT); p.update(c['params'])
    mode = p['observe']
    blocks = {}
    ys, subj = [], []
    t0 = time.time()
    for s in range(N_SUBJ):
        X, y = sim.generate_subject_windows(subject_seed(seed, s), p, c['n_per_class'],
                                            c['delta_rho'], c['amp_mult'], c['direction'])
        for i in range(X.shape[0]):
            paths = {}
            if c['native_fs'] is None:
                paths[''] = (X[i], p['fs'])
            else:
                paths['bench_'] = (F.benchmark_uniformise(X[i], c['native_fs']), 256.0)
                paths['ref_'] = (F.reference_uniformise(X[i], c['native_fs']), 256.0)
            for pre, (xx, fs) in paths.items():
                for kind in c['kinds']:
                    fe = _features_for(xx, fs, mode, kind)
                    tag = '' if kind == 'stockwell' else kind + ':'
                    for k, v in fe.items():
                        blocks.setdefault(pre + tag + k, []).append(v.astype(np.float32))
        ys.append(y); subj.append(np.full(len(y), s))
    np.savez_compressed(path, y=np.concatenate(ys), subj=np.concatenate(subj),
                        **{k: np.stack(v) for k, v in blocks.items()},
                        _meta=json.dumps(dict(cond=cname, seed=seed, secs=time.time() - t0)))
    return path


def run(conds, seeds, procs=2):
    jobs = [(c, s) for c in conds for s in seeds]
    jobs = [j for j in jobs if not os.path.exists(os.path.join(OUT, f'{j[0]}__s{j[1]}.npz'))]
    t0 = time.time()
    with Pool(procs) as pool:
        for i, path in enumerate(pool.imap_unordered(run_one, jobs)):
            print(f'[{i + 1}/{len(jobs)}] {os.path.basename(path)}  {time.time() - t0:.0f}s', flush=True)


if __name__ == '__main__':
    conds = sys.argv[1].split(',')
    seeds = [int(s) for s in sys.argv[2].split(',')] if ',' in sys.argv[2] else list(range(int(sys.argv[2])))
    run(conds, seeds)
