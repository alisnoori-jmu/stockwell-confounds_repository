import experiments as E
S20 = list(range(20)); S16 = list(range(16)); S12 = list(range(12))
plan = [
  (['inc_0.0','inc_0.35','inc_0.6','power40'], S20),
  (['rs_512','rs_1000','rs_400','rs_250'], S16),
  (['obs_source','obs_referential','obs_bipolar_noart'], S12),
  (['lag_0','lag_10','lag_60','lag_90','lag_0_null'], S12),
  (['inc_0.1','inc_0.2','dec_0.1','dec_0.2','dec_0.35'], S12),
  (['snr_p10','snr_m5','hetero2'], S12),
]
for conds, seeds in plan:
    print('=== ', conds, flush=True)
    E.run(conds, seeds)
print('ALL DONE', flush=True)
