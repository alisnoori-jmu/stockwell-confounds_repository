"""Real-EEG checks on seizure-free CHB-MIT recordings (no seizure labels needed).

(a) Power-phase entanglement: how strongly each phase index tracks window band power.
(b) Resampling: 256 -> 128 Hz by sample picking vs anti-aliased polyphase decimation.
(c) Temporal clustering of window-level exceedances and its effect on alarm rules,
    compared with the same exceedances randomly permuted (i.i.d. at the same rate).
"""
import os, sys, json, glob
import numpy as np
import pyedflib
from scipy import signal, stats
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
import features as F

CHB_DB = ['FP1-F7', 'F7-T7', 'T7-P7', 'P7-O1', 'FP1-F3', 'F3-C3', 'C3-P3', 'P3-O1',
          'FP2-F4', 'F4-C4', 'C4-P4', 'P4-O2', 'FP2-F8', 'F8-T8', 'T8-P8', 'P8-O2', 'FZ-CZ', 'CZ-PZ']
CHAIN = np.array([0] * 4 + [1] * 4 + [2] * 4 + [3] * 4 + [4] * 2)
WIN = 5.0


def load_edf(path):
    f = pyedflib.EdfReader(path)
    labels = [l.strip().upper() for l in f.getSignalLabels()]
    fs = f.getSampleFrequency(0)
    idx = []
    for ch in CHB_DB:
        # first occurrence; duplicated derivations may carry a suffix (e.g. 'T8-P8-0', 'T8-P8-1')
        k = next(i for i, l in enumerate(labels) if l == ch or (l.startswith(ch + '-') and l[len(ch) + 1:].isdigit()))
        idx.append(k)
    if any(f.getSampleFrequency(k) != fs for k in idx):
        raise ValueError('mixed sampling rates')
    X = np.vstack([f.readSignal(k) for k in idx])
    f.close()
    return X, fs


def windows(X, fs, win=WIN):
    n = int(win * fs)
    m = X.shape[1] // n
    return X[:, :m * n].reshape(X.shape[0], m, n).transpose(1, 0, 2)


def local_mask(chain):
    iu = np.triu_indices(len(chain), 1)
    return chain[iu[0]] == chain[iu[1]]


def features_for_record(X, fs):
    W = windows(X, fs)
    lm = local_mask(CHAIN)
    feats = [F.window_features(w, fs, lm, CHAIN) for w in W]
    keys = feats[0].keys()
    return {k: np.stack([f[k] for f in feats]) for k in keys}, W


def line_length(W):
    return np.abs(np.diff(W, axis=-1)).sum(-1).mean(-1)


def run_lengths(x):
    runs, r = [], 0
    for v in x:
        if v:
            r += 1
        elif r:
            runs.append(r); r = 0
    if r:
        runs.append(r)
    return np.array(runs)


def alarms(x, rule, R=84):
    x = x.astype(int)
    if rule == '3consec':
        c = np.zeros(len(x), bool); c[2:] = (x[2:] & x[1:-1] & x[:-2]).astype(bool)
    else:
        s = np.convolve(x, np.ones(5, int), 'full')[:len(x)]; c = s >= 3
    onsets = np.flatnonzero(c & ~np.r_[False, c[:-1]])
    n, last = 0, -10 ** 9
    for t in onsets:
        if t >= last + R:
            n += 1; last = t
    return n


def main(data_dir, out_json):
    files = sorted(glob.glob(os.path.join(data_dir, '**', 'chb*.edf'), recursive=True))
    res = dict(files=[os.path.basename(f) for f in files], records=[])
    all_feats, all_pow, all_pid = [], [], []
    rs_rows = []
    clus = []
    for f in files:
        pid = os.path.basename(f).split('_')[0]
        X, fs = load_edf(f)
        X = X - X.mean(axis=1, keepdims=True)
        fe, W = features_for_record(X, fs)
        n_w = W.shape[0]
        alpha_pow = fe['A1'].reshape(n_w, len(CHB_DB), 5)[:, :, 2].mean(1)
        all_feats.append(fe); all_pow.append(alpha_pow); all_pid += [pid] * n_w
        # (b) resampling: pick 1 of 2 vs anti-aliased
        Xp = X[:, ::2]
        Xf = signal.resample_poly(X, 1, 2, axis=1)
        fp, _ = features_for_record(Xp, fs / 2)
        ff, _ = features_for_record(Xf, fs / 2)
        f_hi = np.fft.rfftfreq(W.shape[-1], 1 / fs)
        P = (np.abs(np.fft.rfft(W, axis=-1)) ** 2).mean(axis=(0, 1))
        alias_frac = float(P[f_hi >= fs / 4].sum() / P[f_hi > 0.5].sum())
        rs_rows.append(dict(file=os.path.basename(f), alias_energy_frac=alias_frac,
                            **{f'mad_{k}': float(np.median(np.abs(fp['A3_' + k] - ff['A3_' + k]) /
                                                            (np.abs(ff['A3_' + k]) + 1e-9)))
                               for k in F.INDICES},
                            **{f'corr_{k}': float(np.median([stats.spearmanr(fp['A3_' + k][:, c], ff['A3_' + k][:, c])[0]
                                                             for c in range(15)])) for k in F.INDICES}))
        # (c) clustering of exceedances for several window scores
        scores = dict(line_length=line_length(W), alpha_power=alpha_pow,
                      alpha_plv=fe['A3_plv'][:, 2], alpha_wpli=fe['A3_wpli'][:, 2],
                      beta_power=fe['A1'].reshape(n_w, len(CHB_DB), 5)[:, :, 3].mean(1))
        rng = np.random.default_rng(0)
        for sname, s in scores.items():
            thr = np.quantile(s, 0.98)
            x = s > thr
            rl = run_lengths(x)
            hours = n_w * WIN / 3600
            real = {r: alarms(x, r) / hours for r in ('3consec', '3of5')}
            shuf = {r: np.mean([alarms(rng.permutation(x), r) for _ in range(200)]) / hours for r in ('3consec', '3of5')}
            ac = float(np.corrcoef(s[:-1], s[1:])[0, 1])
            pp = float(x.mean())
            L = float(rl.mean()) if len(rl) else 0.0
            lam_iid = {'3consec': (1 - pp) * pp ** 3, '3of5': 6 * pp ** 3 * (1 - pp) ** 2}
            lam_m = (pp / L) * (1 - 1 / L) ** 2 if L > 1 else 0.0
            pred = {r: (lam / (1 + lam * 84)) * 720 for r, lam in lam_iid.items()}
            pred_m = lam_m / (1 + lam_m * 84) * 720
            clus.append(dict(file=os.path.basename(f), score=sname, p=pp,
                             mean_run=L, max_run=int(rl.max()) if len(rl) else 0, n_runs=int(len(rl)),
                             lag1_autocorr=ac, tau_eff_s=float(-WIN / np.log(ac)) if 0 < ac < 1 else np.nan,
                             fa_real_3consec=real['3consec'], fa_iid_3consec=shuf['3consec'],
                             fa_real_3of5=real['3of5'], fa_iid_3of5=shuf['3of5'],
                             pred_iid_3consec=pred['3consec'], pred_iid_3of5=pred['3of5'], pred_markov=pred_m))
        res['records'].append(dict(file=os.path.basename(f), fs=fs, hours=n_w * WIN / 3600, windows=n_w))
        print(os.path.basename(f), 'done', flush=True)
    # (a) power-phase entanglement across all windows (within-record terciles, leave-one-patient-out)
    pids = np.array(all_pid)
    pw = np.concatenate(all_pow)
    fe_all = {k: np.concatenate([f[k] for f in all_feats]) for k in all_feats[0]}
    rec_id = np.concatenate([np.full(len(p), i) for i, p in enumerate(all_pow)])
    lab = np.full(len(pw), -1)
    for r in np.unique(rec_id):
        m = rec_id == r
        lo, hi = np.quantile(pw[m], [1 / 3, 2 / 3])
        lab[m & (pw <= lo)] = 0
        lab[m & (pw >= hi)] = 1
    ent = {}
    for k in F.INDICES:
        X = fe_all['A3_' + k]
        corr = float(np.median([stats.spearmanr(pw, X[:, 2])[0]]))   # alpha-band mean over pairs
        aucs = []
        for p in np.unique(pids):
            tr = (pids != p) & (lab >= 0); te = (pids == p) & (lab >= 0)
            sc = StandardScaler().fit(X[tr])
            m = LogisticRegression(C=1.0, max_iter=3000).fit(sc.transform(X[tr]), lab[tr])
            aucs.append(roc_auc_score(lab[te], m.decision_function(sc.transform(X[te]))))
        ent[k] = dict(spearman_alpha_power=corr, auc_power_terciles_lopo=aucs, auc_mean=float(np.mean(aucs)))
    res['entanglement'] = ent
    res['resampling'] = rs_rows
    res['clustering'] = clus
    json.dump(res, open(out_json, 'w'), indent=1)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
