"""Signal-level check of the benchmark resampling operations (Reviewer 2, comment 5).

For each native rate the MLSPred-bench operation (sample picking, zero padding to 1280 samples, read as
256 Hz) is compared with an anti-aliased resampler that puts the signal on exactly the same nominal
sample grid (polyphase decimation to the effective rate of the picked samples, followed by the same
zero padding). Their difference is the error introduced by picking without an anti-aliasing filter
(aliasing, plus timing jitter for the 5-of-8 pattern at 400 Hz). It is reported as the in-band error
power relative to the in-band power of the anti-aliased signal (dB), over 1-45 Hz and in the alpha band,
for bipolar channels of simulated windows of the test subjects.
Usage: python alias_signal.py <repo> <out.json>
"""
import json, os, sys
import numpy as np
from scipy import signal
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, sys.argv[1]]
import kernels, sim_ext
kernels.install(); sim_ext.install()
import sim, features as F
from experiments import subject_seed

CONDS = {
    'rs_250': dict(fs=250.0),
    'rs_400': dict(fs=400.0),
    'rs_512': dict(fs=512.0),
    'rs_1000': dict(fs=1000.0),
    'rsx_1000_emg4': dict(fs=1000.0, emg=1.20),
    'rsx_1000_mains60': dict(fs=1000.0, mains_f=60.0, mains_harm='1/k', mains=0.50),
    'rsx_1000_mains60_x4': dict(fs=1000.0, mains_f=60.0, mains_harm='1/k', mains=2.00),
}
IDEAL = {250: (1, 1), 400: (5, 8), 512: (1, 2), 1000: (1, 4)}   # up, down to the effective picked rate


def ideal_grid(x, fs):
    up, down = IDEAL[int(fs)]
    y = x if (up, down) == (1, 1) else signal.resample_poly(x, up, down, axis=-1)
    n = y.shape[-1]
    if n < 1280:
        pad = 1280 - n
        y = np.pad(y, ((0, 0), (pad // 2, pad - pad // 2)))
    return y[:, :1280]


f = np.fft.rfftfreq(1280, 1 / 256.0)
INB = (f >= 1) & (f <= 45)
ALPHA = (f >= 8) & (f < 13)
out = {}
for cname, extra in (CONDS.items() if __name__ == "__main__" else []):
    p = dict(sim.DEFAULT); p.update(extra)
    fs = p['fs']
    e_in, i_in, e_al, i_al, per_win = 0.0, 0.0, 0.0, 0.0, []
    for seed in range(4):
        for s in range(48, 60):                                  # test subjects
            X, y = sim.generate_subject_windows(subject_seed(seed, s), p, 8, 0.35)
            for x in X.astype(np.float64):
                b = F.benchmark_uniformise(x, fs)
                r = ideal_grid(x, fs)
                Pe = np.abs(np.fft.rfft(b - r, axis=-1)) ** 2
                Pi = np.abs(np.fft.rfft(r, axis=-1)) ** 2
                e_in += Pe[:, INB].sum(); i_in += Pi[:, INB].sum()
                e_al += Pe[:, ALPHA].sum(); i_al += Pi[:, ALPHA].sum()
                per_win.append(10 * np.log10(Pe[:, INB].sum() / Pi[:, INB].sum() + 1e-30))
    pw = np.array(per_win)
    out[cname] = dict(inband_db=float(10 * np.log10(e_in / i_in + 1e-30)),
                      alpha_db=float(10 * np.log10(e_al / i_al + 1e-30)),
                      win_db_median=float(np.median(pw)), win_db_p90=float(np.quantile(pw, 0.9)),
                      win_db_max=float(pw.max()), n_windows=int(len(pw)))
    print(cname, out[cname], flush=True)
if __name__ == '__main__':
    json.dump(out, open(sys.argv[2], 'w'), indent=1)
