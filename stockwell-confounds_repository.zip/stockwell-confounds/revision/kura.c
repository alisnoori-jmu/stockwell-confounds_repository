/* Euler-Maruyama integration of Eq. (2): identical arithmetic and summation order to sim._kuramoto_integrate. */
#include <math.h>
void kura(const double *th0, const double *w, const double *K, const double *noise, double dt,
          int nb, int n, int m, double *out) {
    double th[64], nw[64];
    for (int k = 0; k < m; k++) th[k] = th0[k];
    for (int t = 0; t < nb + n; t++) {
        for (int k = 0; k < m; k++) {
            double s = 0.0;
            for (int j = 0; j < m; j++) s += K[k * m + j] * sin(th[j] - th[k]);
            nw[k] = th[k] + (w[k] + s) * dt + noise[t * m + k];
        }
        for (int k = 0; k < m; k++) th[k] = nw[k];
        if (t >= nb) for (int k = 0; k < m; k++) out[(t - nb) * m + k] = th[k];
    }
}
