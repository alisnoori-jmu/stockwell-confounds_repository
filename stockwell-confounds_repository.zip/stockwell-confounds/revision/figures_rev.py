"""Figures of the revised manuscript, drawn at their printed size (IJIES rules: text >= 10 pt, no panel
letters inside figures, no outer border, one figure per image; multi-part figures are separate images
stacked in the page and labelled (a), (b), ... in the text below each image).

Usage: python figures_rev.py <repo dir> <work dir> <out dir>
Inputs : <repo>/results/auc.json, event_level.json, regime_check.json (original runs)
         <work>/results/aggregate.json (revision runs; optional parts are skipped when missing)
Output : PNG at 600 dpi; the physical size of each file is its printed size.
"""
import json, os, sys
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch
from matplotlib.lines import Line2D

REPO, WORK, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, os.path.join(REPO, 'appendix_a'))
import alarm_exact as AX

FS = 10                                  # minimum font size at print size
COL = 8.2 / 2.54                         # column width (in)
FULL = 17.0 / 2.54                       # text width (in)
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Liberation Serif', 'TeX Gyre Termes', 'DejaVu Serif'],
    'mathtext.fontset': 'stix', 'font.size': FS, 'axes.labelsize': FS, 'axes.titlesize': FS,
    'xtick.labelsize': FS, 'ytick.labelsize': FS, 'legend.fontsize': FS, 'legend.title_fontsize': FS,
    'axes.linewidth': 0.8, 'xtick.major.width': 0.8, 'ytick.major.width': 0.8, 'lines.linewidth': 1.3,
    'lines.markersize': 4.5, 'legend.frameon': False, 'legend.handlelength': 1.8, 'legend.borderaxespad': 0.2,
    'legend.columnspacing': 1.0, 'legend.handletextpad': 0.4, 'axes.spines.top': False, 'axes.spines.right': False,
    'savefig.dpi': 600, 'figure.dpi': 100, 'axes.grid': True, 'grid.color': '#e4e4e4', 'grid.linewidth': 0.6,
})
# Okabe-Ito palette; every feature keeps its colour, marker and line style in all figures
OI = ['#0072B2', '#D55E00', '#009E73', '#E69F00', '#CC79A7', '#56B4E9', '#000000', '#7F7F7F']
STY = {
    'A1': dict(c=OI[0], m='o', ls='-', lab='Band power (A1)'),
    'plv': dict(c=OI[1], m='s', ls='--', lab='PLV'),
    'ppc': dict(c=OI[4], m='P', ls=(0, (3, 1, 1, 1)), lab='PPC'),
    'wpli': dict(c=OI[2], m='^', ls='-.', lab='wPLI'),
    'imcoh': dict(c=OI[3], m='D', ls=':', lab='|ImCoh|'),
    'dwpli': dict(c=OI[5], m='v', ls=(0, (5, 1)), lab='dwPLI'),
    'ciplv': dict(c=OI[6], m='X', ls=(0, (1, 1)), lab='ciPLV'),
    'A2': dict(c=OI[7], m='*', ls='--', lab='Absolute phase (A2)'),
}
R = json.load(open(os.path.join(REPO, 'results', 'auc.json')))
AGG_P = os.path.join(WORK, 'results', 'aggregate.json')
AGG = json.load(open(AGG_P)) if os.path.exists(AGG_P) else None


def vals(c, a):
    d = R.get(c, {})
    return np.array([d[s][a]['auc'] for s in sorted(d, key=int) if a in d[s]])


def ci(v, level=0.95):
    v = np.asarray(v, float)
    m = v.mean()
    h = stats.t.ppf(0.5 + level / 2, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return m, m - h, m + h


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + '.png'), dpi=600)
    plt.close(fig)
    print('wrote', name)


def chance(ax, horizontal=True):
    (ax.axhline if horizontal else ax.axvline)(0.5, color='#555555', lw=0.8, ls=':', zorder=1)


# ====================================================================== Fig. 1: processing chain
def fig1():
    fig = plt.figure(figsize=(FULL, 2.75))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 41); ax.axis('off')
    top = [('Sources', ['8 sources, Eq. (1)', 'or Eq. (2); alpha', 'rhythm + 1/f noise']),
           ('Lead field', ['Gaussian, width', '0.35 head radii;', '17 electrodes']),
           ('Artefacts', ['EMG, mains and', 'pops; sensor noise', '(SNR 5 dB)']),
           ('Montage', ['20 bipolar', 'TCP channels', '(MLSPred-bench)']),
           ('Resampling', ['native rate to', '256 Hz (resampling', 'tests only)'])]
    bot = [('Time-frequency', ['Stockwell, Morlet', 'or Hilbert;', '29 voices']),
           ('Features', ['A1 band power,', 'A2 absolute phase,', 'A3 six indices']),
           ('Classifier', ['L2 logistic', 'regression, C from', 'validation subjects']),
           ('Window scores', ['test AUROC;', 'score streams', 'of test subjects']),
           ('Alarm rules', ['3 of 5, 3 consec.,', 'firing power;', 'refractory period'])]
    w, h, gap = 17.6, 16.5, 2.5
    xs = [1 + i * (w + gap) for i in range(5)]
    for row, y in [(top, 23.5), (bot, 1.0)]:
        for i, (title, lines) in enumerate(row):
            x = xs[i]
            ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0,rounding_size=1.2', fc='#f2f6fb',
                                        ec='#3d5a80', lw=0.9))
            ax.text(x + w / 2, y + h - 2.6, title, ha='center', va='center', fontsize=FS, fontweight='bold')
            for k, ln in enumerate(lines):
                ax.text(x + w / 2, y + h - 6.9 - 3.6 * k, ln, ha='center', va='center', fontsize=FS)
            if i < 4:
                ax.annotate('', xy=(xs[i + 1] - 0.3, y + h / 2), xytext=(x + w + 0.3, y + h / 2),
                            arrowprops=dict(arrowstyle='-|>', color='#222222', lw=0.9, mutation_scale=9))
    # connector from the last box of the top row to the first box of the bottom row
    ymid = (1.0 + h + 23.5) / 2
    ax.plot([xs[4] + w / 2, xs[4] + w / 2, xs[0] + w / 2], [23.5 - 0.3, ymid, ymid], color='#222222', lw=0.9)
    ax.annotate('', xy=(xs[0] + w / 2, 1.0 + h + 0.3), xytext=(xs[0] + w / 2, ymid),
                arrowprops=dict(arrowstyle='-|>', color='#222222', lw=0.9, mutation_scale=9))
    save(fig, 'fig01_chain')


# ====================================================================== Fig. 2: alarm definition
def fig2():
    fig = plt.figure(figsize=(FULL, 1.95))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(-6, 104); ax.set_ylim(-17, 20); ax.axis('off')
    x0, x1, x2 = 0, 28, 82                          # alarm, end of SPH, end of SOP
    ax.add_patch(Rectangle((x0, 0), x1 - x0, 9, fc='#e3f0dc', ec='#4b8b3b', hatch='///', lw=0.9))
    ax.add_patch(Rectangle((x1, 0), x2 - x1, 9, fc='#dceaf8', ec='#2f6db5', lw=0.9))
    ax.text((x0 + x1) / 2, 4.5, 'SPH: no seizure expected', ha='center', va='center', fontsize=FS,
            bbox=dict(fc='white', ec='none', pad=0.6))
    ax.text((x1 + x2) / 2, 4.5, 'SOP: a seizure onset here makes the alarm correct', ha='center', va='center',
            fontsize=FS)
    ax.annotate('', xy=(100, -2), xytext=(-4, -2), arrowprops=dict(arrowstyle='-|>', color='black', lw=0.9))
    ax.text(100, -5.0, 'time', ha='right', va='center', fontsize=FS)
    for x in (x0, x1, x2):
        ax.plot([x, x], [-2, 12], color='black', lw=0.8, ls='--')
    ax.plot([x0], [13.5], marker='v', color='black', ms=7)
    ax.text(x0 + 1.0, 16.5, 'alarm at $t_a$', ha='left', va='center', fontsize=FS)
    ax.text(x0, -5.0, '$t_a$', ha='center', va='center', fontsize=FS)
    ax.text(x1, -5.0, '$t_a$ + SPH', ha='center', va='center', fontsize=FS)
    ax.text(x2, -5.0, '$t_a$ + SPH + SOP', ha='center', va='center', fontsize=FS)
    ax.annotate('', xy=(x2, -11), xytext=(x0, -11), arrowprops=dict(arrowstyle='<->', color='#9b1c1c', lw=0.9))
    ax.text((x0 + x2) / 2, -14.2, 'refractory period after each alarm: $R$ = SPH + SOP (no new alarm is raised)',
            ha='center', va='center', fontsize=FS, color='#9b1c1c')
    save(fig, 'fig02_alarm')


# ====================================================================== Fig. 3: window labels around a seizure
def fig3():
    fig = plt.figure(figsize=(FULL, 1.75))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(-4, 104); ax.set_ylim(-12, 19); ax.axis('off')
    a, b, s, c = 22, 52, 66, 92                      # ts-SPH-SOP, ts-SPH, ts, ts+30 min
    ax.add_patch(Rectangle((0, 0), a, 9, fc='#efefef', ec='#333333', lw=0.9))
    ax.add_patch(Rectangle((a, 0), b - a, 9, fc='#dceaf8', ec='#2f6db5', lw=0.9))
    ax.add_patch(Rectangle((b, 0), c - b, 9, fc='#fbe3e3', ec='#c0392b', hatch='///', lw=0.9))
    ax.text(a / 2, 4.5, 'interictal (0)', ha='center', va='center', fontsize=FS)
    ax.text((a + b) / 2, 4.5, 'preictal (1)', ha='center', va='center', fontsize=FS)
    ax.text((b + c) / 2, 4.5, 'excluded', ha='center', va='center', fontsize=FS, bbox=dict(fc='white', ec='none', pad=0.6))
    ax.add_patch(Rectangle((c, 0), 8, 9, fc='#efefef', ec='#333333', lw=0.9))
    ax.text(c + 4, 4.5, '(0)', ha='center', va='center', fontsize=FS)
    ax.annotate('', xy=(102, -2), xytext=(-2, -2), arrowprops=dict(arrowstyle='-|>', color='black', lw=0.9))
    for x in (a, b, c):
        ax.plot([x, x], [-2, 11], color='black', lw=0.8, ls='--')
    ax.plot([s, s], [-2, 13], color='#c0392b', lw=1.6)
    ax.text(s, 15.5, 'seizure onset $t_s$', ha='center', va='center', fontsize=FS, color='#c0392b')
    for x, lab in [(a, '$t_s$ − SPH − SOP'), (b, '$t_s$ − SPH'), (s, '$t_s$'), (c, '$t_s$ + 30 min')]:
        ax.text(x, -5.5, lab, ha='center', va='center', fontsize=FS)
    ax.text(102, -9.5, 'time', ha='right', va='center', fontsize=FS)
    save(fig, 'fig03_labels')


# ====================================================================== Fig. 4: AUROC versus coupling change
def fig4():
    arms = ['A1', 'plv', 'ppc', 'wpli', 'imcoh', 'ciplv', 'A2']
    xs = [-0.35, -0.2, -0.1, 0.0, 0.1, 0.2, 0.35, 0.6]
    cn = {-0.35: 'dec_0.35', -0.2: 'dec_0.2', -0.1: 'dec_0.1', 0.0: 'inc_0.0', 0.1: 'inc_0.1', 0.2: 'inc_0.2',
          0.35: 'inc_0.35', 0.6: 'inc_0.6'}
    fig, ax = plt.subplots(figsize=(COL, 3.55), constrained_layout=True)
    for j, a in enumerate(arms):
        st = STY[a]
        pts = np.array([ci(vals(cn[x], a)) for x in xs])
        off = (j - 3) * 0.006
        ax.errorbar(np.array(xs) + off, pts[:, 0], yerr=[pts[:, 0] - pts[:, 1], pts[:, 2] - pts[:, 0]], color=st['c'],
                    marker=st['m'], ls=st['ls'], capsize=1.8, lw=1.1, ms=4, elinewidth=0.8, label=st['lab'])
    chance(ax)
    ax.axvline(0, color='#999999', lw=0.6)
    ax.set_xlabel(r'Change of focal coupling, $\Delta\rho$ (negative: decrease)')
    ax.set_ylabel('Test AUROC (mean, 95% CI)')
    ax.set_xticks([-0.35, -0.2, -0.1, 0, 0.1, 0.2, 0.35, 0.6])
    ax.set_xticklabels(['−0.35', '−0.2', '', '0', '', '0.2', '0.35', '0.6'])
    ax.legend(loc='upper center', bbox_to_anchor=(0.45, -0.25), ncol=2)
    save(fig, 'fig04_coupling')


# ====================================================================== Fig. 5: power-only control and permutation null
def fig5():
    arms = ['A1', 'plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'A2']
    short = dict(A1='A1', A2='A2', plv='PLV', ppc='PPC', imcoh='|ImCoh|', wpli='wPLI', dwpli='dwPLI', ciplv='ciPLV')
    fig, ax = plt.subplots(figsize=(COL, 2.75), constrained_layout=True)
    for i, a in enumerate(arms):
        st = STY[a]
        for cond, off, fill in [('power40', -0.17, True), ('inc_0.35', 0.17, False)]:
            m, lo, hi = ci(vals(cond, a))
            ax.errorbar(i + off, m, yerr=[[m - lo], [hi - m]], color=st['c'], marker='o', ms=4.5,
                        mfc=st['c'] if fill else 'white', mec=st['c'], capsize=1.8, ls='none', lw=1.0)
    chance(ax)
    ax.set_xticks(range(len(arms))); ax.set_xticklabels([short[a] for a in arms], rotation=45, ha='right',
                                                          rotation_mode='anchor')
    ax.set_ylabel('Test AUROC (95% CI)')
    ax.legend(handles=[Line2D([], [], color='#444444', marker='o', ls='none', label='power only (+40%)'),
                       Line2D([], [], color='#444444', marker='o', ls='none', mfc='white',
                              label=r'coupling only ($\Delta\rho$ = 0.35)')], loc='upper right')
    save(fig, 'fig05a_power_only')

    fig, ax = plt.subplots(figsize=(COL, 2.75), constrained_layout=True)
    rows = [('wpli', 'wPLI'), ('plv', 'PLV'), ('A1+wpli', 'A1+wPLI')]
    k, ticks, tl, groups = 0, [], [], []
    for cond, cl in [('inc_0.35', r'$\Delta\rho$ = 0.35'), ('inc_0.6', r'$\Delta\rho$ = 0.6')]:
        k0 = k
        for arm, lab in rows:
            ss = [s for s in sorted(R[cond], key=int) if 'perm:' + arm in R[cond][s]]
            obs = np.array([R[cond][s][arm]['auc'] for s in ss])
            perm = np.array([R[cond][s]['perm:' + arm] for s in ss]).mean(0)
            col = STY['wpli']['c'] if arm == 'wpli' else STY['plv']['c'] if arm == 'plv' else '#333333'
            parts = ax.violinplot([perm], positions=[k], widths=0.7, showextrema=False)
            for b in parts['bodies']:
                b.set_facecolor('#cfcfcf'); b.set_edgecolor('none'); b.set_alpha(1)
            m, lo, hi = ci(obs)
            ax.errorbar(k, m, yerr=[[m - lo], [hi - m]], color=col, marker='o', ms=4.5, capsize=1.8, lw=1.0)
            ticks.append(k); tl.append(lab); k += 1
        groups.append(((k0 + k - 1) / 2, cl)); k += 0.6
    chance(ax)
    ax.set_xticks(ticks); ax.set_xticklabels(tl, rotation=45, ha='right', rotation_mode='anchor')
    for x, cl in groups:
        ax.text(x, 0.885, cl, ha='center', va='top', fontsize=FS)
    ax.set_ylabel('Test AUROC'); ax.set_ylim(0.45, 0.9)
    ax.legend(handles=[Line2D([], [], color='#bdbdbd', lw=6, label='permutation null'),
                       Line2D([], [], color='#444444', marker='o', ls='none', label='observed (95% CI)')],
              loc='center left', bbox_to_anchor=(0.0, 0.62))
    save(fig, 'fig05b_permutation')


# ====================================================================== Fig. 6: observation model and lag spread
def fig6():
    arms = ['A1', 'plv', 'wpli', 'imcoh']
    conds = [('obs_source', 'Sources'), ('obs_referential', 'Referential'), ('obs_bipolar_noart', 'Bipolar,\nno artefacts'),
             ('inc_0.35', 'Bipolar,\nartefacts')]
    fig, ax = plt.subplots(figsize=(COL, 2.85), constrained_layout=True)
    for j, a in enumerate(arms):
        st = STY[a]
        pts = np.array([ci(vals(c, a)) for c, _ in conds])
        x = np.arange(len(conds)) + (j - 1.5) * 0.08
        ax.errorbar(x, pts[:, 0], yerr=[pts[:, 0] - pts[:, 1], pts[:, 2] - pts[:, 0]], color=st['c'], marker=st['m'],
                    ls=st['ls'], capsize=1.8, lw=1.1, ms=4, label=st['lab'])
    chance(ax)
    ax.set_xticks(range(len(conds))); ax.set_xticklabels([c[1] for c in conds])
    ax.set_ylabel(r'Test AUROC, $\Delta\rho$ = 0.35')
    ax.legend(loc='upper right', ncol=2)
    ax.set_ylim(0.46, 0.70)
    save(fig, 'fig06a_observation')

    lags = [(0, 'lag_0'), (10, 'lag_10'), (30, 'inc_0.35'), (60, 'lag_60'), (90, 'lag_90')]
    fig, ax = plt.subplots(figsize=(COL, 2.6), constrained_layout=True)
    for a in arms:
        st = STY[a]
        pts = np.array([ci(vals(c, a)) for _, c in lags])
        x = np.array([l for l, _ in lags])
        ax.errorbar(x, pts[:, 0], yerr=[pts[:, 0] - pts[:, 1], pts[:, 2] - pts[:, 0]], color=st['c'], marker=st['m'],
                    ls=st['ls'], capsize=1.8, lw=1.1, ms=4, label=st['lab'])
    chance(ax)
    ax.set_xticks([0, 10, 30, 60, 90]); ax.set_xlabel('SD of the fixed source lags (degrees)')
    ax.set_ylabel(r'Test AUROC, $\Delta\rho$ = 0.35')
    ax.set_ylim(0.46, 0.70)
    save(fig, 'fig06b_lag')


# ====================================================================== Fig. 7: mechanism controls (revision)
MECH = [('Shared walk, Eq. (1)', None),
        ('global change, lag SD 30° (default)', 'inc_0.35'),
        ('global change, lag SD 0°', 'lag_0'),
        ('global change, lag SD 90°', 'lag_90'),
        ('focal-only change, lag SD 30°', 'sw_focal_0.35'),
        ('focal-only change, lag SD 0°', 'sw_focal_0.35_lag0'),
        ('Kuramoto, Eq. (2)', None),
        ('ΔK = 0.1, no imposed lag', 'kura_inc_0.1'),
        ('ΔK = 0.1, lag SD 30°', 'kura_inc_0.1_lag30'),
        ('ΔK = 0.1, lag SD 90°', 'kura_inc_0.1_lag90'),
        ('ΔK = 0.4, no imposed lag', 'kura_inc_0.4'),
        ('ΔK = 0.4, lag SD 30°', 'kura_inc_0.4_lag30')]


def fig7():
    if AGG is None:
        return
    inc = AGG['incr']
    fig, ax = plt.subplots(figsize=(FULL, 3.6), constrained_layout=True)
    y = 0
    yt, yl = [], []
    for lab, c in MECH:
        if c is None:
            yt.append(y); yl.append(lab); y -= 1
            continue
        if c not in inc:
            y -= 1; continue
        for comb, off, fill in [('A1+plv', 0.14, True), ('A1+wpli', -0.14, False)]:
            r = inc[c][comb]
            col = STY['plv']['c'] if comb == 'A1+plv' else STY['wpli']['c']
            ax.errorbar(r['mean'], y + off, xerr=[[r['mean'] - r['lo']], [r['hi'] - r['mean']]], color=col,
                        marker='s' if comb == 'A1+plv' else '^', mfc=col if fill else 'white', ms=4.5, capsize=1.8,
                        lw=1.0, ls='none')
        yt.append(y); yl.append(lab); y -= 1
    ax.axvline(0, color='#555555', lw=0.8, ls=':')
    ax.set_yticks(yt); ax.set_yticklabels(yl)
    for t, (lab, c) in zip(ax.get_yticklabels(), [m for m in MECH if m[1] is None or m[1] in inc]):
        if c is None:
            t.set_fontweight('bold')
    ax.set_xlabel('AUROC gain over band power (95% CI)')
    ax.grid(axis='y', visible=False)
    ax.legend(handles=[Line2D([], [], color=STY['plv']['c'], marker='s', ls='none', label='A1 + PLV − A1'),
                       Line2D([], [], color=STY['wpli']['c'], marker='^', mfc='white', ls='none', label='A1 + wPLI − A1')],
              loc='center right', bbox_to_anchor=(1.0, 0.47), ncol=1)
    save(fig, 'fig07_mechanism')


# ====================================================================== Fig. 8: resampling (with stress tests)
def fig8():
    if AGG is None:
        return
    groups = [('rs_250', '250 Hz\npad'), ('rs_400', '400 Hz\n5 of 8'), ('rs_512', '512 Hz\n1 of 2'),
              ('rs_1000', '1000 Hz\n1 of 4'), ('rsx_1000_emg4', '1000 Hz\nEMG ×4'),
              ('rsx_1000_mains60', '1000 Hz\n60-Hz harm.'), ('rsx_1000_mains60_x4', '1000 Hz\n60 Hz ×4')]
    groups = [g for g in groups if g[0] in AGG['tost']]
    arms = ['A1', 'A2', 'plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv']
    fig, ax = plt.subplots(figsize=(FULL, 3.0), constrained_layout=True)
    ax.axhspan(-0.05, 0.05, color='#f3f3f3', zorder=0)
    ax.axhspan(-0.02, 0.02, color='#e1e1e1', zorder=0)
    for j, a in enumerate(arms):
        st = STY[a]
        xs, ms, lo, hi = [], [], [], []
        for i, (c, _) in enumerate(groups):
            r = AGG['tost'][c].get(a)
            if r is None:
                continue
            xs.append(i + (j - 3.5) * 0.095); ms.append(r['diff']); lo.append(r['ci90'][0]); hi.append(r['ci90'][1])
        ms, lo, hi = map(np.array, (ms, lo, hi))
        ax.errorbar(xs, ms, yerr=[ms - lo, hi - ms], color=st['c'], marker=st['m'], ls='none', capsize=1.6, ms=4.5,
                    lw=1.0, label=st['lab'])
    ax.axhline(0, color='#333333', lw=0.8)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels([g[1] for g in groups])
    ax.set_ylabel('ΔAUROC, benchmark − anti-aliased\n(mean, 90% CI)')
    ax.grid(axis='x', visible=False)
    ax.legend(ncol=4, loc='lower center', bbox_to_anchor=(0.5, 1.0))
    save(fig, 'fig08_resampling')


# ====================================================================== Fig. 9: alarm rules
def fig9():
    rchk = json.load(open(os.path.join(REPO, 'results', 'regime_check.json')))
    ev = json.load(open(os.path.join(REPO, 'results', 'event_level.json')))
    # (a) critical run length, exact onset probabilities
    ps = np.logspace(np.log10(0.005), np.log10(0.3), 40)
    fig, ax = plt.subplots(figsize=(COL, 2.95), constrained_layout=True)
    for rule, st, lab in [('3consec', STY['A1'], '3 consecutive'), ('3of5', STY['plv'], '3 of 5')]:
        Lc = np.array([AX.L_star(p, rule, True) for p in ps])
        ok = np.isfinite(Lc)
        ax.plot(ps[ok], Lc[ok] * 5 / 60, color=st['c'], ls=st['ls'], lw=1.5, label=r'$L_c$, ' + lab)
    iid = {(x['p'], x['rule'], x['cfg']): x['sim_fa_h'] for x in rchk if x['L'] is None}
    for x in rchk:
        if x['L'] is None or x['cfg'] != 'SPH2_SOP5':
            continue
        more = x['sim_fa_h'] > iid[(x['p'], x['rule'], x['cfg'])]
        col = STY['A1']['c'] if x['rule'] == '3consec' else STY['plv']['c']
        mk = 'o' if x['rule'] == '3consec' else 's'
        f = 0.9 if x['rule'] == '3consec' else 1.1
        ax.plot(x['p'] * f, x['L'] * 5 / 60, marker=mk, ms=4.5, ls='none', color=col, mfc=col if more else 'white')
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlabel('Exceedance probability per window, $p$')
    ax.set_ylabel('Mean exceedance run (min)')
    ax.legend(handles=[Line2D([], [], color=STY['A1']['c'], lw=1.5, label=r'$L_c$, 3 consecutive'),
                       Line2D([], [], color=STY['plv']['c'], lw=1.5, ls='--', label=r'$L_c$, 3 of 5')],
              loc='upper center', bbox_to_anchor=(0.5, -0.27), ncol=2)
    save(fig, 'fig09a_critical_run')

    taus = [0.0, 30.0, 60.0, 300.0, 1200.0]
    tlab = ['0', '30 s', '1 min', '5 min', '20 min']

    def series(cfg, rule, m):
        out = []
        for t in taus:
            rr = [r for r in ev if r['cfg'] == cfg and r['rule'] == rule and r['tau'] == t]
            v = np.array([r[m] for r in rr])
            b = np.random.default_rng(0).choice(v, (5000, len(v))).mean(1)
            out.append((v.mean(), np.quantile(b, 0.025), np.quantile(b, 0.975), np.mean([r['random_sens'] for r in rr])))
        return np.array(out)

    for m, ylab, name in [('fa_h', 'False alarms per hour', 'fig09b_false_alarms'),
                          ('sens', 'Event sensitivity', 'fig09c_sensitivity')]:
        fig, ax = plt.subplots(figsize=(COL, 2.75), constrained_layout=True)
        for cfg, mfill, ls, cl in [('SPH2_SOP5', True, '-', '2/5'), ('SPH10_SOP30', False, '--', '10/30')]:
            for rule, st, rl in [('3consec', STY['A1'], '3 consec.'), ('3of5', STY['plv'], '3 of 5')]:
                s = series(cfg, rule, m)
                x = np.arange(len(taus)) + (0.07 if cfg == 'SPH10_SOP30' else -0.07)
                ax.errorbar(x, s[:, 0], yerr=[s[:, 0] - s[:, 1], s[:, 2] - s[:, 0]], color=st['c'], marker=st['m'],
                            mfc=st['c'] if mfill else 'white', ls=ls, capsize=1.6, lw=1.0, ms=4,
                            label=f'{rl}, SPH/SOP {cl}')
                if m == 'sens':
                    ax.plot(np.arange(len(taus)), s[:, 3], color=st['c'], ls=':', lw=0.9)
        ax.set_xticks(range(len(taus))); ax.set_xticklabels(tlab)
        ax.set_xlabel(r'Correlation time of window scores, $\tau$')
        ax.set_ylabel(ylab)
        if m == 'sens':
            ax.set_ylim(0, 0.9)
            ax.text(0.98, 0.03, 'dotted: random predictor', transform=ax.transAxes, ha='right', fontsize=FS)
        else:
            ax.legend(loc='upper right', ncol=1)
        save(fig, name)


if __name__ == '__main__':
    for f in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9):
        f()
