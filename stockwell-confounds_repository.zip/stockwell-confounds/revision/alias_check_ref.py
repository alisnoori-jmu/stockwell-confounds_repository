"""Check: alpha-band error power of sample picking with 60-Hz harmonics, bipolar versus referential channels.
Usage: python alias_check_ref.py <repo> <out.json>"""
import sys, os, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, sys.argv[1]]
import kernels, sim_ext
kernels.install(); sim_ext.install()
import sim, features as F
from experiments import subject_seed
from alias_signal import ideal_grid, INB, ALPHA
res = {}
for mains in (0.0, 0.5, 2.0):
    for obs in ('bipolar', 'referential'):
        p = dict(sim.DEFAULT); p.update(fs=1000.0, mains_f=60.0, mains_harm='1/k', mains=mains, observe=obs)
        if mains == 0.0:
            p.update(mains_f=50.0); p.pop('mains_harm')
        e_al = i_al = 0.0
        for seed in range(2):
            for s in range(48, 60):
                X, y = sim.generate_subject_windows(subject_seed(seed, s), p, 4, 0.35)
                for x in X.astype(np.float64):
                    b = F.benchmark_uniformise(x, 1000.0); r = ideal_grid(x, 1000.0)
                    Pe = np.abs(np.fft.rfft(b - r, axis=-1)) ** 2; Pi = np.abs(np.fft.rfft(r, axis=-1)) ** 2
                    e_al += Pe[:, ALPHA].sum(); i_al += Pi[:, ALPHA].sum()
        res[f'{mains}|{obs}'] = float(10 * np.log10(e_al / i_al))
        print(f'mains {mains:.1f} {obs:12s} alpha-band error {10*np.log10(e_al/i_al):6.2f} dB', flush=True)
json.dump(res, open(sys.argv[2], 'w'), indent=1)
