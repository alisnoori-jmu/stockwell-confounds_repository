# Revision analyses (second submission to IJIES, paper 20266731)

This folder contains the analyses added in response to the reviewers and the script that draws every figure of
the revised manuscript. They use the original code in the parent folder without changing it: default code paths
call the original functions, and the variants below are switched on by explicit condition parameters.

## Environment note

The original runs used Numba to compile two kernels. Where Numba is not available, `kernels.py` provides
replacements with the same arithmetic: a C integrator for the Kuramoto model (`kura.c`, compiled to `libkura.so`;
same order of operations as `sim._kuramoto_integrate`) and a vectorised NumPy version of `features._pair_kernel`.
All revision runs used these replacements.

Reproduction check: 6 existing conditions (inc_0.0, inc_0.35, inc_0.6, kura_inc_0.1, kura_inc_0.4, power40; seeds 0-11) were regenerated with the replacement kernels and compared with `results/auc.json` (`results/aggregate.json`, key `regen`). All 864 test AUROCs of the single-feature arms and their per-subject AUROCs are identical. In the combined arms (A1+plv, A1+wpli), 22 of 144 pooled test AUROCs and 21 of 1728 per-subject AUROCs differ: in inc_0.0, seed 11, A1+wpli, nearly tied validation AUROCs selected C = 10 instead of 1 (test AUROC difference 0.0072); all other differences are at most 6 window pairs ranked in reverse order (at most 0.00065), which we attribute to floating-point rounding. Event-level experiment (`event_fp.py`): all 12000 alarm and window metrics of `results/event_level.json` are reproduced exactly; the alarm thresholds differ by at most 4.1e-06.

The folder
`numba/` is a stand-in package so that `import numba` succeeds without Numba; delete it to use the real Numba.

    gcc -O2 -fPIC -shared -ffp-contract=off -o libkura.so kura.c -lm

## Files

| File | Purpose | Manuscript |
|---|---|---|
| `kernels.py`, `kura.c`, `numba/` | Exact replacements of the two Numba kernels | Section 2.9 |
| `sim_ext.py` | Generator variants: Kuramoto with the fixed source lags of Eq. (1) (`kura_lags`), shared walk with the coupling change confined to the focal set (`focal_only`, Eq. 13), 60-Hz mains with harmonics of amplitude 1/k (`mains_f`, `mains_harm`). Added random numbers come from an auxiliary stream seeded by (subject seed, 20261016), so every other quantity of every window equals the default generator | Sections 2.9, 3.6, 3.8 |
| `runner.py` | Features and classifier results for the new conditions (logistic regression for all 14 arms; gradient-boosted trees for 5 arms in 6 conditions) and regeneration of 6 existing conditions as a reproduction check | Tables 6, 7, 9 |
| `aggregate.py` | Seed-paired increments, contrasts between conditions, TOST, gradient boosting, reproduction check → `results/aggregate.json` | Tables 6–9 |
| `alias_signal.py` | In-band error power added by sample picking (Eq. 14) → `results/alias_signal.json` | Section 3.8, Table 9 |
| `event_boot.py` | Subject-level and hierarchical (seed, then subject) bootstrap of the event-level metrics → `results/event_boot.json` | Section 3.9, Appendix B |
| `event_fp.py` | Exact regeneration of the event-level experiment and the firing-power rule (Eq. 15) on the same score streams → `results/event_level_regen.json`, `results/event_fp*.json` | Section 3.9, Table 11 |
| `alias_check_ref.py` | Alpha-band error of sample picking in bipolar versus referential channels → `results/alias_check_ref.json` | Section 3.8 |
| `figures_rev.py` | All figures of the revised manuscript at printed size (text ≥ 10 pt) → `figures/` | Figs. 1–9 |
| `results/jobs/` | One JSON per (condition, seed): test AUROC and per-subject AUROC of every arm | — |

## Reproduce

    python runner.py <repo> <work> all 2          # about 2.5 h on two cores
    python runner.py <repo> <work> r25b 2         # extreme mains condition and Kuramoto ΔK = 0.4 (gradient boosting), about 35 min
    python aggregate.py <repo> <work> <work>/results/aggregate.json
    python alias_signal.py <repo> <work>/results/alias_signal.json
    python alias_check_ref.py <repo> <work>/results/alias_check_ref.json
    python event_boot.py <repo>/results/event_level.json <work>/results/event_boot.json
    python event_fp.py <repo> <work>              # needs the regenerated inc_0.6 features (seeds 0-4)
    python figures_rev.py <repo> <work> <work>/figs

## Conditions added in the revision

| Condition | Definition | Seeds |
|---|---|---|
| `kura_inc_0.1_lag30`, `kura_inc_0.4_lag30` | Kuramoto, ΔK = 0.1 or 0.4, fixed lags with SD 30° | 0–11 |
| `kura_inc_0.1_lag90` | Kuramoto, ΔK = 0.1, fixed lags with SD 90° | 0–11 |
| `sw_focal_0.35`, `sw_focal_0.35_lag0` | Shared walk, Δρ = 0.35 confined to the focal set (Eq. 13), lag SD 30° or 0° | 0–11 |
| `lf_0.25`, `lf_0.50` (+ `_power40`) | Lead-field width 0.25 or 0.50 head radii; Δρ = 0.35 or power +40 % | 0–11 |
| `f0_theta`, `f0_beta` (+ `_power40`) | Oscillation 5–7 Hz or 18–22 Hz; Δρ = 0.35 or power +40 % | 0–11 |
| `rsx_1000_emg4` | Native 1000 Hz, EMG level 1.20 × clean RMS | 0–15 |
| `rsx_1000_mains60` | Native 1000 Hz, 60-Hz mains 0.50 × clean RMS with harmonics k = 1..8 of amplitude 1/k | 0–15 |
| `rsx_1000_mains60_x4` | As above with 2.00 × clean RMS | 0–15 |
| regenerated: `inc_0.0`, `inc_0.35`, `inc_0.6`, `power40`, `kura_inc_0.1`, `kura_inc_0.4` | Original definitions; logistic regression must equal `results/auc.json`; gradient boosting added | 0–11 |
