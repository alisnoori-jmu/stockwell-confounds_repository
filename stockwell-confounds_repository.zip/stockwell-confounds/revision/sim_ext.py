"""Generator variants used in the revision. Every default code path calls the original function unchanged.

Variants (switched on by entries in the parameter dict p):
  kura_lags=True   Kuramoto generator with the fixed per-subject source lags of Eq. (1) added to the
                   oscillator phases (the lags are the same draws as in the shared-walk generator).
  focal_only=True  shared-walk generator in which the coupling change is confined to the focal set:
                   theta_k = rho0*Xi + b*Xi_F + c*xi_k + lag_k for focal sources, with
                   b = sqrt(rho_f^2 - rho0^2), c = sqrt(1 - rho_f^2), so focal-focal coupling equals
                   rho_f^2 as in Eq. (1) while focal-nonfocal coupling stays at rho0^2 (as in the Kuramoto
                   generator, where only focal-focal coupling changes).
  mains_f, mains_harm='1/k'
                   mains interference at frequency mains_f with harmonics k = 1..8 of amplitude 1/k
                   (only harmonics below the native Nyquist frequency are added).
Draws that a variant adds (the focal walk Xi_F and the phases of mains harmonics 4-8) come from an
auxiliary random stream seeded from the subject seed, so the main random stream, and therefore every
other quantity of every window, is identical to the default generator for the same subject.
"""
import numpy as np
import sim

_AUX = {'rng': None}
_orig_gsw = sim.generate_subject_windows
_orig_sw = sim.source_window
_orig_kw = sim.source_window_kuramoto
_orig_ew = sim.electrode_window


def generate_subject_windows(seed, p, n_per_class, delta_rho=0.0, amp_mult=1.0, direction=+1):
    _AUX['rng'] = np.random.default_rng([int(seed), 20261016])
    return _orig_gsw(seed, p, n_per_class, delta_rho, amp_mult, direction)


def source_window(rng, subj, p, rho_focal, amp_focal_mult, n, fs):
    if not p.get('focal_only', False):
        return _orig_sw(rng, subj, p, rho_focal, amp_focal_mult, n, fs)
    t = np.arange(n) / fs
    step = p['diffusion'] / np.sqrt(fs)
    Xi = np.cumsum(rng.normal(0, step, n))
    xi = np.cumsum(rng.normal(0, step, (sim.N_SRC, n)), axis=1)
    XiF = np.cumsum(_AUX['rng'].normal(0, step, n))
    r0 = p['rho_base']
    if rho_focal < r0:
        raise ValueError('focal_only is defined for coupling increases only')
    a = np.full(sim.N_SRC, r0)
    b = np.zeros(sim.N_SRC)
    c = np.full(sim.N_SRC, np.sqrt(1 - r0 ** 2))
    b[sim.FOCAL] = np.sqrt(rho_focal ** 2 - r0 ** 2)
    c[sim.FOCAL] = np.sqrt(1 - rho_focal ** 2)
    theta = a[:, None] * Xi[None, :] + b[:, None] * XiF[None, :] + c[:, None] * xi + subj['lags'][:, None]
    phase0 = rng.uniform(0, 2 * np.pi)
    amp = subj['amp'].copy()
    amp[sim.FOCAL] *= amp_focal_mult
    osc = amp[:, None] * np.sqrt(2) * np.cos(2 * np.pi * subj['f0'] * t[None, :] + phase0 + theta)
    bg = np.vstack([sim._pink(rng, 1, n, fs, bb)[0] for bb in subj['beta']])
    return bg + osc


def source_window_kuramoto(rng, subj, p, k_focal, amp_focal_mult, n, fs):
    if not p.get('kura_lags', False):
        return _orig_kw(rng, subj, p, k_focal, amp_focal_mult, n, fs)
    dt = 1.0 / fs
    nb = int(round(p['kura_burn_s'] * fs))
    K = np.full((sim.N_SRC, sim.N_SRC), p['kura_K0'])
    for i in sim.FOCAL:
        for j in sim.FOCAL:
            K[i, j] = k_focal
    np.fill_diagonal(K, 0.0)
    w = 2 * np.pi * (subj['f0'] + subj['detune'])
    th = rng.uniform(0, 2 * np.pi, sim.N_SRC)
    noise = rng.normal(0, p['diffusion'] * np.sqrt(dt), (nb + n, sim.N_SRC))
    out = sim._kuramoto_integrate(th, w, K, noise, dt, nb, n)
    amp = subj['amp'].copy()
    amp[sim.FOCAL] *= amp_focal_mult
    osc = amp[:, None] * np.sqrt(2) * np.cos(out.T + subj['lags'][:, None])
    bg = np.vstack([sim._pink(rng, 1, n, fs, bb)[0] for bb in subj['beta']])
    return bg + osc


def electrode_window(rng, subj, p, src, n, fs):
    if p.get('mains_f', 50.0) == 50.0 and not p.get('mains_harm'):
        return _orig_ew(rng, subj, p, src, n, fs)
    clean = subj['L'] @ src
    rms = clean.std(axis=1, keepdims=True).mean()
    x = clean.copy()
    if p['artefacts']:
        t = np.arange(n) / fs
        if rng.random() < subj['emg_rate']:
            k = rng.integers(2, 5)
            sites = rng.choice(sim.EMG_SITES, k, replace=False)
            dur = rng.uniform(0.5, 2.0)
            t0 = rng.uniform(0, n / fs - dur)
            env = 1.0 + 3.0 * ((t >= t0) & (t < t0 + dur))
            for s in sites:
                x[s] += p['emg'] * rms * env * sim._bandnoise(rng, n, fs, 20.0)
        harm = [(k, 1.0 / k) for k in range(1, 9)] if p.get('mains_harm') == '1/k' else [(1, 1.0), (2, 0.4), (3, 0.2)]
        for hmul, a in harm:
            fh = p.get('mains_f', 50.0) * hmul
            if fh < 0.5 * fs:
                ph = (rng if hmul <= 3 else _AUX['rng']).uniform(0, 2 * np.pi)
                x += (p['mains'] * rms * a * subj['mains_amp'])[:, None] * np.sin(2 * np.pi * fh * t + ph)[None, :]
        if rng.random() < 0.5:
            e = rng.integers(len(sim.ELECTRODES))
            t0 = rng.uniform(0, n / fs - 0.5)
            m = t >= t0
            x[e, m] += p['pop'] * 4.0 * rms * rng.choice([-1, 1]) * np.exp(-(t[m] - t0) / 0.3)
    noise_sd = rms * 10 ** (-subj['snr_db'] / 20.0)
    x += rng.normal(0, noise_sd, x.shape)
    return x * subj['scale']


def install():
    sim.generate_subject_windows = generate_subject_windows
    sim.source_window = source_window
    sim.source_window_kuramoto = source_window_kuramoto
    sim.electrode_window = electrode_window
