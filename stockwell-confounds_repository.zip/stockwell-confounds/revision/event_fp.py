"""Event-level experiment: exact regeneration and firing-power control (revision).

Usage: python event_fp.py <repo dir> <work dir>
1. Regenerates the event-level experiment of Section 2.7 with the released code (event_level.run) and
   compares every row with the stored results/event_level.json (reproduction check).
2. Applies the firing-power alarm rule of Teixeira et al. (EPILAB) as used by Batista et al. (2024) and
   Andrade et al. (2024) to the SAME score streams: o[k] = 1 if the classifier labels window k preictal
   (decision function > 0), fp[n] = mean of o over the last SOP windows, an alarm is raised when fp rises
   to or above a threshold (0.5, and 0.7 as a secondary setting), followed by a refractory period
   SPH + SOP. Sensitivity, FA/h, time in warning and the random-predictor sensitivity are computed with
   the same functions as for the persistence rules.
Outputs: <work>/results/event_level_regen.json, <work>/results/event_fp.json
"""
import json, os, sys
import numpy as np

REPO, WORK = sys.argv[1], sys.argv[2]
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, REPO]
import kernels, sim_ext
kernels.install(); sim_ext.install()
import experiments as E, analysis as A, event_level as EV

FEAT = os.path.join(WORK, 'features')
E.OUT = FEAT; A.OUT = FEAT
RES = os.path.join(WORK, 'results')
os.makedirs(RES, exist_ok=True)
EV.OUTF = os.path.join(RES, 'event_level_regen.json')      # event scores are cached next to it

# ---------------------------------------------------------------- 1. regenerate and compare
if not os.path.exists(EV.OUTF):
    rows = EV.run()
else:
    rows = json.load(open(EV.OUTF))
orig = json.load(open(os.path.join(REPO, 'results', 'event_level.json')))
key = lambda r: (r['cfg'], r['seed'], r['subject'], r['tau'], r['rule'])
om = {key(r): r for r in orig}
maxd, nkeys, missing, nonid, per_key = 0.0, 0, 0, 0, {}
for r in rows:
    o = om.get(key(r))
    if o is None:
        missing += 1
        continue
    for k, v in r.items():
        if isinstance(v, (int, float)) and k in o:
            d = abs(float(v) - float(o[k]))
            maxd = max(maxd, d)
            per_key[k] = max(per_key.get(k, 0.0), d)
            nkeys += 1
            nonid += d > 0
check = dict(rows_regen=len(rows), rows_orig=len(orig), missing=missing, values_compared=nkeys,
             max_abs_diff=maxd, n_nonidentical=int(nonid), max_abs_diff_by_field=per_key)
print('reproduction check', check, flush=True)

# ---------------------------------------------------------------- 2. firing power on the same streams
FP_THR = [0.5, 0.7]
scored = {}
for seed in (0, 1, 2, 3, 4):
    c = json.load(open(os.path.join(RES, 'event_scores', f's{seed}.json')))
    scored[seed] = (c['thr'], {int(k): v for k, v in c['subj'].items()})


def fp_alarms(o, win, thr, refract):
    cs = np.concatenate([[0], np.cumsum(o)])
    n = len(o)
    idx = np.arange(n)
    lo = np.maximum(idx - win + 1, 0)
    fp = (cs[idx + 1] - cs[lo]) / win                 # fraction of the last `win` windows labelled preictal
    up = (fp >= thr) & ~np.r_[False, fp[:-1] >= thr]   # rises to the threshold
    out, last = [], -10 ** 9
    for t in np.flatnonzero(up):
        if t >= last + refract:
            out.append(t); last = t
    return np.array(out, int), fp


fprows = []
for seed, (thr, subj) in scored.items():
    for s, dd in subj.items():
        rng = np.random.default_rng(seed * 1000 + s)
        n, on = EV.timeline(rng)
        s0, s1 = np.array(dd['s0']), np.array(dd['s1'])
        for cfg, (sph, sop) in EV.CONFIGS.items():
            for tau in EV.TAUS:
                sc, lab = EV.stream(np.random.default_rng(seed * 1000 + s + int(tau)), n, on, s0, s1, tau, sph, sop)
                o = (sc > 0).astype(float)                 # classifier label (logistic decision function > 0)
                q0 = float(o[lab == 0].mean()); q1 = float(o[lab == 1].mean())
                for ft in FP_THR:
                    al, fp = fp_alarms(o, sop, ft, sph + sop)
                    sens, fa, tiw, ih, nfp = EV.evaluate_alarms(al, on, lab, n, sph, sop)
                    rnd = EV.random_predictor_sens(np.random.default_rng(seed + s), len(al), on, n, sph=sph, sop=sop)
                    fprows.append(dict(cfg=cfg, seed=seed, subject=s, tau=tau, rule=f'fp{ft}', sens=sens, fa_h=fa,
                                       n_fa=nfp, tiw=tiw, random_sens=rnd, label_rate_inter=q0, label_rate_pre=q1,
                                       n_alarms=len(al), inter_fp_max=float(fp[lab == 0].max())))
json.dump(dict(check=check, rows=fprows), open(os.path.join(RES, 'event_fp.json'), 'w'))

# ---------------------------------------------------------------- summary with subject and hierarchical bootstrap
B = 5000


def summ(rows, m):
    seeds = sorted({r['seed'] for r in rows})
    v = np.array([[r[m] for r in sorted([x for x in rows if x['seed'] == sd], key=lambda x: x['subject'])] for sd in seeds])
    rng = np.random.default_rng(0)
    flat = v.ravel()
    sb = rng.choice(flat, (B, flat.size)).mean(1)
    rng = np.random.default_rng(1)
    si = rng.integers(0, v.shape[0], (B, v.shape[0])); ji = rng.integers(0, v.shape[1], (B, v.shape[0], v.shape[1]))
    hb = v[si[:, :, None], ji].mean(axis=(1, 2))
    q = lambda b: [float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))]
    sm = v.mean(1)
    return dict(mean=float(v.mean()), subject_ci=q(sb), hier_ci=q(hb), seed_min=float(sm.min()), seed_max=float(sm.max()))


summary = {}
for cfg in EV.CONFIGS:
    for ft in FP_THR:
        for tau in EV.TAUS:
            rr = [r for r in fprows if r['cfg'] == cfg and r['rule'] == f'fp{ft}' and r['tau'] == tau]
            summary[f'{cfg}|fp{ft}|{tau}'] = {m: summ(rr, m) for m in ('sens', 'fa_h', 'tiw', 'random_sens')}
            summary[f'{cfg}|fp{ft}|{tau}']['label_rate_inter'] = float(np.mean([r['label_rate_inter'] for r in rr]))
            summary[f'{cfg}|fp{ft}|{tau}']['label_rate_pre'] = float(np.mean([r['label_rate_pre'] for r in rr]))
json.dump(dict(check=check, summary=summary), open(os.path.join(RES, 'event_fp_summary.json'), 'w'), indent=1)
for k, v in summary.items():
    print(f"{k:26s} sens {v['sens']['mean']:.2f} [{v['sens']['hier_ci'][0]:.2f},{v['sens']['hier_ci'][1]:.2f}] "
          f"FA/h {v['fa_h']['mean']:.2f} [{v['fa_h']['hier_ci'][0]:.2f},{v['fa_h']['hier_ci'][1]:.2f}] "
          f"TIW {v['tiw']['mean']:.3f} rnd {v['random_sens']['mean']:.2f} q0 {v['label_rate_inter']:.2f} q1 {v['label_rate_pre']:.2f}")
