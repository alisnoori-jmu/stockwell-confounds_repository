"""Revision simulations: generate features for new or regenerated conditions and evaluate every arm.

Usage: python runner.py <repo dir> <work dir> <plan name> [procs]
Each (condition, seed) job writes  <work>/features/<cond>__s<seed>.npz  and  <work>/jobs/<cond>__s<seed>.json
with the logistic-regression results of the original protocol (all 14 arms; benchmark and reference
paths for resampling conditions) and, for non-resampling conditions, a gradient-boosting classifier
(capacity check) on five arms. Jobs already on disk are skipped, so the run can be resumed.
"""
import json, os, sys, time
import numpy as np

REPO, WORK, PLAN = sys.argv[1], sys.argv[2], sys.argv[3]
PROCS = int(sys.argv[4]) if len(sys.argv) > 4 else 2
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, REPO]                      # numba stub first, then the original code
import kernels, sim_ext, sim, features as F, experiments as E, analysis as A
from analyze import ARMS
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
kernels.install()
sim_ext.install()

FEAT = os.path.join(WORK, 'features'); JOBS = os.path.join(WORK, 'jobs')
os.makedirs(FEAT, exist_ok=True); os.makedirs(JOBS, exist_ok=True)
E.OUT = FEAT

KURA = dict(generator='kuramoto')
P40 = float(np.sqrt(1.4))
NEW = {
    # R2-2: one mechanism at a time (paired with kura_inc_0.1 / kura_inc_0.4 / inc_0.35 / lag_0 of the original run)
    'kura_inc_0.1_lag30': dict(delta_rho=0.1, params=dict(KURA, kura_lags=True)),
    'kura_inc_0.4_lag30': dict(delta_rho=0.4, params=dict(KURA, kura_lags=True)),
    'kura_inc_0.1_lag90': dict(delta_rho=0.1, params=dict(KURA, kura_lags=True, lag_sd_deg=90.0)),
    'sw_focal_0.35': dict(delta_rho=0.35, params=dict(focal_only=True)),
    'sw_focal_0.35_lag0': dict(delta_rho=0.35, params=dict(focal_only=True, lag_sd_deg=0.0)),
    # R2-1: forward model and frequency structure (paired with inc_0.35 / power40)
    'lf_0.25': dict(delta_rho=0.35, params=dict(lf_width=0.25)),
    'lf_0.50': dict(delta_rho=0.35, params=dict(lf_width=0.50)),
    'lf_0.25_power40': dict(amp_mult=P40, params=dict(lf_width=0.25)),
    'lf_0.50_power40': dict(amp_mult=P40, params=dict(lf_width=0.50)),
    'f0_theta': dict(delta_rho=0.35, params=dict(f0_range=(5.0, 7.0))),
    'f0_beta': dict(delta_rho=0.35, params=dict(f0_range=(18.0, 22.0))),
    'f0_theta_power40': dict(amp_mult=P40, params=dict(f0_range=(5.0, 7.0))),
    'f0_beta_power40': dict(amp_mult=P40, params=dict(f0_range=(18.0, 22.0))),
    # R2-5: high-frequency contamination stress at 1000 Hz native rate (paired with rs_1000)
    'rsx_1000_emg4': dict(delta_rho=0.35, native_fs=1000, params=dict(fs=1000.0, emg=1.20)),
    'rsx_1000_mains60': dict(delta_rho=0.35, native_fs=1000, params=dict(fs=1000.0, mains_f=60.0, mains_harm='1/k', mains=0.50)),
    'rsx_1000_mains60_x4': dict(delta_rho=0.35, native_fs=1000, params=dict(fs=1000.0, mains_f=60.0, mains_harm='1/k', mains=2.00)),
}
for name, kw in NEW.items():
    E.CONDITIONS[name] = E.cond(name, **kw)
for c in E.CONDITIONS.values():                  # Stockwell features only (other transforms are not needed here)
    c['kinds'] = ['stockwell']

S12, S16 = list(range(12)), list(range(16))
PLANS = {
    'check': [('inc_0.35', [0]), ('kura_inc_0.4', [0])],
    'r22': [('kura_inc_0.1_lag30', S12), ('sw_focal_0.35', S12), ('sw_focal_0.35_lag0', S12),
            ('kura_inc_0.4_lag30', S12), ('kura_inc_0.1_lag90', S12)],
    'r25': [('rsx_1000_emg4', S16), ('rsx_1000_mains60', S16)],
    'r25b': [('rsx_1000_mains60_x4', S16), ('kura_inc_0.4', S12)],   # + gradient boosting for Kuramoto ΔK = 0.4
    'r21': [('lf_0.25', S12), ('lf_0.50', S12), ('f0_theta', S12), ('f0_beta', S12),
            ('lf_0.25_power40', S12), ('lf_0.50_power40', S12), ('f0_theta_power40', S12), ('f0_beta_power40', S12)],
    'regen': [('inc_0.6', S12), ('inc_0.35', S12), ('power40', S12), ('kura_inc_0.1', S12), ('inc_0.0', S12)],
}
HGB_CONDS = {'inc_0.0', 'inc_0.35', 'inc_0.6', 'power40', 'kura_inc_0.1', 'kura_inc_0.4'}
PLANS['all'] = PLANS['r22'] + PLANS['r25'] + PLANS['r21'] + PLANS['regen']

HGB_ARMS = ['A1', 'plv', 'wpli', 'A1+plv', 'A1+wpli']
HGB_GRID = [(lr, leaves) for lr in (0.05, 0.1) for leaves in (7, 15)]


def hgb(lr, leaves, seed):
    return HistGradientBoostingClassifier(max_iter=200, learning_rate=lr, max_leaf_nodes=leaves,
                                          l2_regularization=1.0, early_stopping=False, random_state=seed)


def eval_hgb(d, blocks, seed):
    X = np.hstack([d[b] for b in blocks]).astype(np.float64)
    y, subj = d['y'], d['subj']
    mk = A.masks(subj)
    best = None
    for lr, leaves in HGB_GRID:
        m = hgb(lr, leaves, seed).fit(X[mk['train']], y[mk['train']])
        a = roc_auc_score(y[mk['val']], m.predict_proba(X[mk['val']])[:, 1])
        if best is None or a > best[0]:
            best = (a, lr, leaves)
    trv = mk['train'] | mk['val']
    m = hgb(best[1], best[2], seed).fit(X[trv], y[trv])
    s = m.predict_proba(X[mk['test']])[:, 1]
    return dict(auc=float(roc_auc_score(y[mk['test']], s)), lr=best[1], leaves=best[2],
                subj_auc=A.per_subject_auc(s, y[mk['test']], subj[mk['test']]).tolist())


def job(args):
    cname, seed = args
    out_path = os.path.join(JOBS, f'{cname}__s{seed}.json')
    if os.path.exists(out_path):
        return cname, seed, 'skip', 0.0
    t0 = time.time()
    path = E.run_one((cname, seed))
    dz = np.load(path)
    d = {k: dz[k] for k in dz.files}
    res = dict(cond=cname, seed=seed, lr={}, hgb={})
    c = E.CONDITIONS[cname]
    if c['native_fs'] is not None:
        for pre in ('bench_', 'ref_'):
            for name, bl in ARMS.items():
                if all(pre + b in d for b in bl):
                    r = A.eval_arm(d, bl, prefix=pre)
                    res['lr'][pre + name] = dict(auc=r['auc'], C=r['C'], subj_auc=r['subj_auc'])
    else:
        for name, bl in ARMS.items():
            if all(b in d for b in bl):
                r = A.eval_arm(d, bl)
                res['lr'][name] = dict(auc=r['auc'], C=r['C'], subj_auc=r['subj_auc'])
        if cname in HGB_CONDS:
            for name in HGB_ARMS:
                res['hgb'][name] = eval_hgb(d, ARMS[name], seed)
    res['secs'] = time.time() - t0
    json.dump(res, open(out_path + '.tmp', 'w'))
    os.replace(out_path + '.tmp', out_path)
    return cname, seed, 'done', res['secs']


if __name__ == '__main__':
    os.environ.setdefault('OMP_NUM_THREADS', '1')
    jobs = [(c, s) for c, seeds in PLANS[PLAN] for s in seeds]
    t0 = time.time()
    from multiprocessing import Pool
    with Pool(PROCS) as pool:
        for i, (c, s, st, secs) in enumerate(pool.imap(job, jobs)):
            print(f'[{i + 1}/{len(jobs)}] {c} s{s} {st} {secs:.0f}s (elapsed {time.time() - t0:.0f}s)', flush=True)
    print('PLAN DONE', PLAN, flush=True)
