"""Aggregate the revision simulations with the original results.

Usage: python aggregate.py <repo dir> <work dir> <out.json>
Reads <repo>/results/auc.json (original runs) and <work>/jobs/*.json (revision runs) and writes:
  arms      per condition and arm: n seeds, mean test AUROC, 95 % t-interval
  incr      per condition: paired increments A1+PLV - A1 and A1+wPLI - A1 (seed-paired, 95 % t-interval)
  paired    named contrasts between conditions on common seeds (mechanism controls, sensitivity)
  tost      benchmark minus reference resampling for the high-frequency stress conditions (90 % / 95 % CI)
  hgb       gradient-boosting results and the paired difference from logistic regression
  regen     maximum absolute difference between regenerated and original AUROCs (reproduction check)
"""
import glob, json, os, sys
import numpy as np
from scipy import stats

REPO, WORK, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
orig = json.load(open(os.path.join(REPO, 'results', 'auc.json')))

# ---- collect per-seed AUROCs: res[cond][seed][arm] = auc ; hgb[cond][seed][arm] = auc
res, hgb, new_lr, new_full = {}, {}, {}, {}
for c, seeds in orig.items():
    for s, arms in seeds.items():
        res.setdefault(c, {})[int(s)] = {a: v['auc'] for a, v in arms.items() if isinstance(v, dict)}
for f in sorted(glob.glob(os.path.join(WORK, 'jobs', '*.json'))):
    j = json.load(open(f))
    c, s = j['cond'], int(j['seed'])
    new_lr.setdefault(c, {})[s] = {a: v['auc'] for a, v in j['lr'].items()}
    new_full.setdefault(c, {})[s] = j['lr']
    if j.get('hgb'):
        hgb.setdefault(c, {})[s] = {a: v['auc'] for a, v in j['hgb'].items()}
for c, seeds in new_lr.items():
    if c not in orig:                       # new conditions enter the main table
        res[c] = seeds


def tci(x, level=0.95):
    x = np.asarray(x, float)
    n = len(x)
    m = float(x.mean())
    if n < 2:
        return dict(n=n, mean=m, lo=float('nan'), hi=float('nan'))
    h = stats.t.ppf(0.5 + level / 2, n - 1) * x.std(ddof=1) / np.sqrt(n)
    return dict(n=n, mean=m, lo=m - h, hi=m + h, sd=float(x.std(ddof=1)))


def arm_vals(table, c, arm, seeds=None):
    d = table[c]
    ss = sorted(d) if seeds is None else seeds
    return [d[s][arm] for s in ss if arm in d[s]]


out = dict(arms={}, incr={}, paired={}, tost={}, hgb={}, regen={})

# ---- per-arm means
for c in sorted(res):
    out['arms'][c] = {}
    arms = sorted({a for s in res[c].values() for a in s})
    for a in arms:
        if a.startswith('perm:'):
            continue
        out['arms'][c][a] = tci(arm_vals(res, c, a))

# ---- power-plus-phase increments (within condition, seed-paired)
for c in sorted(res):
    for pre in ([''] if not c.startswith(('rs_', 'rsx_')) else ['bench_', 'ref_']):
        if pre + 'A1+plv' not in out['arms'][c]:
            continue
        ss = sorted(res[c])
        a1 = np.array(arm_vals(res, c, pre + 'A1', ss))
        for comb in ('A1+plv', 'A1+wpli'):
            v = np.array(arm_vals(res, c, pre + comb, ss))
            r = tci(v - a1)
            r['p_wilcoxon'] = float(stats.wilcoxon(v - a1).pvalue) if np.any(v != a1) else 1.0
            out['incr'].setdefault(c, {})[pre + comb] = r


# ---- named paired contrasts between conditions (common seeds)
def contrast(c1, c0, arm, arm0=None):
    arm0 = arm0 or arm
    ss = sorted(set(res[c1]) & set(res[c0]))
    x1 = np.array([res[c1][s][arm] for s in ss])
    x0 = np.array([res[c0][s][arm0] for s in ss])
    return tci(x1 - x0)


def incr_contrast(c1, c0, comb='A1+plv'):
    """difference between conditions of the within-condition increment (comb - A1)"""
    ss = sorted(set(res[c1]) & set(res[c0]))
    i1 = np.array([res[c1][s][comb] - res[c1][s]['A1'] for s in ss])
    i0 = np.array([res[c0][s][comb] - res[c0][s]['A1'] for s in ss])
    return tci(i1 - i0)


PAIRS = [  # (name, condition, baseline)
    # R2-2 mechanism controls
    ('kura_lag30_vs_kura_0.1', 'kura_inc_0.1_lag30', 'kura_inc_0.1'),
    ('kura_lag30_vs_kura_0.4', 'kura_inc_0.4_lag30', 'kura_inc_0.4'),
    ('kura_lag90_vs_kura_0.1', 'kura_inc_0.1_lag90', 'kura_inc_0.1'),
    ('kura_lag90_vs_kura_lag30', 'kura_inc_0.1_lag90', 'kura_inc_0.1_lag30'),
    ('swfocal_vs_inc_0.35', 'sw_focal_0.35', 'inc_0.35'),
    ('swfocal_lag0_vs_swfocal', 'sw_focal_0.35_lag0', 'sw_focal_0.35'),
    ('swfocal_lag0_vs_lag_0', 'sw_focal_0.35_lag0', 'lag_0'),
    ('swfocal_lag0_vs_kura_0.1', 'sw_focal_0.35_lag0', 'kura_inc_0.1'),
    ('lag_0_vs_inc_0.35', 'lag_0', 'inc_0.35'),
    # R2-1 forward model and frequency structure
    ('lf_0.25_vs_inc_0.35', 'lf_0.25', 'inc_0.35'),
    ('lf_0.50_vs_inc_0.35', 'lf_0.50', 'inc_0.35'),
    ('f0_theta_vs_inc_0.35', 'f0_theta', 'inc_0.35'),
    ('f0_beta_vs_inc_0.35', 'f0_beta', 'inc_0.35'),
    ('lf_0.25_power40_vs_power40', 'lf_0.25_power40', 'power40'),
    ('lf_0.50_power40_vs_power40', 'lf_0.50_power40', 'power40'),
    ('f0_theta_power40_vs_power40', 'f0_theta_power40', 'power40'),
    ('f0_beta_power40_vs_power40', 'f0_beta_power40', 'power40'),
]
for name, c1, c0 in PAIRS:
    if c1 not in res or c0 not in res:
        continue
    r = {}
    for arm in ('A1', 'plv', 'ppc', 'wpli', 'imcoh', 'ciplv', 'A1+plv', 'A1+wpli'):
        if arm in out['arms'][c1] and arm in out['arms'][c0]:
            r[arm] = contrast(c1, c0, arm)
    for comb in ('A1+plv', 'A1+wpli'):
        r['incr_' + comb] = incr_contrast(c1, c0, comb)
    r['seeds'] = sorted(set(res[c1]) & set(res[c0]))
    out['paired'][name] = r

# ---- R2-5: benchmark - reference TOST for the stress conditions (and the original rates for reference)
for c in sorted(res):
    if not c.startswith(('rs_', 'rsx_')):
        continue
    ss = sorted(res[c])
    out['tost'][c] = {}
    for arm in ('A1', 'A2', 'plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'A1+plv', 'A1+wpli'):
        if 'bench_' + arm not in res[c][ss[0]]:
            continue
        b = np.array([res[c][s]['bench_' + arm] for s in ss])
        r_ = np.array([res[c][s]['ref_' + arm] for s in ss])
        d = b - r_
        c90, c95 = tci(d, 0.90), tci(d, 0.95)
        out['tost'][c][arm] = dict(ref=float(r_.mean()), bench=float(b.mean()), diff=c95['mean'],
                                   ci90=[c90['lo'], c90['hi']], ci95=[c95['lo'], c95['hi']],
                                   eq02=bool(c90['lo'] > -0.02 and c90['hi'] < 0.02),
                                   eq05=bool(c90['lo'] > -0.05 and c90['hi'] < 0.05),
                                   sig=bool(c95['lo'] > 0 or c95['hi'] < 0), n=len(ss))
# stress versus the default 1000-Hz condition (same seeds and subjects), per path
for c in ('rsx_1000_emg4', 'rsx_1000_mains60', 'rsx_1000_mains60_x4'):
    if c not in res or 'rs_1000' not in res:
        continue
    ss = sorted(set(res[c]) & set(res['rs_1000']))
    r = {}
    for pre in ('bench_', 'ref_'):
        for arm in ('A1', 'plv', 'ppc', 'wpli', 'A1+plv'):
            k = pre + arm
            r[k] = tci([res[c][s][k] - res['rs_1000'][s][k] for s in ss])
    out['paired'][c + '_vs_rs_1000'] = r

# ---- HGB capacity check
for c, seeds in sorted(hgb.items()):
    ss = sorted(seeds)
    out['hgb'][c] = {}
    for arm in sorted({a for s in seeds.values() for a in s}):
        h = np.array([seeds[s][arm] for s in ss])
        l = np.array([res[c][s][arm] for s in ss])
        out['hgb'][c][arm] = dict(hgb=tci(h), lr=tci(l), hgb_minus_lr=tci(h - l), n=len(ss))
    if 'A1+plv' in seeds[ss[0]]:
        for comb in ('A1+plv', 'A1+wpli'):
            out['hgb'][c]['incr_' + comb] = tci([seeds[s][comb] - seeds[s]['A1'] for s in ss])

# ---- reproduction check: regenerated conditions against the original auc.json
#      (pooled test AUROC, selected C and per-subject AUROCs of every arm and seed). A difference is also expressed
#      as the number of window pairs whose order was reversed (AUROC step = 1 / (n_pos * n_neg)).
def pair_counts(c, s, n_test_subj):
    fz = os.path.join(WORK, 'features', f'{c}__s{s}.npz')
    if not os.path.exists(fz):
        return None, None
    z = np.load(fz)
    y, subj = z['y'], z['subj']
    pos = np.array([int(y[subj == u].sum()) for u in np.unique(subj)])
    neg = np.array([int((subj == u).sum()) for u in np.unique(subj)]) - pos
    if len(set(pos)) != 1 or len(set(neg)) != 1:
        return None, None
    return int(pos[0] * neg[0]), int(n_test_subj * pos[0] * n_test_subj * neg[0])


for c, seeds in new_full.items():
    if c not in orig:
        continue
    diffs, sdiffs, cdiff, nonid, snonid, cmis = [], [], 0, [], [], []
    n_comb = n_comb_subj = 0
    for s, arms in seeds.items():
        o = orig[c].get(str(s))
        if o is None:
            continue
        pp_subj = pp_pool = None
        for a, v in arms.items():
            if a not in o:
                continue
            d = abs(v['auc'] - o[a]['auc'])
            diffs.append(d)
            if a.startswith('A1+'):                 # combined power-plus-phase arms
                n_comb += 1
                n_comb_subj += len(v.get('subj_auc', []))
            if 'C' in o[a] and v.get('C') != o[a]['C']:
                cdiff += 1
                cmis.append(dict(seed=s, arm=a, C_new=v.get('C'), C_orig=o[a]['C'], diff=d))
            sd = [abs(x - y) for x, y in zip(v.get('subj_auc', []), o[a].get('subj_auc', []))]
            sdiffs += sd
            if (d > 0 or any(x > 0 for x in sd)) and pp_subj is None:
                pp_subj, pp_pool = pair_counts(c, s, len(v.get('subj_auc', [])))
            if d > 0:
                nonid.append(dict(seed=s, arm=a, diff=d, pairs=round(d * pp_pool) if pp_pool else None))
            for k, x in enumerate(sd):
                if x > 0:
                    snonid.append(dict(seed=s, arm=a, subject=k, diff=x, pairs=round(x * pp_subj) if pp_subj else None))
    out['regen'][c] = dict(n_seeds=len(seeds), n_values=len(diffs), max_abs_diff=float(max(diffs)) if diffs else None,
                           n_nonidentical=len(nonid), nonidentical=nonid, n_C_mismatch=cdiff,
                           n_subj_values=len(sdiffs), max_subj_diff=float(max(sdiffs)) if sdiffs else None,
                           n_subj_nonidentical=len(snonid), subj_nonidentical=snonid, C_mismatch=cmis,
                           n_values_combined=n_comb, n_subj_values_combined=n_comb_subj)

json.dump(out, open(OUT, 'w'), indent=1)


def fmt(r):
    return f"{r['mean']:+.3f} ({r['lo']:+.3f} to {r['hi']:+.3f}) n={r['n']}"


print('== power-plus-phase increments ==')
for c, r in out['incr'].items():
    print(f"{c:22s}", ' | '.join(f"{k}: {fmt(v)}" for k, v in r.items()))
print('== paired contrasts ==')
for k, r in out['paired'].items():
    print(k)
    for a, v in r.items():
        if isinstance(v, dict):
            print(f"   {a:14s} {fmt(v)}")
print('== TOST ==')
for c, r in out['tost'].items():
    for a, v in r.items():
        print(f"{c:18s} {a:8s} ref {v['ref']:.3f} diff {v['diff']:+.3f} 90%[{v['ci90'][0]:+.3f},{v['ci90'][1]:+.3f}] eq02 {v['eq02']} eq05 {v['eq05']} sig {v['sig']}")
print('== HGB ==')
for c, r in out['hgb'].items():
    for a, v in r.items():
        if 'hgb' in v:
            print(f"{c:14s} {a:8s} HGB {v['hgb']['mean']:.3f} LR {v['lr']['mean']:.3f} diff {fmt(v['hgb_minus_lr'])}")
        else:
            print(f"{c:14s} {a:12s} {fmt(v)}")
print('== regen ==', out['regen'])
