"""Replacements for the two numba kernels of the original code (numba cannot be installed here).

pair_kernel        vectorised NumPy version of features._pair_kernel (same formulas)
kuramoto_integrate C version of sim._kuramoto_integrate (same arithmetic and summation order, no fast-math)
install()          patches features and sim in place; call before generating any window
"""
import ctypes, os
import numpy as np

_LIB = ctypes.CDLL(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'libkura.so'))
_D = np.ctypeslib.ndpointer(dtype=np.float64, flags='C_CONTIGUOUS')
_LIB.kura.argtypes = [_D, _D, _D, _D, ctypes.c_double, ctypes.c_int, ctypes.c_int, ctypes.c_int, _D]
_LIB.kura.restype = None


def kuramoto_integrate(th0, w, K, noise, dt, nb, n):
    m = th0.shape[0]
    out = np.empty((n, m))
    _LIB.kura(np.ascontiguousarray(th0, np.float64), np.ascontiguousarray(w, np.float64),
              np.ascontiguousarray(K, np.float64), np.ascontiguousarray(noise, np.float64),
              float(dt), int(nb), int(n), int(m), out)
    return out


def kuramoto_integrate_np(th0, w, K, noise, dt, nb, n):
    m = th0.shape[0]
    th = th0.copy()
    out = np.empty((n, m))
    for t in range(nb + n):
        s = np.zeros(m)
        for j in range(m):
            s = s + K[:, j] * np.sin(th[j] - th)
        th = th + (w + s) * dt + noise[t]
        if t >= nb:
            out[t - nb] = th
    return out


def pair_kernel(Cr, Ci, iu0, iu1):
    A_r, A_i = Cr[iu0], Ci[iu0]
    B_r, B_i = Cr[iu1], Ci[iu1]
    xr = A_r * B_r + A_i * B_i
    xi = A_i * B_r - A_r * B_i
    mag = np.sqrt(xr * xr + xi * xi).astype(np.float64) + 1e-20
    xr64, xi64 = xr.astype(np.float64), xi.astype(np.float64)
    ser = (xr64 / mag).sum(-1); sei = (xi64 / mag).sum(-1)
    sim_ = xi64.sum(-1); ssim = (xi64 * xi64).sum(-1); sabs = np.abs(xi64).sum(-1)
    pa = (A_r * A_r + A_i * A_i).astype(np.float64).sum(-1)
    pb = (B_r * B_r + B_i * B_i).astype(np.float64).sum(-1)
    n = float(Cr.shape[2])
    mr, mi = ser / n, sei / n
    out = np.empty((6,) + ser.shape)
    out[0] = np.sqrt(mr * mr + mi * mi)
    out[1] = np.abs(sim_ / n) / np.sqrt((pa / n) * (pb / n) + 1e-20)
    out[2] = np.abs(sim_) / (sabs + 1e-20)
    v = (sim_ * sim_ - ssim) / ((sabs * sabs - ssim) + 1e-20)
    out[3] = np.where(v > 0, v, 0.0)
    out[4] = np.abs(mi) / np.sqrt(np.maximum(1.0 - mr * mr, 1e-6))
    out[5] = ((ser * ser + sei * sei) - n) / (n * (n - 1.0))
    return out


def install():
    import features, sim
    features._pair_kernel = pair_kernel
    sim._kuramoto_integrate = kuramoto_integrate
