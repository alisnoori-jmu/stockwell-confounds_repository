"""Uncertainty of the event-level metrics with the hierarchy of the experiment (Reviewer 2, comment 4).

The 60 monitored subjects come from five fitted models (seeds 0-4, 12 test subjects each). For every
SPH/SOP setting, alarm rule and correlation time tau this script reports, for event sensitivity, FA/h and
time in warning:
  subject   : mean over the 60 subjects with the subject-level bootstrap of the manuscript (5,000 resamples)
  hier      : two-stage bootstrap - resample the 5 seeds with replacement, then the 12 subjects within each
              drawn seed with replacement (5,000 resamples)
  seed      : the five seed-level means (mean over the 12 subjects of each fitted model) and their range
and the paired change relative to independent windows (tau = 0) for the same subjects and seizure times.
Usage: python event_boot.py <event_level.json> <out.json>
"""
import json, sys
import numpy as np

ev = json.load(open(sys.argv[1]))
B = 5000
METRICS = ['sens', 'fa_h', 'tiw']
TAUS = [0.0, 30.0, 60.0, 300.0, 1200.0]


def grid(rows, metric):
    seeds = sorted({r['seed'] for r in rows})
    return np.array([[r[metric] for r in sorted([x for x in rows if x['seed'] == s], key=lambda x: x['subject'])]
                     for s in seeds])                                         # (n_seeds, n_subjects)


def subject_boot(v, rng):
    flat = v.ravel()
    b = rng.choice(flat, (B, flat.size)).mean(1)
    return [float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))]


def hier_boot(v, rng):
    ns, nj = v.shape
    s_idx = rng.integers(0, ns, (B, ns))
    j_idx = rng.integers(0, nj, (B, ns, nj))
    b = v[s_idx[:, :, None], j_idx].mean(axis=(1, 2))
    return [float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))]


def summarise(v):
    rng = np.random.default_rng(0)
    seed_means = v.mean(1)
    return dict(mean=float(v.mean()), subject_ci=subject_boot(v, rng),
                hier_ci=hier_boot(v, np.random.default_rng(1)),
                seed_means=[float(x) for x in seed_means],
                seed_min=float(seed_means.min()), seed_max=float(seed_means.max()))


out = {}
for cfg in ['SPH2_SOP5', 'SPH10_SOP30']:
    for rule in ['3of5', '3consec']:
        base = {m: grid([r for r in ev if r['cfg'] == cfg and r['rule'] == rule and r['tau'] == 0.0], m) for m in METRICS}
        for tau in TAUS:
            rows = [r for r in ev if r['cfg'] == cfg and r['rule'] == rule and r['tau'] == tau]
            res = {}
            for m in METRICS:
                v = grid(rows, m)
                res[m] = summarise(v)
                if tau > 0:
                    res[m]['paired_vs_tau0'] = summarise(v - base[m])
            out[f'{cfg}|{rule}|{tau}'] = res
json.dump(out, open(sys.argv[2], 'w'), indent=1)
for k, r in out.items():
    s, f = r['sens'], r['fa_h']
    line = (f"{k:28s} sens {s['mean']:.2f} subj[{s['subject_ci'][0]:.2f},{s['subject_ci'][1]:.2f}] "
            f"hier[{s['hier_ci'][0]:.2f},{s['hier_ci'][1]:.2f}] seeds {s['seed_min']:.2f}-{s['seed_max']:.2f} | "
            f"FA/h {f['mean']:.2f} subj[{f['subject_ci'][0]:.2f},{f['subject_ci'][1]:.2f}] "
            f"hier[{f['hier_ci'][0]:.2f},{f['hier_ci'][1]:.2f}] seeds {f['seed_min']:.2f}-{f['seed_max']:.2f}")
    if 'paired_vs_tau0' in f:
        pf, ps = f['paired_vs_tau0'], s['paired_vs_tau0']
        line += (f" | dFA {pf['mean']:+.2f} hier[{pf['hier_ci'][0]:+.2f},{pf['hier_ci'][1]:+.2f}]"
                 f" dSens {ps['mean']:+.2f} hier[{ps['hier_ci'][0]:+.2f},{ps['hier_ci'][1]:+.2f}]")
    print(line)
