"""Stand-in for numba when it cannot be installed: njit returns the function unchanged.
The two jitted kernels are replaced in kernels.py (C for the Kuramoto integrator, NumPy for the pair kernel)."""
def njit(*a, **k):
    if a and callable(a[0]) and len(a) == 1 and not k:
        return a[0]
    return lambda f: f
jit = njit
prange = range
