# Confounds in phase-connectivity features for scalp-EEG seizure prediction

Code and result files for the manuscript *Confounds in Phase Connectivity Features for Scalp EEG Seizure
Prediction: Coupling, Power, Resampling and Alarm Rules in a Controlled Simulation* (International Journal of
Intelligent Engineering and Systems, submission 20266731).

Every number, table and figure in the manuscript is produced by the scripts below. No value in a table is
typed by hand: `make_tables.py` writes the tables from `results/summary.json`.

- Repository: [GitHub URL]
- Archived release: [Zenodo DOI]
- Licence: see `LICENSE` (to be chosen by the authors before release)

## Environment

Tested with Python 3.11, NumPy 2.4, SciPy 1.17, scikit-learn 1.8, Numba 0.67 and Matplotlib 3.10
(`requirements.txt`, `environment.yml`). `pyedflib` is only needed for the optional real-EEG checks.

    pip install -r requirements.txt

## Files

| File | What it does |
|---|---|
| `sim.py` | Scalp-EEG generator: shared-walk phase model (Eq. 1), noisy Kuramoto model (Eq. 2), Gaussian lead field, artefacts (EMG, mains, electrode pops), observation models and the 20-channel double-banana montage |
| `features.py` | Stockwell, Morlet and band-pass Hilbert coefficients; PLV, PPC, \|ImCoh\|, wPLI, dwPLI, ciPLV (Eqs. 6–11, function `_pair_kernel`); feature arms A1, A2, A3 and regional summaries; MLSPred-bench and polyphase resampling |
| `experiments.py` | Condition definitions (Table 2), subject split, subject seeds, feature-generation runner |
| `kura_calib.py` | Calibration of the Kuramoto coupling increments against the source-level PLV change of Eq. (1) |
| `run_all.py`, `run_kura.py` | Generate the feature files of every condition with the seeds used in the paper |
| `analysis.py`, `analyze.py` | L2 logistic regression per arm and seed, within-subject permutation nulls → `results/auc.json` |
| `chain_analyze.sh` | Optional helper that runs `analyze.py` block by block while feature files are still being generated |
| `event_level.py` | Event-level experiment (Section 2.7): window scoring, Gaussian-copula monitoring streams, alarm rules, analytic regime map (`python event_level.py map`) |
| `regime_check.py` | Direct simulation of Markov and independent exceedance streams used to validate the alarm-rate model (Appendix A.4) |
| `appendix_a/alarm_exact.py` | Exact onset probabilities by enumeration of 6-window histories (Eq. A2), closed form (Eq. A3), critical run length L_c (Eq. A5) → `results/alarm_exact.json` |
| `appendix_a/alarm_validate.py` | Compares the exact and approximate predictions with `results/regime_check.json` → `results/alarm_validate.json` |
| `appendix_a/event_regime.py` | Per-subject comparison of the copula streams with L_c (Appendix A.4) → `results/event_regime.json` |
| `report.py` | Statistics (seed-paired t-intervals, Wilcoxon, Holm within condition, TOST, subject bootstrap) → `results/summary.json` and `results/figs/` |
| `make_tables.py` | Manuscript Tables 3–7 from `results/summary.json` → `results/tables/` |
| `eeg_real.py` | Optional label-free checks on CHB-MIT recordings (not used in the manuscript tables) |
| `revision/` | Analyses added in the revision, their results and the figure script (see `revision/README.md`) |
| `figstyle.py` | Minimal plotting style used by `report.py` |
| `verification/reproduction_verification.json` | Record of a complete independent re-run: 384/384 feature and AUROC jobs, 6,896 arm comparisons and 1,200 event rows, maximum absolute difference 0 |
| `results/full_condition_arm_results.csv` | Per-condition, per-arm results in flat form |

## Manuscript map (revised manuscript, second submission)

| Manuscript item | Produced by | Source data |
|---|---|---|
| Tables 1–2 (settings, conditions) | `sim.DEFAULT`, `experiments.CONDITIONS`, `revision/runner.py` (`NEW`) | — |
| Table 3 (main AUROC) | `make_tables.py` → `table3_main.md` | `summary.json["table"]` |
| Table 4 (transforms) | `make_tables.py` → `table4_transforms.md` | `summary.json["transforms"]` |
| Table 5 (Kuramoto generator) | `make_tables.py` → `table5_kuramoto.md` | `summary.json["table"]` |
| Table 6 (power-plus-phase gain in every condition) | `revision/aggregate.py` | `results/auc.json`, `revision/results/jobs/` → `aggregate.json["incr"]` |
| Table 7 (lead field, frequency, gradient boosting) | `revision/aggregate.py` | `aggregate.json["arms"]`, `["incr"]`, `["hgb"]` |
| Table 8 (resampling, TOST; Table 6 of the first submission) | `make_tables.py` → `table6_resampling.md` | `summary.json["resampling"]` |
| Table 9 (high-frequency stress, signal-level error) | `revision/aggregate.py`, `revision/alias_signal.py` | `aggregate.json["tost"]`, `alias_signal.json` |
| Table 10 (event level, all rules and τ; Table 7 of the first submission) | `make_tables.py` → `table7_event.md` | `summary.json["event"]` |
| Table 11 (firing-power rule) | `revision/event_fp.py` | `event_fp_summary.json` |
| Table 12 (position relative to earlier work) | text | — |
| Table 13 (reporting checklist; Table 8 of the first submission) | text; every entry cites a table or section | — |
| Tables B1–B2 (hierarchical bootstrap) | `revision/event_boot.py` | `results/event_level.json` → `event_boot.json` |
| Figs. 1–9 | `revision/figures_rev.py` (printed size, text ≥ 10 pt) | as above |
| Eq. (13), focal-only coupling change | `revision/sim_ext.py` (`focal_only`) | — |
| Eq. (14), in-band error power | `revision/alias_signal.py` | — |
| Eq. (15), firing power | `revision/event_fp.py` | — |
| Appendix A values (L_c, validation errors) | `appendix_a/*.py` | `regime_check.json`, `event_level.json` |

The manuscript map of the first submission (Tables 6–8 and Figs. 7–8 were renumbered) is kept in the git history.

## Reproduce

    python run_all.py            # feature files of the main and secondary conditions
    python run_kura.py           # independent-generator conditions
    python analyze.py            # classifier results for all conditions -> results/auc.json
    python event_level.py map && python event_level.py && python regime_check.py
    python report.py             # results/summary.json and results/figs/
    python make_tables.py        # manuscript tables -> results/tables/
    cd appendix_a
    python alarm_exact.py ../results/alarm_exact.json
    python alarm_validate.py ../results/regime_check.json ../results/alarm_validate.json
    python event_regime.py ../results/event_level.json ../results/event_regime.json

The feature files (about 800 MB) and the per-subject score streams, seizure times, alarms and exclusion masks
are not stored; they are regenerated deterministically by the commands above. See `SEEDS_AND_SPLITS.md` for
the seeds and subject split.

## Real EEG (optional)

`eeg_real.py` runs label-free checks on six seizure-free one-hour recordings of the CHB-MIT Scalp EEG Database
(chb01_01, chb01_02, chb02_01, chb02_02, chb05_01, chb05_02) from PhysioNet
(https://physionet.org/content/chbmit/1.0.0/), Open Data Commons Attribution License v1.0. The recordings are
not redistributed here.
