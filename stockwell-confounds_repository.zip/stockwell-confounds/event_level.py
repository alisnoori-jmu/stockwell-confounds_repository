"""Event-level evaluation with controlled temporal correlation, plus the analytic regime map.

Scores for each held-out subject come from the trained window classifier (condition inc_0.6,
arm A1+plv) applied to 150 + 150 freshly generated windows per class. Monitoring streams of
25 h (5-s windows, six seizures) are then built with a Gaussian-copula AR(1) latent process:
the marginal score distribution of each class is kept exactly, and only the correlation time
tau changes. Alarm rules: 3-of-5 and 3-consecutive exceedances of a threshold fixed at 98 %
window specificity on validation subjects; consecutive qualifying windows form one event and a
refractory period of SPH + SOP (2 + 5 min, Winterhalder naming) follows each alarm.
"""
import os, json, sys
import numpy as np
from scipy import stats
from multiprocessing import Pool
import sim, features as F, analysis as A
from experiments import subject_seed, CONDITIONS, SPLIT

OUTF = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results', 'event_level.json')
WIN_S = 5.0
SPH_W, SOP_W = 24, 60              # 2 min gap, 5 min occurrence window (in 5-s windows)
REFRACT = SPH_W + SOP_W
CONFIGS = {'SPH2_SOP5': (24, 60), 'SPH10_SOP30': (120, 360)}
POSTICTAL_W = 360                  # 30 min excluded after each seizure
HOURS = 25
N_SZ = 6
TAUS = [0.0, 30.0, 60.0, 300.0, 1200.0]
N_EXTRA = 150
ARM = ['A1', 'A3_plv']


def score_windows(seed):
    """Train the arm on the stored features, then score fresh windows of the test subjects
    (cached in results/event_scores/s{seed}.json)."""
    cache = os.path.join(os.path.dirname(OUTF), 'event_scores', f's{seed}.json')
    if os.path.exists(cache):
        c = json.load(open(cache))
        return seed, c['thr'], {int(k): v for k, v in c['subj'].items()}
    os.makedirs(os.path.dirname(cache), exist_ok=True)
    d = A.load('inc_0.6', seed)
    X = np.hstack([d[b] for b in ARM]).astype(np.float64)
    y, subj = d['y'], d['subj']
    tr = np.isin(subj, list(SPLIT['train']))
    val = np.isin(subj, list(SPLIT['val']))
    # fit on training subjects only (C chosen on validation subjects), so that the alarm threshold
    # can be set on validation windows the model has never seen
    best = None
    for C in A.C_GRID:
        sc_, m_ = A._fit(X[tr], y[tr], C)
        a = A.roc_auc_score(y[val], m_.decision_function(sc_.transform(X[val])))
        if best is None or a > best[0]:
            best = (a, sc_, m_)
    _, sc, m = best
    thr = float(np.quantile(m.decision_function(sc.transform(X[val & (y == 0)])), 0.98))
    c = CONDITIONS['inc_0.6']
    p = dict(sim.DEFAULT); p.update(c['params'])
    lm = sim.local_pairs('bipolar')
    out = {}
    for s in SPLIT['test']:
        X, y = sim.generate_subject_windows(subject_seed(seed, s) + 7, p, N_EXTRA, c['delta_rho'])
        fe = [F.window_features(x, 256.0, lm, sim.CHAIN) for x in X]
        Z = np.stack([np.concatenate([f[b] for b in ARM]) for f in fe]).astype(np.float64)
        sco = m.decision_function(sc.transform(Z))
        out[int(s)] = dict(s0=sco[y == 0].tolist(), s1=sco[y == 1].tolist())
    json.dump(dict(thr=thr, subj=out), open(cache, 'w'))
    return seed, thr, out


def timeline(rng):
    """Seizure onsets (window index) for a 25-h record, >= 2 h apart, none in the first hour."""
    n = int(HOURS * 3600 / WIN_S)
    while True:
        on = np.sort(rng.integers(720, n - 60, N_SZ))
        if np.all(np.diff(on) > 1440):
            return n, on


def stream(rng, n, onsets, s0, s1, tau, sph=SPH_W, sop=SOP_W):
    lab = np.zeros(n, int)                  # 0 interictal, 1 preictal (SOP window), -1 excluded
    for o in onsets:
        lab[max(o - sph - sop, 0):o - sph] = 1
        lab[o - sph:min(o + POSTICTAL_W, n)] = -1
    phi = np.exp(-WIN_S / tau) if tau > 0 else 0.0
    z = np.empty(n)
    z[0] = rng.standard_normal()
    e = rng.standard_normal(n) * np.sqrt(1 - phi ** 2)
    for t in range(1, n):
        z[t] = phi * z[t - 1] + e[t]
    u = stats.norm.cdf(z)
    q0, q1 = np.sort(s0), np.sort(s1)
    sc = np.where(lab == 1, np.quantile(q1, u), np.quantile(q0, u))
    return sc, lab


def alarm_times(x, rule, refract=REFRACT):
    x = x.astype(int)
    if rule == '3consec':
        c = np.zeros(len(x), bool); c[2:] = (x[2:] & x[1:-1] & x[:-2]).astype(bool)
    else:
        c = np.convolve(x, np.ones(5, int), 'full')[:len(x)] >= 3
    onsets = np.flatnonzero(c & ~np.r_[False, c[:-1]])
    out, last = [], -10 ** 9
    for t in onsets:
        if t >= last + refract:
            out.append(t); last = t
    return np.array(out, int)


def evaluate_alarms(al, onsets, lab, n, sph=SPH_W, sop=SOP_W):
    refract = sph + sop
    hit = 0
    tp = set()
    for o in onsets:
        ok = [a for a in al if sph <= o - a <= sph + sop]
        if ok:
            hit += 1
            tp.update(ok)
    fp = [a for a in al if a not in tp and lab[a] == 0]
    refr = np.zeros(n, bool)                     # windows covered by the warning after any alarm
    for a in al:
        refr[a:a + refract] = True
    inter_h = np.sum(lab == 0) * WIN_S / 3600
    avail_h = np.sum((lab == 0) & ~refr) * WIN_S / 3600   # interictal time in which an alarm could be raised
    fa_h = len(fp) / max(avail_h, WIN_S / 3600)
    tiw = float(refr.mean())
    return hit / len(onsets), fa_h, tiw, inter_h, len(fp)


def random_predictor_sens(rng, n_alarms, onsets, n, reps=200, sph=SPH_W, sop=SOP_W):
    s = []
    for _ in range(reps):
        al = np.sort(rng.integers(0, n, n_alarms))
        hit = sum(any(sph <= o - a <= sph + sop for a in al) for o in onsets)
        s.append(hit / len(onsets))
    return float(np.mean(s))


def run(seeds=(0, 1, 2, 3, 4)):
    with Pool(2) as pool:
        scored = pool.map(score_windows, list(seeds))
    rows = []
    for seed, thr, subj in scored:
        for s, dd in subj.items():
            rng = np.random.default_rng(seed * 1000 + s)
            n, on = timeline(rng)
            s0, s1 = np.array(dd['s0']), np.array(dd['s1'])
            for cfg, (sph, sop) in CONFIGS.items():
                for tau in TAUS:
                    sc, lab = stream(np.random.default_rng(seed * 1000 + s + int(tau)), n, on, s0, s1, tau, sph, sop)
                    x = sc > thr
                    p_inter = float(x[lab == 0].mean())
                    runs = []
                    r = 0
                    for v in x[lab == 0]:
                        if v: r += 1
                        elif r: runs.append(r); r = 0
                    for rule in ['3of5', '3consec']:
                        al = alarm_times(x, rule, sph + sop)
                        sens, fa, tiw, ih, nfp = evaluate_alarms(al, on, lab, n, sph, sop)
                        rnd = random_predictor_sens(np.random.default_rng(seed + s), len(al), on, n, sph=sph, sop=sop)
                        rows.append(dict(cfg=cfg, seed=seed, subject=s, tau=tau, rule=rule, sens=sens, fa_h=fa,
                                         n_fa=nfp, tiw=tiw, random_sens=rnd, p_window=p_inter,
                                         mean_run=float(np.mean(runs)) if runs else 0.0,
                                         n_runs=len(runs), inter_h=ih, thr=thr, n_alarms=len(al)))
    json.dump(rows, open(OUTF, 'w'))
    return rows


def regime_map(ps=np.logspace(np.log10(0.005), np.log10(0.3), 60), R=REFRACT):
    """Closed-form crossover run length L* (windows) beyond which clustering LOWERS the alarm
    rate relative to independent windows, for k-consecutive (k=3) and 3-of-5 rules.
    Independent windows: first-trigger rate lambda_k = (1-p) p^k (3-consecutive),
    lambda_35 ~ 6 p^3 (1-p)^2 (3-of-5); refractory thinning lambda / (1 + lambda R).
    Two-state Markov with mean run L: every run of length >= 3 triggers once, rate ~ (p/L)(1-1/L)^2."""
    out = []
    for p in ps:
        for rule, lam in [('3consec', (1 - p) * p ** 3), ('3of5', 6 * p ** 3 * (1 - p) ** 2)]:
            lam_r = lam / (1 + lam * R)
            Ls = np.logspace(0, 5, 4000)
            mk = (p / Ls) * (1 - 1 / Ls) ** 2
            mk_r = mk / (1 + mk * R)
            above = Ls[(mk_r < lam_r) & (Ls > 3)]
            out.append(dict(p=float(p), rule=rule, L_star_windows=float(above.min()) if len(above) else np.inf,
                            iid_rate_per_h=float(lam_r * 720)))
    return out


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'map':
        json.dump({cfg: regime_map(R=sph + sop) for cfg, (sph, sop) in CONFIGS.items()},
                  open(OUTF.replace('event_level', 'regime_map'), 'w'))
    else:
        run()
