"""Classifier evaluation: L2 logistic regression per feature arm, C tuned on validation subjects,
refit on train+validation, pooled and per-subject AUROC on held-out test subjects."""
import os, json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from experiments import OUT, SPLIT

C_GRID = [0.01, 0.1, 1.0, 10.0]


def load(cname, seed):
    d = np.load(os.path.join(OUT, f'{cname}__s{seed}.npz'))
    return {k: d[k] for k in d.files}


def masks(subj):
    return {k: np.isin(subj, list(v)) for k, v in SPLIT.items()}


def _fit(Xtr, ytr, C):
    sc = StandardScaler().fit(Xtr)
    m = LogisticRegression(C=C, max_iter=3000).fit(sc.transform(Xtr), ytr)
    return sc, m


def per_subject_auc(score, y, subj):
    out = []
    for s in np.unique(subj):
        m = subj == s
        if len(np.unique(y[m])) == 2:
            out.append(roc_auc_score(y[m], score[m]))
    return np.array(out)


def eval_arm(d, blocks, prefix='', X_override=None, return_model=False):
    X = X_override if X_override is not None else np.hstack([d[prefix + b] for b in blocks]).astype(np.float64)
    y, subj = d['y'], d['subj']
    mk = masks(subj)
    best, bestC = -1, None
    for C in C_GRID:
        sc, m = _fit(X[mk['train']], y[mk['train']], C)
        a = roc_auc_score(y[mk['val']], m.decision_function(sc.transform(X[mk['val']])))
        if a > best:
            best, bestC = a, C
    trv = mk['train'] | mk['val']
    sc, m = _fit(X[trv], y[trv], bestC)
    s = m.decision_function(sc.transform(X[mk['test']]))
    res = dict(auc=float(roc_auc_score(y[mk['test']], s)), C=bestC,
               subj_auc=per_subject_auc(s, y[mk['test']], subj[mk['test']]).tolist())
    if return_model:
        res['model'] = (sc, m)
    return res


def permute_within_subject(Xblock, subj, rng):
    Xp = Xblock.copy()
    for s in np.unique(subj):
        idx = np.flatnonzero(subj == s)
        Xp[idx] = Xblock[rng.permutation(idx)]
    return Xp


def summarize(vals):
    v = np.asarray(vals, float)
    n = len(v)
    se = v.std(ddof=1) / np.sqrt(n) if n > 1 else np.nan
    return dict(mean=float(v.mean()), sd=float(v.std(ddof=1)) if n > 1 else np.nan,
                ci95=[float(v.mean() - 1.96 * se), float(v.mean() + 1.96 * se)] if n > 1 else None, n=n)
