"""Markdown tables for the manuscript, generated from results/summary.json (numbers are never typed by hand)."""
import os, json, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
S = json.load(open(os.path.join(HERE, 'results', 'summary.json')))

NAME = {'A1': 'A1 band power', 'A2': 'A2 absolute phase', 'plv': 'PLV', 'ppc': 'PPC', 'imcoh': '\\|ImCoh\\|',
        'wpli': 'wPLI', 'dwpli': 'dwPLI', 'ciplv': 'ciPLV', 'plv+reg': 'PLV + regional',
        'wpli+reg': 'wPLI + regional', 'imcoh+reg': '\\|ImCoh\\| + regional', 'ciplv+reg': 'ciPLV + regional',
        'A1+plv': 'A1 + PLV', 'A1+wpli': 'A1 + wPLI'}


ALL_ARMS = ['A1', 'A2', 'plv', 'ppc', 'imcoh', 'wpli', 'dwpli', 'ciplv', 'plv+reg', 'wpli+reg', 'imcoh+reg',
            'ciplv+reg', 'A1+plv', 'A1+wpli']


def cell(cond, arm, ci=True, mark=True):
    r = [x for x in S['table'] if x['cond'] == cond and x['arm'] == arm]
    if not r:
        return '–'
    r = r[0]
    s = f"{r['mean']:.3f}"
    if ci:
        s += f" ({r['lo']:.3f}–{r['hi']:.3f})"
    if mark and r.get('p_holm', 1) < 0.05:
        s += '*'
    return s


def table3():
    conds = [('inc_0.0', 'Null'), ('inc_0.35', '$\\Delta\\rho$ = 0.35'), ('inc_0.6', '$\\Delta\\rho$ = 0.6'),
             ('power40', 'Power +40 %')]
    arms = ALL_ARMS
    L = ['Table: Table 3. Test AUROC by feature arm in the main conditions (mean over 20 seeds, 95 % confidence '
         'interval). \\* differs from 0.5 after Holm correction within the condition (paired Wilcoxon test over seeds, '
         '$p_\\mathrm{Holm} < 0.05$).', '',
         '| Arm | ' + ' | '.join(c[1] for c in conds) + ' |', '|---|' + '---|' * len(conds)]
    for a in arms:
        L.append(f'| {NAME[a]} | ' + ' | '.join(cell(c, a) for c, _ in conds) + ' |')
    return '\n'.join(L)


def table4():
    conds = [('inc_0.35', '$\\Delta\\rho$ = 0.35'), ('inc_0.6', '$\\Delta\\rho$ = 0.6'), ('power40', 'Power +40 %')]
    arms = ['A1', 'A2', 'plv', 'imcoh', 'wpli']
    tr = S['transforms']
    L = ['Table: Table 4. Test AUROC for three time–frequency transforms (mean over 20 seeds; in brackets, the '
         'seed-paired difference from the Stockwell transform with its 95 % CI). The Stockwell and the $2\\pi$-cycle '
         'Morlet transform give identical inter-channel indices (Eq. 4).', '',
         '| Condition | Arm | Stockwell | Morlet, 7 cycles | Band-pass Hilbert |', '|---|---|---|---|---|']
    for c, cl in conds:
        for a in arms:
            row = []
            for t in ['stockwell', 'morlet7', 'hilbert']:
                r = [x for x in tr if x['cond'] == c and x['arm'] == a and x['transform'] == t]
                if not r:
                    row.append('–'); continue
                r = r[0]
                d = r['diff_vs_stockwell']
                row.append(f"{r['mean']:.3f}" + ('' if d is None else f" ({d['mean']:+.3f}; {d['lo']:+.3f} to {d['hi']:+.3f})"))
            L.append(f'| {cl} | {NAME[a]} | ' + ' | '.join(row) + ' |')
    return '\n'.join(L)


SHORT = {'A1': 'A1', 'A2': 'A2', 'plv': 'PLV', 'ppc': 'PPC', 'imcoh': '\\|ImCoh\\|', 'wpli': 'wPLI',
         'dwpli': 'dwPLI', 'ciplv': 'ciPLV'}


def table5():
    rs = S.get('resampling', [])
    if not rs:
        return ''
    L = ['Table: Table 6. Effect of the MLSPred-bench resampling operations on test AUROC: seed-paired difference, '
         'benchmark minus anti-aliased polyphase resampling (16 seeds). Operations: 250 Hz, zero padding from 1250 to '
         '1280 samples; 400 Hz, keeping five of every eight samples, then padding; 512 Hz, keeping one of every two '
         'samples; 1000 Hz, keeping one of every four samples, then padding. As in the benchmark, every output is '
         'treated as 256 Hz, so the 250-, 400- and 1000-Hz paths also rescale frequencies by 2.4 %. A1, band power; '
         'A2, absolute phase; Ref. AUROC, AUROC with polyphase resampling; $\\Delta$AUROC, benchmark minus reference. '
         'Equivalence (TOST) holds when the 90 % interval lies inside the margin; a difference (Diff.) is declared when '
         'the 95 % interval excludes 0.', '',
         '| Rate (Hz) | Arm | Ref. AUROC | $\\Delta$AUROC | 90 % CI | 95 % CI | Equiv. ±0.02 | Equiv. ±0.05 | Diff. |',
         '|-------|----------|----------|-----------|------------------|------------------|---------|---------|-------|']
    for r in rs:
        L.append(f"| {r['rate']} | {SHORT[r['arm']]} | {r['ref_auc']:.3f} | {r['mean']:+.3f} | "
                 f"{r['lo90']:+.3f} to {r['hi90']:+.3f} | {r['lo95']:+.3f} to {r['hi95']:+.3f} | "
                 f"{'yes' if r['equiv_002'] else 'no'} | {'yes' if r['equiv_005'] else 'no'} | {'yes' if r['differs'] else 'no'} |")
    return '\n'.join(L)


def table6():
    ev = S.get('event', [])
    if not ev:
        return ''
    lab = {0.0: '0', 30.0: '30 s', 60.0: '1 min', 300.0: '5 min', 1200.0: '20 min'}
    L = ['Table: Table 7. Event-level performance of the A1 + PLV classifier ($\\Delta\\rho$ = 0.6) on 25-h '
         'monitoring streams of 60 test subjects (five seeds), by alarm rule and correlation time $\\tau$ of the window '
         'scores ($\\tau$ = 0: independent windows). Means over subjects with subject-bootstrap 95 % intervals. '
         '$p$, pooled exceedance rate on interictal windows; run, mean run of exceedances (windows); FA/h, false alarms '
         'per hour; TIW, time in warning; random, event sensitivity of a random predictor issuing the same number of '
         'alarms.', '',
         '| SPH / SOP (min) | Rule | $\\tau$ | $p$ | Run | Sensitivity | FA/h | Median FA/h | TIW | Random |',
         '|---------|---------|-------|-------|-------|---------------|---------------|---------|-------|---------|']
    order = {'SPH2_SOP5': 0, 'SPH10_SOP30': 1}
    ev = sorted(ev, key=lambda r: (order[r['cfg']], 0 if r['rule'] == '3of5' else 1, r['tau']))
    for r in ev:
        cfg = '2 / 5' if r['cfg'] == 'SPH2_SOP5' else '10 / 30'
        rule = '3 of 5' if r['rule'] == '3of5' else '3 consec.'
        s, f = r['sens'], r['fa_h']
        L.append(f"| {cfg} | {rule} | {lab[r['tau']]} | {r['p_window']:.3f} | {r['mean_run_windows']:.1f} | "
                 f"{s[0]:.2f} ({s[1]:.2f}–{s[2]:.2f}) | {f[0]:.2f} ({f[1]:.2f}–{f[2]:.2f}) | {r['fa_h_median']:.2f} | "
                 f"{r['tiw']:.3f} | {r['random_sens']:.3f} |")
    return '\n'.join(L)


def table_kura():
    conds = [('kura_null', 'Null'), ('kura_inc_0.1', '$\\Delta K$ = 0.1'), ('kura_inc_0.4', '$\\Delta K$ = 0.4'),
             ('kura_power40', 'Power +40 %')]
    if not any(x['cond'] == 'kura_null' for x in S['table']):
        return ''
    arms = ALL_ARMS
    L = ['Table: Table 5. Independent generator (noisy Kuramoto oscillators, Eq. 2): test AUROC by feature arm '
         '(mean over 12 seeds, 95 % confidence interval). \\* differs from 0.5 after Holm correction.', '',
         '| Arm | ' + ' | '.join(c[1] for c in conds) + ' |', '|---|' + '---|' * len(conds)]
    for a in arms:
        L.append(f'| {NAME[a]} | ' + ' | '.join(cell(c, a) for c, _ in conds) + ' |')
    return '\n'.join(L)


def _minus(t):
    import re
    t = re.sub(r'(?<=[\s(;])-(?=\d)', '\u2212', t)
    return re.sub(r'[+\u2212]0\.000(?!\d)', '0.000', t)


if __name__ == '__main__':
    D = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'results', 'tables')
    os.makedirs(D, exist_ok=True)
    for name, fn in [('table3_main', table3), ('table4_transforms', table4), ('table5_kuramoto', table_kura),
                     ('table6_resampling', table5), ('table7_event', table6)]:
        txt = fn()
        if txt:
            open(os.path.join(D, name + '.md'), 'w').write(_minus(txt) + '\n')
    print('written', sorted(os.listdir(D)))
