"""Scalp-EEG window generator for the phase-connectivity simulation study.

Every property that the analysis depends on is an explicit, documented parameter:
coupling strength (rho), phase-diffusion rate, lag spread, oscillation amplitude,
lead-field width, artefact levels, sensor SNR, inter-subject heterogeneity and the
native sampling rate. Nothing is tuned after looking at classifier output.
"""
import numpy as np

# ---------------------------------------------------------------- geometry
ELECTRODES = ['FP1', 'FP2', 'F7', 'F8', 'F3', 'F4', 'T3', 'T4', 'T5', 'T6',
              'C3', 'C4', 'CZ', 'P3', 'P4', 'O1', 'O2']
EPOS = np.array([
    [-0.309, 0.951], [0.309, 0.951],      # FP1 FP2
    [-0.809, 0.588], [0.809, 0.588],      # F7 F8
    [-0.420, 0.550], [0.420, 0.550],      # F3 F4
    [-1.000, 0.000], [1.000, 0.000],      # T3 T4
    [-0.809, -0.588], [0.809, -0.588],    # T5 T6
    [-0.500, 0.000], [0.500, 0.000],      # C3 C4
    [0.000, 0.000],                       # CZ
    [-0.420, -0.550], [0.420, -0.550],    # P3 P4
    [-0.309, -0.951], [0.309, -0.951]])   # O1 O2
EIDX = {e: i for i, e in enumerate(ELECTRODES)}

# 20-channel TCP double-banana montage (TUH/MLSPred-Bench, ear channels removed)
MONTAGE = [('FP1', 'F7'), ('F7', 'T3'), ('T3', 'T5'), ('T5', 'O1'),
           ('FP2', 'F8'), ('F8', 'T4'), ('T4', 'T6'), ('T6', 'O2'),
           ('T3', 'C3'), ('C3', 'CZ'), ('CZ', 'C4'), ('C4', 'T4'),
           ('FP1', 'F3'), ('F3', 'C3'), ('C3', 'P3'), ('P3', 'O1'),
           ('FP2', 'F4'), ('F4', 'C4'), ('C4', 'P4'), ('P4', 'O2')]
CHAIN = np.array([0] * 4 + [1] * 4 + [2] * 4 + [3] * 4 + [4] * 4)
MONTAGE_A = np.array([EIDX[a] for a, b in MONTAGE])
MONTAGE_B = np.array([EIDX[b] for a, b in MONTAGE])

N_SRC = 8
SRC_ANG = np.pi / 8 + np.arange(N_SRC) * np.pi / 4
SRC_R = 0.55
FOCAL = np.array([2, 3, 4, 5])          # left-hemisphere sources whose coupling/power changes
EMG_SITES = np.array([EIDX[e] for e in ['FP1', 'FP2', 'F7', 'F8', 'T3', 'T4', 'T5', 'T6']])

DEFAULT = dict(
    fs=256.0, win_s=5.0,
    rho_base=0.35,          # baseline weight of the common phase walk
    diffusion=0.6,          # phase random-walk intensity, rad / sqrt(s)
    lag_sd_deg=30.0,        # SD of fixed per-source phase lags (deg); 0 = zero-lag coupling
    osc_amp=1.0,            # oscillation amplitude relative to unit-RMS background
    f0_range=(9.0, 11.0),   # oscillation frequency, drawn per subject
    bg_beta=(1.0, 2.0),     # 1/f^beta background exponent range
    lf_width=0.35,          # lead-field Gaussian width (head radius = 1)
    snr_db=5.0,             # sensor-noise SNR relative to clean electrode RMS
    emg=0.30, mains=0.20, pop=0.50,   # artefact levels relative to clean RMS
    hetero=1.0,             # multiplier on all inter-subject jitters
    observe='bipolar',      # 'source' | 'referential' | 'bipolar'
    artefacts=True,
    generator='shared_walk',  # 'shared_walk' (Eq. 1) | 'kuramoto' (independent check)
    kura_K0=0.10,           # Kuramoto: baseline pairwise coupling (rad/s)
    kura_detune_hz=0.05,    # Kuramoto: SD of natural-frequency offsets (Hz), fixed per subject
    kura_burn_s=3.0,        # Kuramoto: burn-in before each window (s)
)


def _pink(rng, n_ch, n, fs, beta, fmax_frac=0.45):
    """Unit-RMS 1/f^beta noise with content from 0.5 Hz up to fmax_frac*fs."""
    f = np.fft.rfftfreq(n, 1.0 / fs)
    amp = np.zeros_like(f)
    band = (f >= 0.5) & (f <= fmax_frac * fs)
    amp[band] = f[band] ** (-beta / 2.0)
    spec = amp * (rng.standard_normal((n_ch, f.size)) + 1j * rng.standard_normal((n_ch, f.size)))
    x = np.fft.irfft(spec, n=n, axis=-1)
    return x / (x.std(axis=-1, keepdims=True) + 1e-12)


def _bandnoise(rng, n, fs, lo, hi_frac=0.45):
    f = np.fft.rfftfreq(n, 1.0 / fs)
    m = (f >= lo) & (f <= hi_frac * fs)
    spec = m * (rng.standard_normal(f.size) + 1j * rng.standard_normal(f.size))
    x = np.fft.irfft(spec, n=n)
    return x / (x.std() + 1e-12)


def make_subject(rng, p):
    """Fixed per-subject anatomy / physiology."""
    h = p['hetero']
    ang = SRC_ANG + rng.normal(0, 0.10 * h, N_SRC)
    rad = SRC_R * np.exp(rng.normal(0, 0.10 * h, N_SRC))
    spos = np.c_[rad * np.cos(ang), rad * np.sin(ang)]
    width = p['lf_width'] * np.exp(rng.normal(0, 0.10 * h))
    d2 = ((EPOS[:, None, :] - spos[None, :, :]) ** 2).sum(-1)
    gain = np.exp(rng.normal(0, 0.10 * h, len(ELECTRODES)))
    L = gain[:, None] * np.exp(-d2 / (2 * width ** 2))
    return dict(
        L=L,
        f0=rng.uniform(*p['f0_range']) + 0.0 * h,
        beta=rng.uniform(*p['bg_beta'], N_SRC),
        amp=p['osc_amp'] * np.exp(rng.normal(0, 0.20 * h, N_SRC)),
        lags=np.deg2rad(rng.normal(0, p['lag_sd_deg'], N_SRC)),
        snr_db=p['snr_db'] + rng.normal(0, 1.5 * h),
        mains_amp=rng.uniform(0.5, 1.5, len(ELECTRODES)),
        emg_rate=np.clip(rng.normal(0.5, 0.15 * h), 0.05, 0.95),
        scale=np.exp(rng.normal(0, 0.30 * h)),   # overall amplifier/anatomy gain
    )


def make_subject_full(rng, p):
    subj = make_subject(rng, p)
    if p.get('generator', 'shared_walk') == 'kuramoto':
        # drawn after all shared-walk quantities so the shared-walk random stream is unchanged
        subj['detune'] = rng.normal(0, p['kura_detune_hz'] * p['hetero'], N_SRC)
    return subj


import numba


@numba.njit(cache=True)
def _kuramoto_integrate(th0, w, K, noise, dt, nb, n):
    """Euler-Maruyama steps of Eq. (2); returns the phases of the last n steps."""
    m = th0.shape[0]
    th = th0.copy()
    new = np.empty(m)
    out = np.empty((n, m))
    for t in range(nb + n):
        for k in range(m):
            s = 0.0
            for j in range(m):
                s += K[k, j] * np.sin(th[j] - th[k])
            new[k] = th[k] + (w[k] + s) * dt + noise[t, k]
        for k in range(m):
            th[k] = new[k]
        if t >= nb:
            for k in range(m):
                out[t - nb, k] = th[k]
    return out


def source_window_kuramoto(rng, subj, p, k_focal, amp_focal_mult, n, fs):
    """Independent generator: noisy Kuramoto oscillators.

    d theta_k = [2 pi (f0 + detune_k) + sum_j K_kj sin(theta_j - theta_k)] dt + D dW_k,
    K_kj = K0 for all pairs, K0 + dK for pairs inside the focal set (class 1). Lags are not
    imposed: they emerge from the natural-frequency offsets, as in coupled oscillators.
    Euler-Maruyama at fs with a burn-in so that each window starts from the stationary regime."""
    dt = 1.0 / fs
    nb = int(round(p['kura_burn_s'] * fs))
    K = np.full((N_SRC, N_SRC), p['kura_K0'])
    for i in FOCAL:
        for j in FOCAL:
            K[i, j] = k_focal
    np.fill_diagonal(K, 0.0)
    w = 2 * np.pi * (subj['f0'] + subj['detune'])
    th = rng.uniform(0, 2 * np.pi, N_SRC)
    noise = rng.normal(0, p['diffusion'] * np.sqrt(dt), (nb + n, N_SRC))
    out = _kuramoto_integrate(th, w, K, noise, dt, nb, n)
    amp = subj['amp'].copy()
    amp[FOCAL] *= amp_focal_mult
    osc = amp[:, None] * np.sqrt(2) * np.cos(out.T)
    bg = np.vstack([_pink(rng, 1, n, fs, b)[0] for b in subj['beta']])
    return bg + osc


def source_window(rng, subj, p, rho_focal, amp_focal_mult, n, fs):
    """8 source signals: 1/f background + coupled oscillation at f0.

    theta_k(t) = rho_k * Xi(t) + sqrt(1 - rho_k^2) * xi_k(t) + lag_k
    Xi, xi_k independent random walks with increment SD = diffusion / sqrt(fs), so the
    accumulated phase variance over a window does not depend on fs.
    """
    t = np.arange(n) / fs
    step = p['diffusion'] / np.sqrt(fs)
    Xi = np.cumsum(rng.normal(0, step, n))
    xi = np.cumsum(rng.normal(0, step, (N_SRC, n)), axis=1)
    rho = np.full(N_SRC, p['rho_base'])
    rho[FOCAL] = rho_focal
    theta = rho[:, None] * Xi[None, :] + np.sqrt(1 - rho[:, None] ** 2) * xi + subj['lags'][:, None]
    phase0 = rng.uniform(0, 2 * np.pi)
    amp = subj['amp'].copy()
    amp[FOCAL] *= amp_focal_mult
    osc = amp[:, None] * np.sqrt(2) * np.cos(2 * np.pi * subj['f0'] * t[None, :] + phase0 + theta)
    bg = np.vstack([_pink(rng, 1, n, fs, b)[0] for b in subj['beta']])
    return bg + osc


def electrode_window(rng, subj, p, src, n, fs):
    clean = subj['L'] @ src
    rms = clean.std(axis=1, keepdims=True).mean()
    x = clean.copy()
    if p['artefacts']:
        t = np.arange(n) / fs
        # EMG: broadband (20 Hz .. 0.45 fs), focal (2-4 edge electrodes), bursty
        if rng.random() < subj['emg_rate']:
            k = rng.integers(2, 5)
            sites = rng.choice(EMG_SITES, k, replace=False)
            dur = rng.uniform(0.5, 2.0)
            t0 = rng.uniform(0, n / fs - dur)
            env = 1.0 + 3.0 * ((t >= t0) & (t < t0 + dur))
            for s in sites:
                x[s] += p['emg'] * rms * env * _bandnoise(rng, n, fs, 20.0)
        # mains 50 Hz + harmonics below Nyquist, electrode-specific amplitude
        for hmul, a in [(1, 1.0), (2, 0.4), (3, 0.2)]:
            fh = 50.0 * hmul
            if fh < 0.5 * fs:
                ph = rng.uniform(0, 2 * np.pi)
                x += (p['mains'] * rms * a * subj['mains_amp'])[:, None] * np.sin(2 * np.pi * fh * t + ph)[None, :]
        # electrode pop: step with exponential decay on one electrode
        if rng.random() < 0.5:
            e = rng.integers(len(ELECTRODES))
            t0 = rng.uniform(0, n / fs - 0.5)
            m = t >= t0
            x[e, m] += p['pop'] * 4.0 * rms * rng.choice([-1, 1]) * np.exp(-(t[m] - t0) / 0.3)
    noise_sd = rms * 10 ** (-subj['snr_db'] / 20.0)
    x += rng.normal(0, noise_sd, x.shape)
    return x * subj['scale']


def observe(p, src, elec, rng, subj, n):
    if p['observe'] == 'source':
        rms = src.std(axis=1, keepdims=True).mean()
        return (src + rng.normal(0, rms * 10 ** (-subj['snr_db'] / 20.0), src.shape)) * subj['scale']
    if p['observe'] == 'referential':
        return elec
    return elec[MONTAGE_A] - elec[MONTAGE_B]


def generate_subject_windows(seed, p, n_per_class, delta_rho=0.0, amp_mult=1.0, direction=+1):
    """Return (X, y): X (2*n_per_class, n_ch, n) at p['fs']; y=1 for the 'preictal' class."""
    rng = np.random.default_rng(seed)
    fs = p['fs']
    n = int(round(p['win_s'] * fs))
    subj = make_subject_full(rng, p)
    kura = p.get('generator', 'shared_walk') == 'kuramoto'
    out, y = [], []
    for cls in (0, 1):
        if kura:
            rho_f = max(p['kura_K0'] + (direction * delta_rho if cls == 1 else 0.0), 0.0)
        else:
            rho_f = p['rho_base'] + (direction * delta_rho if cls == 1 else 0.0)
            rho_f = float(np.clip(rho_f, 0.0, 0.999))
        am = amp_mult if cls == 1 else 1.0
        for _ in range(n_per_class):
            if kura:
                src = source_window_kuramoto(rng, subj, p, rho_f, am, n, fs)
            else:
                src = source_window(rng, subj, p, rho_f, am, n, fs)
            elec = None if p['observe'] == 'source' else electrode_window(rng, subj, p, src, n, fs)
            out.append(observe(p, src, elec, rng, subj, n).astype(np.float32))
            y.append(cls)
    return np.stack(out), np.array(y)


def local_pairs(observe_mode):
    """Boolean mask over the upper-triangle pair list marking 'local' pairs."""
    if observe_mode == 'bipolar':
        ch = CHAIN
        n = len(ch)
        iu = np.triu_indices(n, 1)
        return ch[iu[0]] == ch[iu[1]]
    if observe_mode == 'referential':
        n = len(ELECTRODES)
        iu = np.triu_indices(n, 1)
        d = np.linalg.norm(EPOS[iu[0]] - EPOS[iu[1]], axis=1)
        return d < 0.62
    n = N_SRC
    iu = np.triu_indices(n, 1)
    diff = np.abs(iu[0] - iu[1])
    return (diff == 1) | (diff == n - 1)


def focal_pairs(observe_mode):
    """Pairs lying inside the focal (left) region - used only for descriptive checks."""
    if observe_mode == 'source':
        n = N_SRC
        iu = np.triu_indices(n, 1)
        f = np.isin(iu[0], FOCAL) & np.isin(iu[1], FOCAL)
        return f
    if observe_mode == 'bipolar':
        left = np.isin(CHAIN, [0, 3])
    else:
        left = EPOS[:, 0] < -0.1
    n = len(left)
    iu = np.triu_indices(n, 1)
    return left[iu[0]] & left[iu[1]]
