import experiments as E
E.run(['kura_null', 'kura_inc_0.1', 'kura_inc_0.4', 'kura_power40'], list(range(12)))
print('KURA DONE', flush=True)
