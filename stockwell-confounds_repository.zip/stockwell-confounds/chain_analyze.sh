#!/bin/bash
# Analyse each block of conditions as soon as all its feature files exist (sequential: one analyze at a time).
F=results/features
wait_for () {   # $1 = glob prefix list, $2 = expected count
  while true; do
    n=0; for c in $1; do n=$((n + $(ls $F/${c}__s*.npz 2>/dev/null | wc -l))); done
    if [ "$n" -ge "$2" ]; then break; fi
    sleep 30
  done
}
wait_for "rs_512 rs_1000 rs_400 rs_250" 64
nice -n 3 python3 analyze.py rs_512,rs_1000,rs_400,rs_250 1
wait_for "obs_source obs_referential obs_bipolar_noart" 36
nice -n 3 python3 analyze.py obs_source,obs_referential,obs_bipolar_noart 1
wait_for "lag_0 lag_10 lag_60 lag_90 lag_0_null" 60
nice -n 3 python3 analyze.py lag_0,lag_10,lag_60,lag_90,lag_0_null 1
wait_for "inc_0.1 inc_0.2 dec_0.1 dec_0.2 dec_0.35" 60
nice -n 3 python3 analyze.py inc_0.1,inc_0.2,dec_0.1,dec_0.2,dec_0.35 1
wait_for "snr_p10 snr_m5 hetero2" 36
nice -n 3 python3 analyze.py snr_p10,snr_m5,hetero2 1
wait_for "kura_null kura_inc_0.1 kura_inc_0.4 kura_power40" 48
nice -n 3 python3 analyze.py kura_null,kura_inc_0.1,kura_inc_0.4,kura_power40 1
echo CHAIN DONE
