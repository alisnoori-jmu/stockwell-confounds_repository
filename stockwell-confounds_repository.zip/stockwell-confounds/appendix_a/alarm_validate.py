"""Compare exact-onset + refractory-thinning predictions with the direct simulations of regime_check.json."""
import json, sys
import numpy as np
from alarm_exact import onset_rate, iid_rate
rc = json.load(open(sys.argv[1]))
R = {'SPH2_SOP5': 84, 'SPH10_SOP30': 480}
rows = []
for r in rc:
    p, L, rule, Rr = r['p'], r['L'], r['rule'], R[r['cfg']]
    lam = iid_rate(p, rule) if L is None else onset_rate(p, L, rule)
    pred = lam / (1 + lam * Rr) * 720
    rows.append(dict(r, pred_exact_fa_h=pred,
                     relerr_orig=abs(r['pred_fa_h'] - r['sim_fa_h']) / r['sim_fa_h'],
                     relerr_exact=abs(pred - r['sim_fa_h']) / r['sim_fa_h']))
for kind in ['iid', 'clustered']:
    for rule in ['3consec', '3of5']:
        sel = [x for x in rows if x['rule'] == rule and ((x['L'] is None) == (kind == 'iid'))]
        print(kind, rule, 'median rel err: original %.3f exact %.3f | max original %.3f exact %.3f' % (
            np.median([x['relerr_orig'] for x in sel]), np.median([x['relerr_exact'] for x in sel]),
            max(x['relerr_orig'] for x in sel), max(x['relerr_exact'] for x in sel)))
for kind in ['iid', 'clustered']:
    sel = [x for x in rows if (x['L'] is None) == (kind == 'iid')]
    print(kind, 'ALL median original %.3f exact %.3f' % (np.median([x['relerr_orig'] for x in sel]), np.median([x['relerr_exact'] for x in sel])))
json.dump(rows, open(sys.argv[2], 'w'), indent=1)
