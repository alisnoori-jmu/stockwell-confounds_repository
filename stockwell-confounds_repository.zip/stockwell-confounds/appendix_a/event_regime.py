"""Per-subject check: in the Gaussian-copula event experiment, compare each subject's empirical interictal
exceedance rate p and mean run with the exact crossover L*(p) of Appendix A."""
import json, sys
import numpy as np
from alarm_exact import L_star
ev = json.load(open(sys.argv[1]))
cache = {}
def Ls(p, rule):
    key = (round(p, 3), rule)
    if key not in cache:
        cache[key] = L_star(max(key[0], 0.002), rule)
    return cache[key]
out = {}
for cfg in ['SPH2_SOP5', 'SPH10_SOP30']:
    for rule in ['3of5', '3consec']:
        base = {(r['seed'], r['subject']): r for r in ev if r['cfg'] == cfg and r['rule'] == rule and r['tau'] == 0.0}
        for tau in [30.0, 60.0, 300.0, 1200.0]:
            rr = [r for r in ev if r['cfg'] == cfg and r['rule'] == rule and r['tau'] == tau]
            above = [r for r in rr if r['mean_run'] > Ls(r['p_window'], rule)]
            fa_tot = sum(r['n_fa'] for r in rr)
            fa_above = sum(r['n_fa'] for r in above)
            d_above = [r['fa_h'] - base[(r['seed'], r['subject'])]['fa_h'] for r in above]
            d_below = [r['fa_h'] - base[(r['seed'], r['subject'])]['fa_h'] for r in rr if r not in above]
            out[f'{cfg}|{rule}|{tau}'] = dict(n=len(rr), n_above=len(above), share_fa_from_above=fa_above / max(fa_tot, 1),
                                              mean_dFA_above=float(np.mean(d_above)) if d_above else None,
                                              mean_dFA_below=float(np.mean(d_below)) if d_below else None,
                                              p_median=float(np.median([r['p_window'] for r in rr])),
                                              p_max=float(max(r['p_window'] for r in rr)))
            print(cfg, rule, tau, out[f'{cfg}|{rule}|{tau}'])
json.dump(out, open(sys.argv[2], 'w'), indent=1)
