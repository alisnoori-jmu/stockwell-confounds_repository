"""Exact stationary alarm-onset rates for a two-state Markov exceedance stream, and the crossover run length L*.

Exceedance stream X_t in {0,1}: stationary P(X=1) = p, mean length of 1-runs L (windows).
Transition probabilities: P(0->1) = a = p / (L (1 - p)), P(1->1) = b = 1 - 1/L.  Independent windows: L = 1/(1-p).
Alarm condition c_t: 3 consecutive -> X_{t-2}=X_{t-1}=X_t=1;  3 of 5 -> X_{t-4}+...+X_t >= 3.
Onset at t: c_t = 1 and c_{t-1} = 0 (consecutive qualifying windows form one event).
lambda(p, L) = P(onset at t) is computed exactly by enumerating the 6-window history X_{t-5..t} (3 of 5) or
X_{t-3..t} (3 consecutive) under the stationary chain.
"""
from itertools import product
import numpy as np


def trans(p, L):
    a = p / (L * (1 - p)); b = 1 - 1 / L
    if not (0 < a <= 1 and 0 <= b < 1):
        raise ValueError((p, L))
    return np.array([[1 - a, a], [1 - b, b]])


def cond(bits, rule):
    return all(bits[-3:]) if rule == '3consec' else sum(bits[-5:]) >= 3


def onset_rate(p, L, rule):
    T = trans(p, L)
    tot = 0.0
    for bits in product((0, 1), repeat=6):
        if cond(bits[1:], rule) and not cond(bits[:5], rule):
            pr = p if bits[0] else 1 - p
            for u, v in zip(bits[:-1], bits[1:]):
                pr *= T[u, v]
            tot += pr
    return tot


def iid_rate(p, rule):
    return onset_rate(p, 1 / (1 - p), rule)


def approx_iid(p, rule):            # formulas used in the original regime map
    return (1 - p) * p ** 3 if rule == '3consec' else 6 * p ** 3 * (1 - p) ** 2


def approx_markov(p, L):            # original regime map, both rules
    return (p / L) * (1 - 1 / L) ** 2


def L_star(p, rule, exact=True, Lmax=1e6):
    """Smallest L > 3 (windows) beyond which the clustered stream raises FEWER onsets than independent windows."""
    ref = iid_rate(p, rule) if exact else approx_iid(p, rule)
    f = (lambda L: onset_rate(p, L, rule)) if exact else (lambda L: approx_markov(p, L))
    Ls = np.logspace(np.log10(3.0001), np.log10(Lmax), 3000)
    v = np.array([f(L) for L in Ls]) - ref
    idx = np.flatnonzero((v[:-1] >= 0) & (v[1:] < 0))
    if len(idx) == 0:
        return np.inf
    i = idx[-1]
    lo, hi = Ls[i], Ls[i + 1]
    for _ in range(80):
        m = np.sqrt(lo * hi)
        if f(m) - ref >= 0: lo = m
        else: hi = m
    return np.sqrt(lo * hi)


if __name__ == '__main__':
    import json, sys
    out = {}
    for p in [0.01, 0.02, 0.05, 0.10]:
        for rule in ['3consec', '3of5']:
            le, la = L_star(p, rule, True), L_star(p, rule, False)
            out[f'{p}|{rule}'] = dict(p=p, rule=rule, iid_exact=iid_rate(p, rule), iid_approx=approx_iid(p, rule),
                                      Lstar_exact_windows=le, Lstar_exact_min=le * 5 / 60,
                                      Lstar_approx_windows=la, Lstar_approx_min=la * 5 / 60)
            print(p, rule, 'iid exact %.3e approx %.3e' % (iid_rate(p, rule), approx_iid(p, rule)),
                  'L* exact %.1f min, approx %.1f min' % (le * 5 / 60, la * 5 / 60))
    json.dump(out, open(sys.argv[1] if len(sys.argv) > 1 else 'alarm_exact.json', 'w'), indent=1)
